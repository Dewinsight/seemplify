# Mailcow Calendar Guide - SOGo Calendar & CalDAV

**Date:** January 19, 2026  
**Status:** ✅ Calendar Available via SOGo

---

## ✅ Calendar Features Available

Mailcow includes **full calendar functionality** through **SOGo** (Scalable OpenGroupware.org):

### Web Interface
- ✅ **Calendar in SOGo Webmail**
  - Access: https://mail.seemplifyai.com/SOGo/
  - Login with your email (e.g., `michael@paddie.io`)
  - Full calendar interface with:
    - Create/edit/delete events
    - Multiple calendars
    - Recurring events
    - Event invitations
    - Calendar sharing

### CalDAV Support
- ✅ **Sync with Calendar Apps**
  - iPhone/iPad Calendar
  - Android Calendar apps
  - macOS Calendar
  - Thunderbird
  - Outlook (with CalDAV plugin)
  - Other CalDAV-compatible clients

### CardDAV Support
- ✅ **Contacts Sync**
  - Sync contacts with mobile devices
  - Compatible with CardDAV clients

---

## 📱 How to Access Calendar

### Web Access
1. Go to: **https://mail.seemplifyai.com/SOGo/**
2. Login with your email: `michael@paddie.io` (or `ryan@paddie.io`, `info@paddie.io`)
3. Click on **Calendar** tab
4. Start creating events!

### Mobile/Desktop Sync (CalDAV)

**CalDAV Server URL:**
```
https://mail.seemplifyai.com/SOGo/dav/michael@paddie.io/Calendar/
```

**Replace `michael@paddie.io` with your email address**

**Authentication:**
- Username: Your full email (e.g., `michael@paddie.io`)
- Password: Your Mailcow password

---

## 📋 CalDAV Setup Instructions

### iPhone/iPad
1. Settings → Calendar → Accounts → Add Account
2. Select **Other** → **Add CalDAV Account**
3. Server: `mail.seemplifyai.com`
4. Username: `michael@paddie.io` (your email)
5. Password: Your Mailcow password
6. Description: `Mailcow Calendar`
7. Save

### Android
1. Install a CalDAV client app (e.g., "DAVx⁵" or "CalDAV-Sync")
2. Add new account:
   - Server URL: `https://mail.seemplifyai.com/SOGo/dav/michael@paddie.io/Calendar/`
   - Username: `michael@paddie.io`
   - Password: Your Mailcow password

### macOS Calendar
1. Calendar app → Preferences → Accounts
2. Click **+** → **Add Other Account** → **Add a CalDAV account**
3. Server: `mail.seemplifyai.com`
4. Username: `michael@paddie.io`
5. Password: Your Mailcow password

### Thunderbird
1. Install **Lightning** calendar extension
2. File → New → Calendar
3. Select **On the Network** → **CalDAV**
4. Location: `https://mail.seemplifyai.com/SOGo/dav/michael@paddie.io/Calendar/`
5. Username: `michael@paddie.io`
6. Password: Your Mailcow password

---

## 📞 Contacts (CardDAV)

**CardDAV Server URL:**
```
https://mail.seemplifyai.com/SOGo/dav/michael@paddie.io/Contacts/
```

Use the same credentials as CalDAV.

---

## ⚠️ Known Limitations

1. **Outlook Compatibility:**
   - Outlook on Windows/Mac doesn't natively support CalDAV
   - May need third-party plugins or workarounds
   - Webmail (SOGo) works perfectly

2. **Event Invitations:**
   - Some external services (like Outlook.com) may have issues with `.ics` invites
   - Internal Mailcow-to-Mailcow invitations work fine

3. **Sync Reliability:**
   - CalDAV sync is generally reliable
   - Some mobile apps may need specific CalDAV client apps

---

## ✅ Current Status

**Calendar is ENABLED and WORKING for all paddie.io mailboxes:**
- ✅ `michael@paddie.io` - Calendar access enabled
- ✅ `ryan@paddie.io` - Calendar access enabled
- ✅ `info@paddie.io` - Calendar access enabled

**SOGo is running and configured:**
- ✅ SOGo container: Running
- ✅ Calendar functionality: Enabled
- ✅ CalDAV: Available
- ✅ CardDAV: Available

---

## 🎯 Quick Start

**To use calendar right now:**

1. **Web Access:**
   - Go to: https://mail.seemplifyai.com/SOGo/
   - Login with your email
   - Click **Calendar** tab
   - Start creating events!

2. **Mobile Sync:**
   - Use CalDAV URL: `https://mail.seemplifyai.com/SOGo/dav/YOUR_EMAIL/Calendar/`
   - Username: Your full email
   - Password: Your Mailcow password

---

**Last Updated:** January 19, 2026  
**Status:** ✅ Calendar Available and Working
