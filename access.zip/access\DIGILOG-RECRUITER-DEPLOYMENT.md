# diGiLog Recruiter — Deployment & Access

**Last updated:** 2026-06-10

How the **diGiLog Recruiter** app is deployed and operated. diGiLog is a standalone fork of the recruiter app — it is **fully self-contained**: its own backend, its own database, and **no Seemplify IdP / no `api.seemplifyai.com`**.

> ⚠️ **Do not confuse the VMs.** diGiLog's backend runs on **`vm-seemplify-budget`** (the shared *budget* VM). It is **NOT** the dedicated Seemplify VM (`seemplify-vm`) and **NOT** `api.seemplifyai.com`. See [VM disambiguation](#vm-disambiguation).

---

## Topology at a glance

| Piece | Where | URL |
|-------|-------|-----|
| **Recruiter frontend** | Vercel (`digilog-recruiter-frontend`) | https://digilog-recruiter-frontend.vercel.app |
| **Candidate portal** | Vercel (`digilog-recruiter-candidates`) | https://digilog-recruiter-candidates.vercel.app |
| **Backend (API + WS)** | Azure VM `vm-seemplify-budget`, PM2 `digilog-backend`, port 5001, behind nginx | https://172-182-227-84.nip.io |
| **Database** | Self-hosted MongoDB on the **same** VM (`digilog` DB) | `mongodb://…@127.0.0.1:27017/digilog` |
| **Redis (BullMQ)** | apt `redis-server` on the **same** VM | `127.0.0.1:6379` |

Vercel scope/team: `project-managers-projects` (`team_KjKB7NzPMvFnmw0h2v2dAF8o`).
A `digilog-recruiter-backend` Vercel project also exists but is **unused/redundant** (Express can't run on serverless) — safe to delete.

---

## Backend — Azure VM

- **VM:** `vm-seemplify-budget` · RG `RG-SEEMPLIFY-BUDGET-WESTUS3` · `westus3` · public IP **`172.182.227.84`** · Ubuntu 22.04.
- **Code:** `/home/seemplify/digilog-backend` (a copy of `digilog-recruiter/backend`; deployed via CI/CD — see below).
- **Process manager:** PM2 process **`digilog-backend`** (runs `server.js` on port **5001**, bound localhost; PM2 startup/systemd persistence enabled).
- **Reverse proxy / TLS:** the VM's **existing nginx** has a vhost `server_name 172-182-227-84.nip.io` → `proxy_pass http://127.0.0.1:5001` with a **Let's Encrypt** cert (auto-renews). WebSocket upgrade enabled. `nip.io` is just the VM's IP with free HTTPS.
- **`.env` (production, on the VM):** `NODE_ENV=production`, `PORT=5001`, `REDIS_HOST=127.0.0.1`, `REDIS_PORT=6379`, `MONGO_URI=mongodb://digilog_app:***@127.0.0.1:27017/digilog?authSource=digilog&replicaSet=rs0&retryWrites=true&w=majority`, plus the ~72 service keys (Azure OpenAI / embeddings / GPT-4o / VoiceLive / Speech, Cloudinary, Nylas, Brevo, JWT, Pinecone, Mem0…). `OIDC_*` / `IDP_*` keys remain but are **unused** (IdP fully removed).

### SSH in
```bash
ssh -i access/azure-budget-vm/id_rsa_azure_budget_vm seemplify@172.182.227.84
```
(Full VM admin details: [`azure-budget-vm/AZURE-BUDGET-VM-ACCESS.md`](azure-budget-vm/AZURE-BUDGET-VM-ACCESS.md).)

### Operate
```bash
pm2 list                              # see digilog-backend status
pm2 logs digilog-backend --lines 50   # logs
pm2 reload digilog-backend            # zero-downtime restart (re-reads .env)
```

---

## Database — self-hosted MongoDB (on the VM)

Moved off MongoDB Atlas because the shared Atlas cluster hit its **500-collection cap**. Now self-hosted on the VM:

- **mongod 7.0**, **single-node replica set `rs0`** (required for the app's transactions), bound to **`127.0.0.1:27017`** only (not internet-exposed), **auth enabled** via keyfile `/etc/mongod.keyfile`.
- **DB:** `digilog`.
- **Users:** `digilogAdmin` (root, `authSource=admin`) and `digilog_app` (`readWrite@digilog`, `authSource=digilog`).
- **Credentials** are stored on the VM at **`/home/seemplify/.mongo-credentials`** (chmod 600) — not committed anywhere.

```bash
# on the VM
PW=$(grep -oP 'digilog_app / \K[0-9a-f]+' ~/.mongo-credentials)
mongosh -u digilog_app -p "$PW" --authenticationDatabase digilog digilog
```

---

## Backend CI/CD — GitHub Actions → VM

- **Workflow:** `.github/workflows/deploy-digilog-backend.yml` (repo `michaelegbo/seemplify`).
- **Trigger:** push to `main` touching `digilog-recruiter/backend/**` (or the workflow file), plus manual `workflow_dispatch`.
- **What it does:** `rsync` `digilog-recruiter/backend/` → `seemplify@172.182.227.84:/home/seemplify/digilog-backend/`, then `npm install --omit=dev` + `pm2 reload digilog-backend` + `pm2 save`.
- **Preserves on the VM:** `.env`, `uploads/`, `node_modules`, logs, `.vercel` (excluded from rsync `--delete`).
- **Secret:** `VM_SSH_KEY` (repo secret) = the admin SSH private key (`access/azure-budget-vm/id_rsa_azure_budget_vm`).
- **Status:** verified working (a manual dispatch reloaded the backend on the VM successfully).

```bash
gh workflow run deploy-digilog-backend.yml --repo michaelegbo/seemplify --ref main   # manual deploy
gh run list --repo michaelegbo/seemplify --workflow=deploy-digilog-backend.yml        # history
```

> The other repo workflows (`deploy-recruiter-backend.yml`, etc.) deploy the **old** apps via **Dokploy** — unrelated to diGiLog.

---

## Frontends — Vercel

- **Projects:** `digilog-recruiter-frontend` (`prj_dn92CAkeUtJmcVK7f9ChAC8Lksl5`) and `digilog-recruiter-candidates` (`prj_YfOmvrswlfXvwDX9Plqpaf4llVqE`).
- **They call the VM backend** (`https://172-182-227-84.nip.io`). Every hardcoded `api.seemplifyai.com` reference was removed from the diGiLog frontend code.
- **Production env vars** (both projects): `NEXT_PUBLIC_API_BASE_URL` / `NEXT_PUBLIC_WS_BASE_URL` (frontend) and `NEXT_PUBLIC_RECRUITER_API_BASE_URL` (candidates) all point at the VM; `NEXT_PUBLIC_IDP_URL` is intentionally empty.
- **Runtime config:** `frontend/public/__runtime_config__.js` (loaded `beforeInteractive`) also points `apiBase`/`wsBase` at the VM. `getRuntimeConfig()` now prefers the **baked env** over this script, so a stale cached copy can't override it.
- **CSP** (`next.config.mjs` `connect-src`) allows the VM origin.

### Deploy the frontend (manual, via Vercel CLI)
```bash
cd digilog-recruiter/frontend
vercel deploy --prod --force -b VERCEL_FORCE_NO_BUILD_CACHE=1 --yes
```
> Use `--force` + `VERCEL_FORCE_NO_BUILD_CACHE=1` — plain redeploys have produced broken 404 builds from a stale cache.

### Setting Vercel env vars
The `vercel env add` CLI has silently stored **empty** values here. **Set env vars via the Vercel REST API** (`POST /v10/projects/{id}/env?...&upsert=true`) and verify with `vercel env pull`.

---

## VM disambiguation

You have three Azure VMs — don't mix them up:

| VM | Region | Public IP | Purpose |
|----|--------|-----------|---------|
| **`vm-seemplify-budget`** | westus3 | **172.182.227.84** | **diGiLog backend lives here** (also hosts the `skyd`/dewinsight project) |
| `seemplify-vm` | westeurope | 4.180.153.209 | Dedicated **Seemplify** VM — **not used by diGiLog** |
| `rmn-vm-prod` | westeurope | 4.180.254.253 | RMN project — unrelated |

- `api.seemplifyai.com` is **Cloudflare-fronted** (separate origin) — **not** this VM.
- `vm-seemplify-budget` is a **shared** box (also runs `skyd`/dewinsight.com with its own Docker apps + GitHub runners). Be **additive** — don't disrupt its nginx vhosts or containers.

---

## Notes / gotchas

- **Browser cache:** `__runtime_config__.js` is cached (`max-age=0, must-revalidate`). After a frontend deploy, **hard-refresh** (Ctrl/Cmd+Shift+R) or use incognito to pick up the new config.
- **No IdP:** org creation, invites, members, roles, ownership transfer are all **local** to the diGiLog backend. Do not reintroduce IdP coupling (`idpService`, `idpOrganizationId` redirects, etc.).
- **Disk:** the VM OS disk runs ~85–87% full — watch it before it gets tight.
- **Cost:** `vm-seemplify-budget` is `Standard_D4s_v5` (4 vCPU / 16 GiB) running 24/7 — not free-tier despite the "budget" name.
