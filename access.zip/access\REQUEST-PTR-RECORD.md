# Request PTR Record from Azure

**Date:** January 13, 2026  
**Priority:** MEDIUM - Improve IP reputation  
**Status:** Ready to implement  
**Estimated Time:** 10-15 minutes (plus Azure approval time)

---

## Problem Identified

Your Azure VM (IP: 4.180.153.209) has no reverse DNS (PTR) record configured.

**Impact:**
- Email providers cannot verify IP ownership via reverse DNS lookup
- Lower IP reputation scores
- Some strict corporate mail servers may reject emails
- Not critical when using Brevo relay, but helps with sender reputation

**Current Setup:**
- VM IP: 4.180.153.209
- Mailcow URL: mail.seemplifyai.com
- Brevo Relay: Already configured (mitigates most issues)

---

## Implementation Steps

### Option A: Request via Azure Portal (Recommended)

**Step 1: Access Azure Portal**
1. Login to Azure Portal:
   ```
   URL: https://portal.azure.com
   Email: your Microsoft account email
   ```

2. Navigate to Virtual Machine:
   - Search for: `seemplify-vm`
   - Click on VM name to open blade

**Step 2: Check for PTR Option**
1. Click: **Networking** (left menu)
2. Click: **Network Interface** link

**Step 3: Look for PTR Request Option**
1. In Network Interface blade, look for:
   - "Reverse DNS" option
   - "Request PTR record" button
   - Or "Advanced DNS configuration" section

**Step 4: If PTR Option Not Found**
1. Click: **Help + Support** (top right)
2. Select: **Create a support request**
3. Fill in request details:
   - **Issue Type:** Network Configuration
   - **Service:** Virtual Machine
   - **Resource:** seemplify-vm (4.180.153.209)
   - **Request Type:** Add PTR record / Configure Reverse DNS
   - **PTR Value:** `mail.seemplifyai.com`
4. Submit support ticket

**Step 5: Submit PTR Request (if available)**
1. If you find PTR configuration option:
   - **PTR Hostname:** `mail.seemplifyai.com`
   - **IP Address:** `4.180.153.209`
   - Click: **Save** or **Apply**
2. Wait for Azure to process (may take 24-72 hours)

---

### Option B: Email Draft for Support Request

If Option A doesn't work, send email to Azure support:

**Email Template:**
```
To: Azure Support (az-network@microsoft.com)
Subject: PTR Record Request for seemplify-vm (4.180.153.209)

Dear Azure Support Team,

I would like to request a PTR (reverse DNS) record for my Azure Virtual Machine.

Details:
- Subscription: [Your subscription ID]
- Resource Group: [Your resource group name]
- VM Name: seemplify-vm
- Public IP: 4.180.153.209
- Requested PTR Hostname: mail.seemplifyai.com

This PTR record is needed for email deliverability and IP reputation purposes.

Please configure the reverse DNS record to map:
  4.180.153.209 → mail.seemplifyai.com

Thank you,
[Your Name]
```

---

## Verification Steps (After Approval)

### Step 1: Check PTR Record Exists
```bash
# Verify PTR is configured (may take 24-72 hours)
nslookup 4.180.153.209

# Expected output:
# 209.153.180.4.in-addr.arpa name = mail.seemplifyai.com
```

**Alternative verification:**
```bash
# Use dig for more detailed check
dig -x 4.180.153.209

# Expected output:
# 209.153.180.4.in-addr.arpa. 100 IN PTR mail.seemplifyai.com
```

### Step 2: Verify Forward DNS Still Works
```bash
# Ensure mail.seemplifyai.com still points to correct IP
nslookup mail.seemplifyai.com

# Expected output:
# mail.seemplifyai.com → 4.180.153.209
```

---

## Subscription Requirements

**PTR Records May Not Be Available For:**
- Free Trial subscriptions
- Some Pay-As-You-Go subscription tiers
- Individual accounts without EA (Enterprise Agreement)

**May Be Available For:**
- Enterprise Agreement (EA) subscriptions
- Microsoft Customer Agreement for enterprise (MCA-E)
- Some Pay-As-You-Go with approval

**If Not Available:**
- Your Brevo relay configuration already handles most reputation issues
- PTR record is optional but helpful
- You can skip this task if subscription doesn't support it

---

## Azure Portal Navigation Help

### Finding Network Settings:
```
Azure Portal
  → Virtual Machines
    → seemplify-vm
      → Networking
        → Network Interface
          → Look for: "Reverse DNS" or "PTR record"
```

### Alternative Path (if Network Interface doesn't show PTR):
```
Azure Portal
  → Resource Groups
    → [Your Resource Group]
      → seemplify-vm
        → Networking
          → Public IP Address
            → Configuration
              → Look for: "Reverse DNS (PTR)" or "DNS settings"
```

---

## Expected Timeline

| Stage | Timeframe | Notes |
|--------|-----------|-------|
| Submit request | Immediate | Today |
| Azure approval | 24-72 hours | Business hours only |
| DNS propagation | 24-48 hours | After approval |
| Reputation improvement | 1-4 weeks | Gradual |

---

## Troubleshooting

### PTR Request Rejected
**Possible Reasons:**
1. Subscription type doesn't support PTR
   - Contact Azure support for upgrade options
2. IP already has PTR from previous VM
   - Check if PTR points to wrong hostname
   - Request PTR update instead of new record
3. IP is dynamic or not static
   - PTR requires static public IP
   - Verify VM has static IP (it should)

### PTR Not Working After Approval
```bash
# Verify PTR is actually configured
nslookup 4.180.153.209

# If no PTR shown:
# 1. Wait longer (DNS propagation takes time)
# 2. Check Azure portal - PTR may be "Pending"
# 3. Verify VM hasn't been deallocated/reallocated (IP may change)
```

### Wrong PTR Hostname Configured
```bash
# If PTR points to wrong hostname
nslookup 4.180.153.209

# Shows: some-old-hostname instead of mail.seemplifyai.com
# Action: Contact Azure support to update PTR record
```

---

## Current Configuration Info

**Azure VM Details (for support request):**
- **Public IP:** 4.180.153.209
- **Hostname:** mail.seemplifyai.com
- **Resource Type:** Virtual Machine
- **Service:** Email Server (Mailcow)

**Brevo Relay (already configured):**
- **SMTP Server:** smtp-relay.brevo.com:587
- **Login:** 93ea9d001@smtp-brevo.com
- **Status:** Active and operational
- **Benefit:** Already provides good IP reputation

---

## References

### Documentation:
- [`access/AZURE-PORT-25-SOLUTION.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/AZURE-PORT-25-SOLUTION.md) - PTR request process
- [`access/SERVER-ACCESS.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/SERVER-ACCESS.md) - Server credentials

### Azure Resources:
- https://learn.microsoft.com/en-us/azure/virtual-network/ip-services/reverse-dns - PTR documentation
- https://docs.microsoft.com/en-us/azure/virtual-network/troubleshoot-outbound-smtp-connectivity - Email infrastructure

---

## Completion Checklist

- [ ] Login to Azure Portal (portal.azure.com)
- [ ] Navigate to seemplify-vm Networking
- [ ] Look for PTR/reverse DNS option
- [ ] Submit PTR request or create support ticket
- [ ] Wait for Azure approval (24-72 hours)
- [ ] Receive confirmation of PTR configuration
- [ ] Verify PTR with nslookup 4.180.153.209
- [ ] Verify result: 209.153.180.4.in-addr.arpa → mail.seemplifyai.com

---

**After completing this task, your Azure VM IP will have proper reverse DNS mapping, improving sender reputation and email deliverability!**

**Final Task:** Test email deliverability with all authentication methods (Task 5)
