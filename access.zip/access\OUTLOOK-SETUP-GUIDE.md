# Outlook Setup Guide - paddie.io Email Accounts

**Date:** January 19, 2026  
**For:** Michael and Ryan - Outlook Desktop & Mobile

---

## 📧 Email Account Details

### Michael
- **Email:** `michael@paddie.io`
- **Password:** (Check credentials document)

### Ryan
- **Email:** `ryan@paddie.io`
- **Password:** (Check credentials document)

### Server Settings (Both Accounts)
- **IMAP Server:** `mail.seemplifyai.com`
- **IMAP Port:** `993` (SSL/TLS)
- **SMTP Server:** `mail.seemplifyai.com`
- **SMTP Port:** `587` (STARTTLS)
- **Username:** Full email address (e.g., `michael@paddie.io`)
- **Password:** Your Mailcow password

---

## 💻 Outlook Desktop (Windows/Mac) Setup

### Method 1: Manual Setup (Recommended)

1. **Open Outlook**
   - Go to **File** → **Add Account** (or **Account Settings** → **Add Account**)

2. **Choose Manual Setup**
   - Select **Manual setup or additional server types**
   - Click **Next**

3. **Select Account Type**
   - Choose **POP or IMAP**
   - Click **Next**

4. **Enter Account Information**
   
   **User Information:**
   - Your Name: `Michael` (or `Ryan`)
   - Email Address: `michael@paddie.io` (or `ryan@paddie.io`)
   
   **Server Information:**
   - Account Type: **IMAP**
   - Incoming mail server: `mail.seemplifyai.com`
   - Outgoing mail server (SMTP): `mail.seemplifyai.com`
   
   **Logon Information:**
   - User Name: `michael@paddie.io` (or `ryan@paddie.io`)
   - Password: Your Mailcow password
   - ✅ Check **Remember password**

5. **Click "More Settings"**

6. **Outgoing Server Tab**
   - ✅ Check **My outgoing server (SMTP) requires authentication**
   - Select **Use same settings as my incoming mail server**

7. **Advanced Tab**
   
   **Incoming Server (IMAP):**
   - Port: `993`
   - Encryption: **SSL/TLS** (or **SSL**)
   - ✅ Check **This server requires an encrypted connection (SSL/TLS)**
   
   **Outgoing Server (SMTP):**
   - Port: `587`
   - Encryption: **STARTTLS** (or **TLS**)
   - ✅ Check **This server requires an encrypted connection**

8. **Click OK** → **Next** → **Finish**

### Method 2: Auto-Discover (May Not Work)

Outlook may try auto-discover, but since we removed Microsoft autodiscover records, it will likely fail. If it does:
- Click **Manual setup**
- Follow Method 1 above

---

## 📱 Outlook Mobile (iOS/Android) Setup

### iOS (iPhone/iPad)

1. **Open Settings App**
   - Go to **Mail** → **Accounts** → **Add Account**

2. **Select Account Type**
   - Choose **Other** (not Outlook.com or Exchange)

3. **Add Mail Account**
   - Name: `Michael` (or `Ryan`)
   - Email: `michael@paddie.io` (or `ryan@paddie.io`)
   - Password: Your Mailcow password
   - Description: `Mailcow` (optional)
   - Click **Next**

4. **Select IMAP**
   - Choose **IMAP** (not POP)

5. **Enter Server Settings**
   
   **Incoming Mail Server:**
   - Host Name: `mail.seemplifyai.com`
   - User Name: `michael@paddie.io` (or `ryan@paddie.io`)
   - Password: Your Mailcow password
   
   **Outgoing Mail Server:**
   - Host Name: `mail.seemplifyai.com`
   - User Name: `michael@paddie.io` (or `ryan@paddie.io`)
   - Password: Your Mailcow password

6. **Click Next** → **Save**

7. **Configure Advanced Settings** (if needed)
   - Go to **Settings** → **Mail** → **Accounts** → Select your account
   - Tap **Advanced**
   - **Incoming Settings:**
     - Use SSL: **ON**
     - Port: `993`
   - **Outgoing Settings:**
     - Use SSL: **ON**
     - Port: `587`
     - Authentication: **Password**

### Android

1. **Open Outlook App**
   - Tap **Get Started** or **Add Account**

2. **Add Account Manually**
   - Tap **Add Account** → **Advanced Setup**
   - Or tap **Skip** if it tries auto-setup, then **Add Account** → **IMAP**

3. **Enter Account Details**
   - Email: `michael@paddie.io` (or `ryan@paddie.io`)
   - Password: Your Mailcow password
   - Tap **Continue** or **Manual Setup**

4. **Enter Server Settings**
   
   **Incoming Server:**
   - IMAP server: `mail.seemplifyai.com`
   - Port: `993`
   - Security: **SSL/TLS** (or **SSL**)
   - Username: `michael@paddie.io` (or `ryan@paddie.io`)
   
   **Outgoing Server:**
   - SMTP server: `mail.seemplifyai.com`
   - Port: `587`
   - Security: **STARTTLS** (or **TLS**)
   - Username: `michael@paddie.io` (or `ryan@paddie.io`)
   - Password: Your Mailcow password

5. **Tap Sign In** or **Done**

---

## ⚙️ Detailed Server Settings Summary

### For Michael (`michael@paddie.io`)

**Incoming Mail (IMAP):**
- Server: `mail.seemplifyai.com`
- Port: `993`
- Encryption: `SSL/TLS`
- Username: `michael@paddie.io`
- Password: (Your Mailcow password)

**Outgoing Mail (SMTP):**
- Server: `mail.seemplifyai.com`
- Port: `587`
- Encryption: `STARTTLS`
- Authentication: Required
- Username: `michael@paddie.io`
- Password: (Your Mailcow password)

### For Ryan (`ryan@paddie.io`)

**Incoming Mail (IMAP):**
- Server: `mail.seemplifyai.com`
- Port: `993`
- Encryption: `SSL/TLS`
- Username: `ryan@paddie.io`
- Password: (Your Mailcow password)

**Outgoing Mail (SMTP):**
- Server: `mail.seemplifyai.com`
- Port: `587`
- Encryption: `STARTTLS`
- Authentication: Required
- Username: `ryan@paddie.io`
- Password: (Your Mailcow password)

---

## 🔧 Troubleshooting

### Common Issues

1. **"Cannot connect to server"**
   - Verify server: `mail.seemplifyai.com`
   - Check ports: IMAP `993`, SMTP `587`
   - Ensure SSL/TLS is enabled

2. **"Authentication failed"**
   - Verify username is full email: `michael@paddie.io` (not just `michael`)
   - Check password is correct
   - Ensure "Require authentication" is enabled for SMTP

3. **"Outgoing mail not sending"**
   - Verify SMTP port is `587` (not `25` or `465`)
   - Check "My outgoing server requires authentication" is enabled
   - Ensure STARTTLS is selected (not SSL for SMTP)

4. **Auto-discover fails**
   - This is expected (we removed Microsoft autodiscover)
   - Use manual setup instead

### Test Connection

After setup, send a test email to yourself to verify:
- ✅ Incoming mail works
- ✅ Outgoing mail works
- ✅ Both servers are accessible

---

## 📅 Calendar Sync (Optional)

**Note:** Outlook desktop/mobile doesn't natively support CalDAV. For calendar sync:

1. **Use SOGo Webmail for Calendar:**
   - Access: https://mail.seemplifyai.com/SOGo/
   - Login and use Calendar tab

2. **Or use a CalDAV client:**
   - iPhone: Use built-in Calendar app with CalDAV
   - Android: Use a CalDAV sync app
   - Desktop: Use Thunderbird with Lightning extension

See `MAILCOW-CALENDAR-GUIDE.md` for calendar setup details.

---

## ✅ Quick Reference Card

### Michael
```
Email: michael@paddie.io
IMAP: mail.seemplifyai.com:993 (SSL)
SMTP: mail.seemplifyai.com:587 (STARTTLS)
```

### Ryan
```
Email: ryan@paddie.io
IMAP: mail.seemplifyai.com:993 (SSL)
SMTP: mail.seemplifyai.com:587 (STARTTLS)
```

---

**Last Updated:** January 19, 2026  
**Status:** ✅ Ready for Setup
