# Server Access & Credentials Guide

**Last Updated:** January 1, 2026  
**Environment:** Production  
**Infrastructure:** Azure VM + Dokploy

---

## 🔐 Quick Access Reference

### Dokploy Dashboard
- **URL:** http://4.180.153.209:3000
- **Email:** admin@seemplifyai.com
- **Password:** Seemplify2026!

### SSH Access
```bash
ssh seemplify@4.180.153.209
```
- **User:** seemplify
- **Host:** 4.180.153.209
- **Port:** 22 (default)

---

## 📍 Infrastructure Details

| Item | Value |
|------|-------|
| **VM IP Address** | 4.180.153.209 |
| **Azure Region** | West Europe |
| **Resource Group** | seemplify-vm-rg |
| **VM Size** | Standard_B2s (2 vCPU, 4 GB RAM) |
| **OS** | Ubuntu 22.04 LTS |
| **Deployment Platform** | Dokploy (self-hosted) |

---

## 🌐 Production URLs

### Frontend Applications
| Application | URL | Status |
|-------------|-----|--------|
| Recruiter | https://app.seemplifyai.com | ✅ Live |
| Leave Management | https://leave.seemplifyai.com | ✅ Live |
| Performance | https://performance.seemplifyai.com | ✅ Live |
| Payroll | https://payroll.seemplifyai.com | ✅ Live |
| Identity Provider / Hub | https://auth.seemplifyai.com | ✅ Live |

### Backend APIs
| Application | URL | Status |
|-------------|-----|--------|
| Recruiter API | https://api.seemplifyai.com | ✅ Live |
| Leave API | https://api-leave.seemplifyai.com | ✅ Live |
| Performance API | https://api-performance.seemplifyai.com | ✅ Live |
| Payroll API | https://api-payroll.seemplifyai.com | ✅ Live |
| AI In Members API | https://api-aiinmembers.seemplifyai.com | ✅ DNS (confirm app env in Dokploy) |

---

## 🔑 Access Credentials

### Dokploy Dashboard
```
URL:      http://4.180.153.209:3000
Email:    admin@seemplifyai.com
Password: Seemplify2026!
```

### SSH Access
```
Host:     4.180.153.209
User:     seemplify
Port:     22
Key:      ~/.ssh/id_rsa (or your configured SSH key)
```

### Azure Access
```
Resource Group: seemplify-vm-rg
Subscription:   [Your Azure Subscription]
Region:         West Europe
```

### Cloudflare DNS
```
Zone:     seemplifyai.com
Zone ID:  bbc142d2d661d64011e2e4becae7a5c3
API Token: s3BUpfG8KqcRoxVgwmyCSqJ3ho3R_ClCEpI4tEXJ
```

---

## 📦 Application Details

### MongoDB Atlas Databases
| Backend | Database Name | Collection |
|---------|---------------|------------|
| Identity Provider | `identity` | Users, Organizations |
| Recruiter | `smart_hr_db` | Candidates, Interviews |
| Leave Management | `leave-management` | Leave Requests |
| Performance | `performance_db` | Reviews, Appraisals |
| Payroll | `payroll_db` | Payroll Records |

**Connection String Pattern:**
```
mongodb+srv://tonyegbo1:IHjykby58BtH5zyC@cluster0.8hdkzxw.mongodb.net/<database>?retryWrites=true&w=majority&appName=Cluster0
```

### Application Ports (Internal)
| Service | Port | Container Port |
|---------|------|----------------|
| Identity Provider | 5008 | 5008 |
| Recruiter Backend | 5001 | 5001 |
| Recruiter Frontend | 5000 | 5000 |
| Leave Backend | 5002 | 5002 |
| Leave Frontend | 5003 | 5003 |
| Performance Backend | 5004 | 5004 |
| Performance Frontend | 5005 | 5005 |
| Payroll Backend | 5006 | 5006 |
| Payroll Frontend | 5007 | 5007 |

---

## 🛠️ Common Operations

### Access Dokploy Dashboard
1. Navigate to: http://4.180.153.209:3000
2. Login with: admin@seemplifyai.com / Seemplify2026!
3. View/Manage all applications

### SSH into Server
```bash
ssh seemplify@4.180.153.209
```

### Check Running Containers
```bash
ssh seemplify@4.180.153.209 "docker ps"
```

### View Application Logs
```bash
ssh seemplify@4.180.153.209 "docker logs <container-name>"
```

### Restart an Application
1. Access Dokploy Dashboard
2. Navigate to the application
3. Click "Deploy" or "Restart"

### Access Docker Services
```bash
# List all containers
docker ps -a

# View Dokploy logs
docker logs dokploy.1.<container-id>

# View Traefik (reverse proxy) logs
docker logs dokploy-traefik
```

---

## 🔐 Security Notes

⚠️ **IMPORTANT SECURITY INFORMATION**

1. **Change Default Passwords:** Consider changing the Dokploy admin password regularly
2. **SSH Keys:** Use SSH key authentication instead of passwords
3. **Firewall:** Only ports 22 (SSH), 80 (HTTP), 443 (HTTPS), and 3000 (Dokploy) are open
4. **SSL/TLS:** All production domains use Let's Encrypt certificates (auto-renewed)
5. **MongoDB:** Database credentials are stored in environment variables in Dokploy

### Recommended: Change Dokploy Admin Password
1. Access Dokploy Dashboard
2. Go to Settings → User Management
3. Change password for admin@seemplifyai.com

---

## 📞 Support & Troubleshooting

### View All Application Status
```bash
ssh seemplify@4.180.153.209 "docker ps --format 'table {{.Names}}\t{{.Status}}'"
```

### Check Application Health
- Access each application URL above
- Check Dokploy dashboard for deployment status
- Review container logs in Dokploy

### Common Issues
- **502 Bad Gateway:** Container may be restarting, wait 1-2 minutes
- **404 on Backend APIs:** Normal - backends don't have root routes, use `/api/*` paths
- **SSL Certificate Issues:** Let's Encrypt auto-renews, check Traefik logs

---

## 🔄 CI/CD

### GitHub Actions
All applications auto-deploy on push to `main` branch:
- **Workflow Files:** `.github/workflows/deploy-*.yml`
- **Trigger:** Push to main branch or manual workflow dispatch
- **Deployment Method:** Dokploy API calls

### Manual Deployment
1. Push code to GitHub main branch, OR
2. Trigger deployment via Dokploy dashboard, OR
3. Use GitHub Actions "Run workflow" manually

---

## 📝 Notes

- All applications run in Docker containers managed by Dokploy
- Traefik handles reverse proxy and SSL termination
- Environment variables are managed in Dokploy dashboard
- Logs can be viewed in Dokploy or via `docker logs`
- Database connections use MongoDB Atlas (cloud-hosted)

---

## 🔗 Related Documentation

- Full deployment guide: `../DOKPLOY-DEPLOYMENT-PLAN.md`
- Scripts: `../scripts/`
- GitHub Actions: `../.github/workflows/`

---

**⚠️ Keep this document secure! It contains sensitive credentials.**
