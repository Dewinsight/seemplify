# Seemplify Chat Admin Credentials

**URL:** https://chat.seemplifyai.com

---

## 🔐 Admin Account Details

**Status:** ✅ Created Successfully (2026-01-30)

The admin account was created via MongoDB direct insertion with proper bcrypt password hashing using Rocket.Chat's bcrypt module.

### Admin Credentials:

```
Full Name: Admin User
Email: michael.egbo@aiinnigeria.com
Username: admin
Password: Admin2026!
User ID: admin_1769772269633
```

**NOTE:** Password verified via bcrypt compareSync - returns TRUE.

### OAuth Configuration:

The OAuth "Login with Seemplify" button is configured with:
- Provider URL: https://auth.seemplifyai.com
- Client ID: rocket-chat
- Client Secret: rocket-chat-seemplify-secret-2026
- Login Style: redirect
- Token sent via: payload (matches IDP's client_secret_post)
- 24 OAuth settings configured in database

**IMPORTANT:** Save this password securely!

### Verification:
- ✅ User created in MongoDB
- ✅ Password properly hashed with bcrypt
- ✅ Admin role assigned
- ✅ Account active
- ✅ Login page accessible at https://chat.seemplifyai.com

---

## 🔧 How Admin Was Created

The admin account was created using the following method:

1. **Generated bcrypt hash** using Rocket.Chat's internal bcrypt module:
   ```bash
   docker compose exec -T rocketchat node -e \
     "const bcrypt = require('/app/bundle/programs/server/npm/node_modules/meteor/accounts-password/node_modules/bcrypt'); \
     console.log(bcrypt.hashSync('Seemplify2026!Admin', 10));"
   ```
   Result: `$2b$10$RVEZRDPUasIqWaQLXPosuOfAkw7h2jCKDaV1OJsmu6CCNRt1WyGs.`

2. **Inserted admin user directly into MongoDB**:
   ```javascript
   db.users.insertOne({
     "_id": "admin-1769763502",
     "createdAt": new Date(),
     "services": {
       "password": {
         "bcrypt": "$2b$10$RVEZRDPUasIqWaQLXPosuOfAkw7h2jCKDaV1OJsmu6CCNRt1WyGs."
       }
     },
     "username": "admin",
     "emails": [{"address": "michael.egbo@aiinnigeria.com", "verified": false}],
     "type": "user",
     "status": "offline",
     "active": true,
     "roles": ["admin"],
     "name": "Michael Egbo",
     "requirePasswordChange": false
   })
   ```

3. **Marked setup wizard as complete**:
   ```javascript
   db.rocketchat_settings.updateOne(
     {_id: "Show_Setup_Wizard"},
     {$set: {value: "completed", valueSource: "processEnvValue"}},
     {upsert: true}
   )
   ```

4. **Restarted Rocket.Chat**:
   ```bash
   docker compose restart rocketchat
   ```

---

## 📋 Setup Instructions

### Option 1: Enable Registration (Recommended)

1. **SSH to Server:**
   ```bash
   ssh seemplify@4.180.153.209
   cd /etc/dokploy/compose/seemplify-rocketchat-*
   ```

2. **Enable Registration:**
   Edit `.env` and set:
   ```bash
   SHOW_SETUP_WIZARD=pending
   # OR remove/comment the line to use default
   ```

3. **Restart Seemplify Chat:**
   ```bash
   docker compose restart rocketchat
   ```

4. **Complete Setup:**
   - Visit https://chat.seemplifyai.com
   - The setup wizard should now appear
   - Fill in the admin details above

### Option 2: Use CLI to Create Admin

```bash
ssh seemplify@4.180.153.209
cd /etc/dokploy/compose/seemplify-rocketchat-*

# Create admin user via Rocket.Chat CLI
docker compose exec rocketchat /app/bundle/programs/server/npm/node_modules/.bin/meteor shell

# In the Meteor shell:
Accounts.createUser({
  username: 'admin',
  email: 'michael.egbo@aiinnigeria.com',
  password: 'Seemplify2026!Admin',
  profile: { name: 'Michael Egbo' }
});

Meteor.users.update(
  { username: 'admin' },
  { $set: { roles: ['admin'] } }
);

# Exit: Ctrl+D
```

### Option 3: Manual Registration Form

If registration is enabled in admin settings:
1. Visit https://chat.seemplifyai.com/home
2. Click "Create an account"
3. Fill in the form with credentials above
4. Click "Join your team"

---

## ✅ Verification Status

| Feature | Status | Notes |
|---------|--------|-------|
| **Site Loading** | ✅ Working | https://chat.seemplifyai.com |
| **Branding** | ✅ Working | Shows "Seemplify Chat" |
| **SSL Certificate** | ✅ Active | Let's Encrypt HTTPS |
| **DNS** | ✅ Working | chat.seemplifyai.com → 4.180.153.209 |
| **Containers** | ✅ Running | MongoDB + Seemplify Chat |
| **Admin Account** | ✅ Created | Username: admin |

---

## 🎯 Next Steps After Admin Setup

1. **Configure OIDC/SSO:**
   - Administration → Settings → OAuth
   - Add Custom OAuth: "Seemplify"
   - Configure with `https://auth.seemplifyai.com`

2. **Test Jitsi Video:**
   - Create a test channel
   - Click 📹 video button
   - Verify Jitsi Meet integration

3. **Test Email:**
   - Administration → Email → SMTP
   - Verify Brevo SMTP settings
   - Send test email

4. **Configure Workspace:**
   - Set organization details
   - Create default channels
   - Configure user permissions

---

**Last Updated:** 2026-01-30  
**Status:** Deployment Complete, Admin Setup Pending
