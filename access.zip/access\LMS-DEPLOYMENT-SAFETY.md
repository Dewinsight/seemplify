# LMS Deployment Safety Guide

**Date:** February 2, 2026  
**Purpose:** Prevent accidental data loss during deployments

---

## ⚠️ INCIDENT SUMMARY

On February 2, 2026, the LMS production data was lost due to the `init.sh` script's factory reset functionality. The script contained code that would delete the entire `/home/frappe/frappe-bench` directory if it existed, causing:

- Loss of original database (`_931a599d893c0e21`)  
- Creation of new empty database (`_abd03c6e65a3520d`)
- Wipe of all LMS data (courses, users, batches, certificates, etc.)

**The old database files still exist in the Docker volume** at:
```
/var/lib/docker/volumes/lms_mariadb-data/_data/_931a599d893c0e21/
```

---

## ✅ WHAT WAS FIXED

**File Modified:** `lms/docker/init.sh`

**Removed dangerous code:**
```bash
# OLD (DANGEROUS - REMOVED)
if [ -d "/home/frappe/frappe-bench/apps/frappe" ]; then
    echo "Removing existing bench for factory reset..."
    rm -rf /home/frappe/frappe-bench  # ← THIS DELETED ALL DATA
fi
```

**Added safety comments:**
```bash
# NEW (SAFE)
# LMS Vanilla Deployment - Safe Initialization
#
# This script initializes the LMS application
# It will NOT delete existing data or configurations
#
# To reinitialize with a fresh database, manually remove:
# 1. The site: bench --site lms.seemplifyai.com drop-site --force
# 2. Then run this script
```

---

## 🔒 SAFETY RULES FOR LMS DEPLOYMENT

### DO ✅

- ✅ Always backup before any deployment
- ✅ Test deployments on staging first
- ✅ Review deployment scripts before running
- ✅ Use environment variables for sensitive data
- ✅ Document all deployment steps
- ✅ Monitor deployments for errors

### DON'T ❌

- ❌ Never run init.sh on production without understanding it
- ❌ Don't use factory reset scripts on live systems
- ❌ Don't assume deployment scripts are safe
- ❌ Don't skip backup verification
- ❌ Don't deploy during business hours without rollback plan

---

## 📋 SAFE DEPLOYMENT PROCEDURE

### Before Deployment

1. **Create database backup**
   ```bash
   # On server, backup current database
   docker exec lms_frappe.1.* mysqldump -h lms_mariadb \
     -u root -p YOUR_PASSWORD \
     _abd03c6e65a3520d > lms-backup-$(date +%Y%m%d).sql
   ```

2. **Backup site config**
   ```bash
   cp /home/frappe/frappe-bench/sites/lms.seemplifyai.com/site_config.json \
     site_config-backup-$(date +%Y%m%d).json
   ```

3. **Document current state**
   ```bash
   # Note current course count, user count, etc.
   bench --site lms.seemplifyai.com execute "print(frappe.db.count('LMS Course'))"
   ```

### During Deployment

1. **Check the deployment script**
   - Read through the entire script
   - Look for rm, delete, or factory reset commands
   - Verify no data destruction commands

2. **Test on staging first**
   - Never deploy directly to production
   - Use a test environment

3. **Monitor the deployment**
   - Watch logs for errors
   - Check database connection status

### After Deployment

1. **Verify data integrity**
   - Check course count matches backup
   - Verify user accounts exist
   - Test critical functionality

2. **Test user workflows**
   - Course enrollment
   - Quiz completion
   - Certificate generation

3. **Rollback if needed**
   ```bash
   # Restore from backup
   docker exec lms_frappe.1.* mysql -h lms_mariadb \
     -u root -p YOUR_PASSWORD \
     _abd03c6e65a3520d < lms-backup-YYYYMMDD.sql
   ```

---

## 🛠️ SAFER ALTERNATIVES TO FACTORY RESET

### Instead of init.sh Factory Reset, Use:

**Option 1: Backup and Restore**
```bash
# 1. Backup current site
bench --site lms.seemplifyai.com backup --with-files

# 2. Drop site (carefully!)
bench --site lms.seemplifyai.com drop-site --force

# 3. Create new site
bench new-site lms.seemplifyai.com

# 4. Restore from backup
bench --site lms.seemplifyai.com restore /path/to/backup.tar
```

**Option 2: Migrate Database Schema Only**
```bash
# Update apps without reinstalling
bench --site lms.seemplifyai.com migrate

# Or migrate specific app
bench --site lms.seemplifyai.com migrate --app lms
```

**Option 3: Use Dokploy Rebuild (Safely)**
- Use Dokploy's rebuild feature with "Preserve Volumes" option checked
- Never use Dokploy to redeploy without understanding the implications

---

## 📝 CHECKLIST FOR FUTURE DEPLOYMENTS

- [ ] Database backup created and verified
- [ ] Site config backup created
- [ ] Current data counts documented
- [ ] Deployment script reviewed for safety
- [ ] Staging environment tested first
- [ ] Rollback plan documented
- [ ] Deployment scheduled during low-traffic period
- [ ] Monitoring in place
- [ ] Post-deployment verification steps planned

---

## 🔧 FILES MODIFIED

| File | Change |
|------|--------|
| `lms/docker/init.sh` | Removed factory reset logic (lines 5-8) |
| `access/LMS-DEPLOYMENT-SAFETY.md` | Created this safety guide |

---

## 📞 EMERGENCY RECOVERY STEPS

If data loss occurs again:

1. **Don't panic** - Docker volumes persist data
2. **Check Docker volumes** for old database files
3. **Identify old database** in `/var/lib/docker/volumes/lms_mariadb-data/_data/`
4. **Attempt recovery** using temporary MariaDB container
5. **Document incident** and improve prevention measures

---

## 🔒 PREVENTION MEASURES IMPLEMENTED

1. ✅ Removed factory reset code from init.sh
2. ✅ Added safety comments to init.sh
3. ✅ Created this documentation
4. ✅ Established backup procedures
5. ✅ Defined safe deployment checklist

---

**Document Created:** February 2, 2026  
**Status:** ✅ Safety Measures Implemented  
**Next Review:** March 2026
