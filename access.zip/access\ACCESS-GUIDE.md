# Service Access Guide

**Comprehensive reference for accessing Seemplify infrastructure services**  
**Last Updated:** February 3, 2026

---

## Overview

This guide provides centralized access information for all four primary services used in the Seemplify infrastructure. Each section contains web access URLs, CLI commands, credential locations, and authentication requirements. Always reference the specific credential documents listed in each section for complete details.

---

## 1. Dokploy Dashboard and API

Dokploy serves as the primary deployment platform for all Seemplify applications, managing containerized services, SSL certificates, and environment configurations through a web dashboard and REST API.

### Web Access

Access the Dokploy dashboard at the following URL using your browser:

| Item | Value |
|------|-------|
| **URL** | http://4.180.153.209:3000 |
| **Email** | admin@seemplifyai.com |
| **Password** | See DOKPLOY-CREDENTIALS.md |
| **Protocol** | HTTP (not HTTPS for local access) |

The dashboard provides real-time monitoring of all applications, deployment controls, log aggregation, and environment variable management. After logging in, you can view all production and development applications, restart containers, update configurations, and monitor resource utilization.

### API Access

For automated deployments and CI/CD integrations, use the Dokploy REST API:

| Item | Value |
|------|-------|
| **Base URL** | http://4.180.153.209:3000/api |
| **Authentication** | x-api-key header |
| **API Token** | See DOKPLOY-API-CREDENTIALS-COMPLETE.md |

Deploy an application using curl:

```bash
curl -X POST "http://4.180.153.209:3000/api/application.deploy" \
  -H "x-api-key: $DOKPLOY_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"applicationId": "tPMolDg5OEdQUBZ4MKMFh"}'
```

List all applications:

```bash
curl -X GET "http://4.180.153.209:3000/api/application.all" \
  -H "x-api-key: $DOKPLOY_TOKEN"
```

### Credential Locations

All Dokploy credentials are documented in the following files within the access directory:

| Document | Contents |
|----------|----------|
| DOKPLOY-CREDENTIALS.md | Dashboard login email and password |
| DOKPLOY-API-CREDENTIALS-COMPLETE.md | API keys, application IDs, project information |
| CREDENTIALS-INDEX.md | Master index of all Dokploy credentials |

### What You Can Do

From the Dokploy dashboard, you can view application status across all deployed services including identity-provider, recruiter-backend, recruiter-frontend, leave-management, performance, payroll, and marketing-site. You can restart individual applications, trigger new deployments, view real-time logs for troubleshooting, configure environment variables for each service, manage custom domains and SSL certificates, monitor CPU, memory, and network usage, and access the terminal for any container.

---

## 2. Cloudflare DNS Management

Cloudflare manages DNS records for the seemplifyai.com domain zone, providing DNS resolution, DNSSEC, and protection against DDoS attacks. Access is available through both the web dashboard and API.

### Web Access

Log into the Cloudflare dashboard using your web browser:

| Item | Value |
|------|-------|
| **URL** | https://dash.cloudflare.com |
| **Email** | Your Cloudflare account email |
| **Password** | Your Cloudflare account password |
| **MFA** | May be required depending on account settings |

After logging in, select the zone you need (`seemplifyai.com`, `aiinnigeria.com`, etc.) from your account overview to access DNS records, security settings, SSL/TLS configuration, and analytics.

### Zone Information

The API token in `SERVER-ACCESS.md` can manage DNS on **multiple** zones in this account. Use the correct zone ID per domain:

| Zone name | Zone ID | Notes |
|-----------|---------|--------|
| **seemplifyai.com** | `bbc142d2d661d64011e2e4becae7a5c3` | Primary Seemplify app hostnames |
| **aiinnigeria.com** | `25e5c8be7e4c31cbc39619cc3f1c223d` | Jetstone / Akwa Ibom white-label (`jetstone.aiinnigeria.com`, `akwaibom.aiinnigeria.com`, etc.) |

**Important:** `ACCESS-GUIDE` examples that use only the seemplifyai.com zone ID must be copied with the right zone when editing `aiinnigeria.com` DNS.

### API Access

For programmatic DNS management, use the Cloudflare API:

| Item | Value |
|------|-------|
| **API Endpoint** | https://api.cloudflare.com/client/v4 |
| **Authentication** | Authorization: Bearer <API_TOKEN> |
| **API Token** | See credential documents below |

List DNS records:

```bash
curl -X GET "https://api.cloudflare.com/client/v4/zones/bbc142d2d661d64011e2e4becae7a5c3/dns_records" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json"
```

Update an existing DNS record:

```bash
curl -X PUT "https://api.cloudflare.com/client/v4/zones/bbc142d2d661d64011e2e4becae7a5c3/dns_records/<RECORD_ID>" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"type":"TXT","name":"@","content":"v=spf1 mx include:spf.brevo.com -all","ttl":1}'
```

### Credential Locations

Cloudflare credentials may be documented in the following locations. Check CREDENTIALS-INDEX.md first:

| Document | Contents |
|----------|----------|
| CREDENTIALS-INDEX.md | Master index with Cloudflare credential location |
| CLOUDFLARE-API-ISSUE.md | Known API token issues and workarounds |
| SERVER-ACCESS.md | Zone ID and API token references |

Note: If the API token is expired or invalid, you must generate a new token through the Cloudflare dashboard. Navigate to My Profile, then API Tokens, and create a new token with Zone DNS Edit permissions for the seemplifyai.com zone.

### DNS Record Types Managed

The following record types are configured for the Seemplify infrastructure: A records map production domains to the Azure VM IP address, CNAME records alias subdomains to primary domains, TXT records contain SPF and DMARC authentication configurations, MX records route email to the mail server, and SRV records specify service locations for various protocols.

---

## 3. Azure Virtual Machine

The Azure VM hosts the Dokploy deployment platform and all containerized applications. Access is available via SSH for command-line management and through the Azure portal for infrastructure administration.

### SSH Access

Connect to the VM using SSH with the following parameters:

| Item | Value |
|------|-------|
| **Host** | 4.180.153.209 |
| **Port** | 22 |
| **Username** | seemplify |
| **Authentication** | SSH private key |
| **Key Path** | access/id_rsa or ~/.ssh/id_rsa |

Connect using the command:

```bash
ssh -i ~/.ssh/id_rsa seemplify@4.180.153.209
```

Or with a specific key file:

```bash
ssh -i C:\Users\Michael\Documents\GitHub\seemplify\access\id_rsa seemplify@4.180.153.209
```

### Azure Portal Access

Manage the virtual machine infrastructure through the Azure portal:

| Item | Value |
|------|-------|
| **Portal URL** | https://portal.azure.com |
| **Subscription** | Your Azure subscription |
| **Resource Group** | seemplify-vm-rg |
| **VM Name** | seemplify-vm |

From the Azure portal, you can start and stop the virtual machine, view monitoring metrics and diagnostics, configure network security groups, manage disk storage, review activity logs and audit history, and access the serial console for recovery scenarios.

### Credential Locations

Azure VM access credentials are documented in:

| Document | Contents |
|----------|----------|
| SERVER-ACCESS.md | SSH credentials, VM details, common operations |
| CREDENTIALS-INDEX.md | Master index with server credential references |

### Common SSH Operations

View running Docker containers:

```bash
ssh seemplify@4.180.153.209 "docker ps"
```

View application logs for a specific container:

```bash
ssh seemplify@4.180.153.209 "docker logs <container-name>"
```

Check system resource usage:

```bash
ssh seemplify@4.180.153.209 "docker stats --no-stream"
```

Restart the Dokploy service:

```bash
ssh seemplify@4.180.153.209 "docker restart dokploy"
```

### VM Specifications

| Resource | Specification |
|----------|---------------|
| **VM Size** | Standard_B2s |
| **vCPU** | 2 |
| **RAM** | 4 GB |
| **OS** | Ubuntu 22.04 LTS |
| **Region** | West Europe |

---

## 4. GitHub Repository

The GitHub repository hosts all Seemplify source code and CI/CD workflows. Access is available through the web interface for repository management and the GitHub CLI for automation.

### Web Access

Access the Seemplify GitHub repository through your web browser:

| Item | Value |
|------|-------|
| **Repository URL** | https://github.com/michaelegbo/seemplify |
| **Organization** | michaelegbo |
| **Repository** | seemplify |
| **Branches** | main (production), dev (development) |

The web interface provides access to source code browsing, pull request management, issue tracking, commit history, branch management, and release creation.

### GitHub CLI Access

Install and authenticate the GitHub CLI for command-line operations:

**Installation (Windows PowerShell):**

```powershell
winget install --id GitHub.cli
```

**Authentication:**

```bash
gh auth login
```

Follow the prompts to authenticate with your GitHub account. You can authenticate via browser or personal access token.

### Repository Operations

Clone the repository:

```bash
gh repo clone michaelegbo/seemplify
```

Or using git directly:

```bash
git clone https://github.com/michaelegbo/seemplify.git
```

View repository contents:

```bash
gh repo view --web
```

List branches:

```bash
gh repo view michaelegbo/seemplify --branch main --json name,defaultBranchRef
```

### GitHub Actions and Secrets

Configure secrets for automated deployments:

| Secret Name | Purpose | Where to Set |
|-------------|---------|--------------|
| DOKPLOY_URL | Dokploy server URL | Repo Settings → Secrets and variables → Actions |
| DOKPLOY_TOKEN | Dokploy API token | Repo Settings → Secrets and variables → Actions |
| IDENTITY_PROVIDER_APP_ID | Production app ID | Repo Settings → Secrets and variables → Actions |
| *_APP_ID | Production application IDs | Repo Settings → Secrets and variables → Actions |
| *_DEV_APP_ID | Development application IDs | Repo Settings → Secrets and variables → Actions |

Set a secret using the CLI:

```bash
gh secret set DOKPLOY_TOKEN --body "github-actions-2026yJfCpQwusWxkVlwhfbFDhkyLzLZrJfEBhBSBcRdgaYfDpKktAiCeJVexVmhfcEeh"
```

List all configured secrets:

```bash
gh secret list
```

### Credential Locations

GitHub access and secrets configuration are documented in:

| Document | Contents |
|----------|----------|
| GITHUB-SECRETS-SETUP-GUIDE.md | Complete GitHub Actions secrets setup guide |
| CREDENTIALS-INDEX.md | Master index with GitHub secret references |
| GITHUB-ACTIONS-CONFIG.md | GitHub Actions workflow configuration |

### Workflow Access

View and trigger GitHub Actions workflows:

| Item | URL |
|------|-----|
| **Actions Dashboard** | https://github.com/michaelegbo/seemplify/actions |
| **Deploy Workflows** | https://github.com/michaelegbo/seemplify/actions?q=deploy |

Trigger a workflow manually:

```bash
gh workflow run deploy-recruiter-backend.yml -f branch=main
```

View workflow run status:

```bash
gh run list --workflow deploy-recruiter-backend.yml
```

---

## Quick Reference Card

Use this condensed reference for daily operations:

### Access All Services

| Service | URL | CLI Command |
|---------|-----|-------------|
| Dokploy Dashboard | http://4.180.153.209:3000 | N/A |
| Cloudflare | https://dash.cloudflare.com | N/A |
| Azure VM | N/A | ssh seemplify@4.180.153.209 |
| GitHub | https://github.com/michaelegbo/seemplify | gh auth login |

### Credential Documents

| Document | Use When |
|----------|----------|
| CREDENTIALS-INDEX.md | Finding any credential location |
| DOKPLOY-CREDENTIALS.md | Dokploy dashboard password |
| DOKPLOY-API-CREDENTIALS-COMPLETE.md | API keys and application IDs |
| SERVER-ACCESS.md | SSH and Azure VM access |
| GITHUB-SECRETS-SETUP-GUIDE.md | GitHub Actions secrets |
| CLOUDFLARE-API-ISSUE.md | DNS management issues |

### Common Commands

Deploy an application:

```bash
curl -X POST "http://4.180.153.209:3000/api/application.deploy" \
  -H "x-api-key: $DOKPLOY_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"applicationId": "RECRUITER_BACKEND_APP_ID"}'
```

SSH into the server:

```bash
ssh seemplify@4.180.153.209
```

List Docker containers:

```bash
ssh seemplify@4.180.153.209 "docker ps --format 'table {{.Names}}\t{{.Status}}'"
```

Trigger GitHub workflow:

```bash
gh workflow run deploy-recruiter-backend.yml -f branch=main
```

---

## Security Notes

Always follow these security practices when accessing Seemplify infrastructure. Never share credentials, API keys, or SSH keys through insecure channels. Rotate API tokens periodically, especially if they may have been compromised. Use the principle of least privilege when granting access to team members. Enable multi-factor authentication on all cloud service accounts. Keep this access documentation secure and never commit it to public repositories. The access directory is gitignored for this reason. Audit access logs regularly to detect any unauthorized activity.

---

## Troubleshooting Access Issues

If you cannot access a service, follow these troubleshooting steps:

For Dokploy dashboard issues, verify the VM is running by pinging 4.180.153.209, confirm port 3000 is accessible and not blocked by firewall, check that the Dokploy service is running via SSH, and review container logs with the command ssh seemplify@4.180.153.209 "docker logs dokploy".

For Cloudflare API issues, verify your API token has not expired, ensure the token has Zone DNS Edit permissions, check you are using the correct **Zone ID** for the domain (see Zone Information above: `seemplifyai.com` vs `aiinnigeria.com`), and fall back to manual updates through the dashboard if the API remains unavailable.

For SSH connection issues, verify your SSH key is correctly configured and added to ssh-agent, confirm the seemplify user exists on the VM, check that port 22 is open and not blocked, and verify the VM is running through the Azure portal.

For GitHub Actions failures, confirm all required secrets are set in repository settings, verify the DOKPLOY_TOKEN has not expired, check that application IDs match current Dokploy configuration, and review workflow logs for specific error messages.

---

## Related Documentation

The following documents provide additional context and operational guidance:

| Document | Purpose |
|----------|---------|
| CREDENTIALS-INDEX.md | Master index of all credentials |
| DEV-PROD-DEPLOYMENT-WORKFLOW.md | CI/CD deployment process |
| OIDC-DEV-COMPLETE.md | Authentication configuration |
| IDP-CRITICAL-RULES.md | Identity provider security rules |

---

*For questions or issues with access documentation, refer to the CREDENTIALS-INDEX.md master index or contact the infrastructure administrator.*
