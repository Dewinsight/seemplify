# Dokploy SSH Deploy Key - experienments2

**Purpose:** Deploy key for GitHub repository (used by Dokploy)

**Created:** 2026-02-28

---

## Private Key

```
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACD2qhlKViHpZyL5gSmT3vkgXofoHtJc3y7RxcmupXRc8AAAAKBK3zN+St8z
fgAAAAtzc2gtZWQyNTUxOQAAACD2qhlKViHpZyL5gSmT3vkgXofoHtJc3y7RxcmupXRc8A
AAAEDxwvjNh7HLCRVdYoUnc/Uk9Y1tFefUG2fHg1xR64+uwfaqGUpWIelnIvmBKZPe+SBe
h+ge0lzfLtHFya6ldFzwAAAAFmRvbmtwbHktZXhwZXJpZW50czIBAgMEBQYH
-----END OPENSSH PRIVATE KEY-----
```

## Public Key

```
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPaqGUpWIelnIvmBKZPe+SBeh+ge0lzfLtHFya6ldFzw experienments2-deploy
```

## Usage in Dokploy

- **Key Name:** `experienments2-deploy`
- **Key ID in DB:** `2246PJCMJx9UCP3rRuB6b` (if already added)
- **GitHub Repo:** `michaelegbo/experienments2`

---

## How to Add to Dokploy

1. Add public key to GitHub repo as Deploy Key
2. Add private key to Dokploy via:
   - UI: Settings > SSH Keys > Add Key
   - Or insert into `sshKey` table in database with `sshKeyId`
3. Link SSH key to application via `customGitSSHKeyId` field
