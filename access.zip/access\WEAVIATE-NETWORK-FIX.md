# Weaviate Network Connection Fix - Deployment Guide

**Problem:** Backend cannot connect to Weaviate due to Docker network isolation
**Solution:** Connect Weaviate to `dokploy-network` so backend can reach it

---

## 🚨 Issue Description

### Error
```
❌ Error storing candidate 6957658dfcfe21bcd3fed046: fetch failed
Error: getaddrinfo ENOTFOUND weaviate
```

### Root Cause
- Weaviate container was on `weaviate_default` network
- Backend container is on `dokploy-network` network
- Docker containers cannot communicate across different networks by default

---

## ✅ Immediate Fix

### Run This Command
```bash
ssh seemplify@4.180.153.209 "docker network connect dokploy-network weaviate"
```

### Verify It Works
```bash
ssh seemplify@4.180.153.209 "docker exec recruiter-backend-... node scripts/setupWeaviate.js"
```

---

## 🔄 Automated Fix for Deployments

### Method 1: Post-Deployment Script (Recommended)

Copy the deployment script to the server and run it after each deployment:

```bash
# Copy script to server
scp recruiter/backend/deploy-with-weaviate-network.sh seemplify@4.180.153.209:/tmp/

# Run after deployment
ssh seemplify@4.180.153.209 "bash /tmp/deploy-with-weaviate-network.sh"
```

This script will:
1. ✅ Find the recruiter backend container
2. ✅ Verify Weaviate is running
3. ✅ Connect Weaviate to dokploy-network
4. ✅ Verify connectivity
5. ✅ Test backend can reach Weaviate

### Method 2: Manual Network Connection

After each deployment or container restart, run:

```bash
ssh seemplify@4.180.153.209 "docker network connect dokploy-network weaviate"
```

---

## 🎯 Permanent Solution (Future)

### Deploy Weaviate via Dokploy Docker Compose

Create a Docker Compose file for Weaviate that includes network configuration:

```yaml
# docker-compose.weaviate.yml
version: '3.8'

services:
  weaviate:
    image: semitechnologies/weaviate:1.24.0
    container_name: weaviate
    restart: unless-stopped
    networks:
      - dokploy-network
    ports:
      - "8080:8080"
      - "50051:50051"
    environment:
      AUTHENTICATION_APIKEY_ENABLED: "true"
      AUTHENTICATION_APIKEY_USERS: "seemplify-admin"
      AUTHENTICATION_APIKEY_ALLOWED_KEYS: "${WEAVIATE_API_KEY}"
      AUTHENTICATION_ANONYMOUS_ACCESS_ENABLED: "false"
      DEFAULT_VECTORIZER_MODULE: "none"
      PERSISTENCE_DATA_PATH: "/var/lib/weaviate"
      CLUSTER_HOSTNAME: "node1"
      ENABLE_MODULES: ""
    volumes:
      - weaviate_data:/var/lib/weaviate

networks:
  dokploy-network:
    external: true

volumes:
  weaviate_data:
    driver: local
```

Then deploy via Dokploy's Docker Compose feature.

---

## 📋 Current Configuration

### Weaviate Container
```bash
Container: weaviate
Image: semitechnologies/weaviate:1.24.0
Networks:
  - dokploy-network (10.0.1.114) ← Connected after fix
  - weaviate_default (172.19.0.2)
Ports:
  - 0.0.0.0:8080→8080/tcp
  - 0.0.0.0:50051→50051/tcp
```

### Backend Environment
```env
WEAVIATE_HOST=weaviate:8080
WEAVIATE_SCHEME=http
WEAVIATE_API_KEY=lJAiU5kO0QcSLZYxfzpr1E9dD8NRHFMV
USE_WEAVIATE=true
```

---

## 🔍 Verification Commands

### Check Network Connection
```bash
# Check if Weaviate is on dokploy-network
ssh seemplify@4.180.153.209 "docker network inspect dokploy-network | grep weaviate"

# Test backend can resolve weaviate hostname
ssh seemplify@4.180.153.209 "docker exec recruiter-backend-... ping -c 2 weaviate"
```

### Test Weaviate Connection
```bash
# Run schema setup
ssh seemplify@4.180.153.209 "docker exec recruiter-backend-... node scripts/setupWeaviate.js"

# Check stats
ssh seemplify@4.180.153.209 "docker exec recruiter-backend-... node -e \"
const weaviateService = require('./services/weaviateService');
(async () => {
  const stats = await weaviateService.getStats();
  console.log('Stats:', stats);
})();
\""
```

### Monitor for Errors
```bash
# Watch for Weaviate errors
ssh seemplify@4.180.153.209 "docker logs recruiter-backend-... -f | grep -i weaviate"

# Check recent errors
ssh seemplify@4.180.153.209 "docker logs recruiter-backend-... --tail 100 | grep 'ENOTFOUND'"
```

---

## 📝 Deployment Checklist

When deploying recruiter backend:

- [ ] Deploy backend via Dokploy
- [ ] Run `deploy-with-weaviate-network.sh` script
- [ ] Verify Weaviate is on `dokploy-network`
- [ ] Run `setupWeaviate.js` to verify schemas
- [ ] Check backend logs for Weaviate connection
- [ ] Test embedding storage with `test-weaviate-storage.js`
- [ ] Monitor for 30 minutes for errors

---

## 🐛 Troubleshooting

### Error: "ENOTFOUND weaviate"
**Cause:** Backend can't resolve `weaviate:8080` hostname
**Fix:** `docker network connect dokploy-network weaviate`

### Error: "fetch failed"
**Cause:** Network connectivity issue between backend and Weaviate
**Fix:** Verify both containers are on same network

### Error: "401 Unauthorized"
**Cause:** Missing or incorrect API key
**Fix:** Check `WEAVIATE_API_KEY` environment variable

### Error persists after restart
**Cause:** Network connection was manual, not permanent
**Fix:** Run `deploy-with-weaviate-network.sh` after each restart

---

## 📞 Support

### Quick Reference

```bash
# Connect network (temporary)
docker network connect dokploy-network weaviate

# Check connection
docker network inspect dokploy-network | grep weaviate

# Disconnect network
docker network disconnect dokploy-network weaviate

# View Weaviate logs
docker logs weaviate --tail 50

# View backend logs
docker logs recruiter-backend-... --tail 100 | grep Weaviate
```

---

**Last Updated:** January 2, 2026
**Status:** ✅ Network Connection Working
**Required Action:** Run `deploy-with-weaviate-network.sh` after each deployment
