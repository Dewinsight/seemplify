# Azure budget VM — step-by-step SSH access

This guide walks through **exactly** how **`seemplify`** (primary admin) and **`developer`** connect to the Linux VM using **SSH keys only** (no password login). Commands use **real private key filenames** (`id_rsa_azure_budget_vm`, `id_ed25519_budget_vm_developer`) and **full paths** where helpful. **Windows** examples use this repo clone: `C:\Users\Michael\Documents\GitHub\seemplify` — change that prefix if your clone lives elsewhere. **macOS/Linux** examples use `$HOME/Documents/GitHub/seemplify` or `~/Documents/GitHub/seemplify` the same way.

**Current server (verify in [AZURE-BUDGET-VM-ACCESS.md](./AZURE-BUDGET-VM-ACCESS.md) if anything fails):**

| Item | Value |
|------|--------|
| **Host (IPv4)** | `172.182.227.84` |
| **Port** | `22` |
| **OS** | Ubuntu 22.04 LTS |

### Copy-paste `ssh` commands (private key **file paths** — not key contents)

These are the **exact** commands to run after OpenSSH is installed. They pass the **private key files** with `-i`. (Never put the *contents* of a private key on the command line.)

**Windows (PowerShell)** — default clone location for this repo; change the path if your `seemplify` folder is elsewhere:

```powershell
ssh -i C:\Users\Michael\Documents\GitHub\seemplify\access\azure-budget-vm\id_rsa_azure_budget_vm seemplify@172.182.227.84
```

```powershell
ssh -i C:\Users\Michael\Documents\GitHub\seemplify\access\azure-budget-vm\id_ed25519_budget_vm_developer developer@172.182.227.84
```

**macOS / Linux** — if the repo is at `~/Documents/GitHub/seemplify` (run `chmod 600` on each private key once first — see §3.2 / §4.2):

```bash
ssh -i "$HOME/Documents/GitHub/seemplify/access/azure-budget-vm/id_rsa_azure_budget_vm" seemplify@172.182.227.84
```

```bash
ssh -i "$HOME/Documents/GitHub/seemplify/access/azure-budget-vm/id_ed25519_budget_vm_developer" developer@172.182.227.84
```

---

## 1. Which account should I use?

| You are… | Linux username | Private key file (name) | Key type |
|----------|----------------|---------------------------|----------|
| Subscription / machine owner (full admin + Azure) | **`seemplify`** | `id_rsa_azure_budget_vm` | RSA |
| Developer (OS admin via `sudo`; **no** Azure portal by default) | **`developer`** | `id_ed25519_budget_vm_developer` | Ed25519 |

**Rules:**

- SSH always uses **username + matching private key**. Wrong user or wrong key → “Permission denied”.
- **Never** share your **private** key (no `.pub` suffix). The `.pub` file is public and goes on servers; the file **without** `.pub` stays secret.
- Both accounts can run **`sudo`** on the VM after login (passwordless). You do **not** SSH as `root`; use `sudo -i` if you need a root shell.

---

## 2. Prerequisites (everyone)

### 2.1 Confirm you have an SSH client

- **Windows 10/11:** OpenSSH is usually installed. Open **PowerShell** or **Command Prompt** and run:

  ```powershell
  ssh -V
  ```

  You should see a version line (e.g. `OpenSSH_for_Windows_...`). If the command is missing, install **Optional feature → OpenSSH Client** in Windows Settings, or use **Git Bash** (includes `ssh`).

- **macOS:** Terminal includes `ssh`. Run `ssh -V`.

- **Linux:** Install `openssh-client` if needed (`ssh -V`).

### 2.2 Confirm you have the correct private key file

From the **repository root** (`seemplify` folder), these paths should exist on the **owner’s** machine (or wherever you copied keys securely):

| Role | Private key file | Typical full path (Windows, this repo) |
|------|------------------|----------------------------------------|
| `seemplify` | `id_rsa_azure_budget_vm` | `C:\Users\Michael\Documents\GitHub\seemplify\access\azure-budget-vm\id_rsa_azure_budget_vm` |
| `developer` | `id_ed25519_budget_vm_developer` | `C:\Users\Michael\Documents\GitHub\seemplify\access\azure-budget-vm\id_ed25519_budget_vm_developer` |

Repo-relative (after `cd` to repo root): `access\azure-budget-vm\id_rsa_azure_budget_vm` and `access\azure-budget-vm\id_ed25519_budget_vm_developer`.

Developers normally receive **`id_ed25519_budget_vm_developer`** (no `.pub`) via a **password manager or secure transfer**—not email in plain text. If they save it in another folder, change only the path after `-i` in the `ssh` command.

### 2.3 Confirm the VM is running

If SSH times out, the VM may be **stopped/deallocated** in Azure. Someone with Azure access must **start** the VM (portal or `az vm start`). See [AZURE-BUDGET-VM-ACCESS.md](./AZURE-BUDGET-VM-ACCESS.md).

### 2.4 Network

Port **22** must be allowed from your network (office, home, VPN). The Azure NSG is open to the world for SSH by default; if you still cannot connect, check local firewall or ISP blocking.

---

## 3. Step-by-step: `seemplify` (primary admin)

Use this when you are the person who has the **RSA** admin key and should use the **Azure-created** Linux user.

### 3.1 Windows (PowerShell)

1. Open **PowerShell**.

2. **Option A — one command from anywhere** (full path to the **RSA private key**):

   ```powershell
   ssh -i C:\Users\Michael\Documents\GitHub\seemplify\access\azure-budget-vm\id_rsa_azure_budget_vm seemplify@172.182.227.84
   ```

3. **Option B — from repo root** (relative path to the same private key):

   ```powershell
   cd C:\Users\Michael\Documents\GitHub\seemplify
   ```

   ```powershell
   ssh -i .\access\azure-budget-vm\id_rsa_azure_budget_vm seemplify@172.182.227.84
   ```

4. (Optional) Confirm the private key file exists:

   ```powershell
   Get-Item C:\Users\Michael\Documents\GitHub\seemplify\access\azure-budget-vm\id_rsa_azure_budget_vm
   ```

5. **First time only:** you may see:

   ```text
   Are you sure you want to continue connecting (yes/no/[fingerprint])?
   ```

   Type **`yes`** and press Enter if you trust this server (or compare the fingerprint with your admin if you published one).

6. You should see a shell prompt for **`seemplify`** on **`vm-seemplify-budget`**.

7. Verify identity and sudo:

   ```bash
   whoami
   sudo whoami
   ```

   The second command should print **`root`** without asking for a password.

8. To disconnect:

   ```bash
   exit
   ```

### 3.2 macOS or Linux (Terminal)

1. Open **Terminal**.

2. **Restrict permissions** on the **RSA private key** once (SSH refuses loose permissions):

   ```bash
   chmod 600 "$HOME/Documents/GitHub/seemplify/access/azure-budget-vm/id_rsa_azure_budget_vm"
   ```

3. **Option A — one command** (full path to private key; adjust if your clone is not under `~/Documents/GitHub/seemplify`):

   ```bash
   ssh -i "$HOME/Documents/GitHub/seemplify/access/azure-budget-vm/id_rsa_azure_budget_vm" seemplify@172.182.227.84
   ```

4. **Option B — from repo root:**

   ```bash
   cd ~/Documents/GitHub/seemplify
   chmod 600 access/azure-budget-vm/id_rsa_azure_budget_vm
   ssh -i access/azure-budget-vm/id_rsa_azure_budget_vm seemplify@172.182.227.84
   ```

5. On first connect, accept the host key with **`yes`** if appropriate (same as Windows).

6. Run `whoami` and `sudo whoami` as above; then `exit` to leave.

---

## 4. Step-by-step: `developer`

Use the **Ed25519** key. Steps mirror `seemplify`; only the **username**, **key path**, and **filename** change.

### 4.1 Windows (PowerShell)

1. Open **PowerShell**.

2. **Option A — one command from anywhere** (full path to the **Ed25519 private key**):

   ```powershell
   ssh -i C:\Users\Michael\Documents\GitHub\seemplify\access\azure-budget-vm\id_ed25519_budget_vm_developer developer@172.182.227.84
   ```

3. **Option B — from repo root:**

   ```powershell
   cd C:\Users\Michael\Documents\GitHub\seemplify
   ssh -i .\access\azure-budget-vm\id_ed25519_budget_vm_developer developer@172.182.227.84
   ```

4. If the developer key was saved somewhere else, only change the path after `-i`, for example:

   ```powershell
   ssh -i C:\secure-keys\id_ed25519_budget_vm_developer developer@172.182.227.84
   ```

5. First-time host key: type **`yes`** if you trust the server.

6. Verify:

   ```bash
   whoami
   groups
   sudo whoami
   ```

   You should see **`developer`**, group **`sudo`**, and **`root`** from `sudo whoami`.

7. `exit` to disconnect.

### 4.2 macOS or Linux

1. **Fix permissions** on the **Ed25519 private key** once:

   ```bash
   chmod 600 "$HOME/Documents/GitHub/seemplify/access/azure-budget-vm/id_ed25519_budget_vm_developer"
   ```

2. **Option A — one command** (full path; adjust if your clone path differs):

   ```bash
   ssh -i "$HOME/Documents/GitHub/seemplify/access/azure-budget-vm/id_ed25519_budget_vm_developer" developer@172.182.227.84
   ```

3. **Option B — from repo root:**

   ```bash
   cd ~/Documents/GitHub/seemplify
   chmod 600 access/azure-budget-vm/id_ed25519_budget_vm_developer
   ssh -i access/azure-budget-vm/id_ed25519_budget_vm_developer developer@172.182.227.84
   ```

4. Accept host key on first connect if appropriate.

5. Run `whoami`, `groups`, `sudo whoami`; then `exit`.

---

## 5. Optional: shorter commands with SSH config

After keys work once, you can add a **host alias** so you do not type `-i` every time.

**macOS / Linux:** edit `~/.ssh/config` (create if missing; `chmod 600 ~/.ssh/config`).

```sshconfig
Host budget-vm-seemplify
    HostName 172.182.227.84
    User seemplify
    IdentityFile ~/Documents/GitHub/seemplify/access/azure-budget-vm/id_rsa_azure_budget_vm

Host budget-vm-dev
    HostName 172.182.227.84
    User developer
    IdentityFile ~/Documents/GitHub/seemplify/access/azure-budget-vm/id_ed25519_budget_vm_developer
```

Then:

```bash
ssh budget-vm-seemplify
# or
ssh budget-vm-dev
```

**Windows:** edit `C:\Users\Michael\.ssh\config` (create folder/file if needed). Use forward slashes in `IdentityFile`:

```sshconfig
Host budget-vm-seemplify
    HostName 172.182.227.84
    User seemplify
    IdentityFile C:/Users/Michael/Documents/GitHub/seemplify/access/azure-budget-vm/id_rsa_azure_budget_vm

Host budget-vm-dev
    HostName 172.182.227.84
    User developer
    IdentityFile C:/Users/Michael/Documents/GitHub/seemplify/access/azure-budget-vm/id_ed25519_budget_vm_developer
```

Then: `ssh budget-vm-seemplify` or `ssh budget-vm-dev`.

If your Windows username or clone path differs, change only the `IdentityFile` lines.

---

## 6. Common problems

| Symptom | What to check |
|--------|----------------|
| **Permission denied (publickey)** | Wrong **username** (`seemplify` vs `developer`) or wrong **`-i`** file. You must point at the **private** key: `…\id_rsa_azure_budget_vm` or `…\id_ed25519_budget_vm_developer` (**not** the `.pub` files). |
| **WARNING: UNPROTECTED PRIVATE KEY FILE** (Unix) | Run `chmod 600` on the private key. |
| **Connection timed out** | VM stopped in Azure; wrong IP; local/network firewall blocking **outbound** port 22. |
| **`ssh: Could not resolve hostname`** | Typo in IP or DNS name; use the IPv4 from [AZURE-BUDGET-VM-ACCESS.md](./AZURE-BUDGET-VM-ACCESS.md). |
| **Port 22: Connection refused** | SSH service down on guest (rare); or connecting to wrong IP/host. |

---

## 7. After you are logged in (quick reference)

| Task | Command |
|------|---------|
| Current user | `whoami` |
| Root shell | `sudo -i` or `sudo su -` |
| Disk space | `df -h` |
| Memory | `free -h` |
| Updates (Ubuntu) | `sudo apt update` then `sudo apt upgrade` (review before confirming) |
| Log out | `exit` |

---

## 8. Security reminders

- **`ssh -i`** takes a **path to a file** that holds the private key. Do **not** paste the private key **text** into the terminal or into this document.
- Private key **files** are **secrets**. Do not commit them to git; the `access/` tree should stay **gitignored** or carefully excluded.
- If a private key may be compromised, **remove** the matching line from `~/.ssh/authorized_keys` on the server (as the other admin user) and **generate a new** key pair.
- **`developer`** has full **sudo** on the VM: protect that key like an admin password.

---

## Related documents

| Document | Purpose |
|----------|---------|
| [AZURE-BUDGET-VM-ACCESS.md](./AZURE-BUDGET-VM-ACCESS.md) | Azure subscription, VM config, CLI, teardown |
| [AZURE-BUDGET-VM-DEVELOPER-SSH.md](./AZURE-BUDGET-VM-DEVELOPER-SSH.md) | Short handout for developers (no Azure IDs) |
| [README.md](./README.md) | Index of files in this folder |
