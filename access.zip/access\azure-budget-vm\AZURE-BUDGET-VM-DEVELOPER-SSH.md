# Budget VM — developer SSH (no cloud console access)

This sheet is for **developers** who need shell access to the shared Linux VM. You **do not** need an Azure account, the Azure portal, or the `az` CLI.

For **numbered steps** (install SSH client, first connection, `chmod`, troubleshooting), use **[AZURE-BUDGET-VM-SSH-STEP-BY-STEP.md](./AZURE-BUDGET-VM-SSH-STEP-BY-STEP.md)** → section **4. Step-by-step: `developer`**.

---

## What you need

| Item | Details |
|------|--------|
| **Host** | `172.182.227.84` |
| **Port** | `22` (default for `ssh`) |
| **Username** | `developer` |
| **Authentication** | SSH **private key** file your admin sends you (Ed25519). **There is no password** for this account. |

Your admin should deliver the private key through a **secure channel** (company secret manager, encrypted transfer, etc.). Save it only on machines you control.

---

## Connect

**Windows (PowerShell), from the folder where you saved the key:**

```powershell
ssh -i .\id_ed25519_budget_vm_developer developer@172.182.227.84
```

**macOS / Linux:**

```bash
chmod 600 ~/path/to/id_ed25519_budget_vm_developer
ssh -i ~/path/to/id_ed25519_budget_vm_developer developer@172.182.227.84
```

**Optional — add to `~/.ssh/config`** (Unix-like systems):

```sshconfig
Host seemplify-budget-vm
    HostName 172.182.227.84
    User developer
    IdentityFile ~/.ssh/id_ed25519_budget_vm_developer
```

Then: `ssh seemplify-budget-vm`

---

## First-time host key

The first time you connect, SSH will show the server’s host key fingerprint and ask you to confirm. If your admin gave you an expected fingerprint, compare before typing **yes**. If anything looks wrong, stop and ask the admin.

---

## What you can and cannot do

- You get a Linux shell as user **`developer`**.
- You may run **`sudo`** (passwordless) for OS administration—e.g. `sudo apt update`, `sudo systemctl restart …`, or a root shell with **`sudo -i`**. Treat that power carefully.
- You **cannot** start/stop the VM, resize it, or change Azure networking or NSGs from the guest; that requires **Azure** access (portal or `az`).

For VM lifecycle in Azure or billing questions, contact your admin.

---

## If access fails

1. Confirm you use user **`developer`** (not `seemplify` or `azureuser`).
2. Confirm the **`-i` path** points to the **private** key (no `.pub` extension).
3. On Linux/macOS, ensure the private key file is **not world-readable** (`chmod 600`).
4. Ask your admin to confirm the VM is running and that port **22** is allowed from your network.

---

## Key hygiene

- Do **not** share your private key or commit it to a repository.
- Tell your admin immediately if the key may have been exposed so they can remove it from the server and issue a new one.
