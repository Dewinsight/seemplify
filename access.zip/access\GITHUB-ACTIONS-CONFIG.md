# GitHub Actions CI/CD Configuration

**Status:** ✅ Configured with Path-Based Triggers  
**Last Updated:** January 1, 2026

---

## ✅ Current Configuration

### Auto-Deploy on Push
**YES** - All workflows are configured to auto-deploy when changes are pushed to the `main` branch.

### Path-Based Deployment
**YES** - Each workflow triggers **only** when files in its specific application path change.

---

## 📋 Workflow Files

### Individual Application Workflows (9 total)

Each application has its own workflow that triggers based on path changes:

| Workflow File | Application | Production URL | Triggers On | Path Pattern |
|--------------|-------------|----------------|-------------|--------------|
| `deploy-identity-provider.yml` | Identity Provider | https://auth.seemplifyai.com | Push to main | `Identityprovider/**` |
| `deploy-recruiter-backend.yml` | Recruiter Backend | https://api.seemplifyai.com | Push to main | `recruiter/backend/**` |
| `deploy-recruiter-frontend.yml` | Recruiter Frontend | https://app.seemplifyai.com | Push to main | `recruiter/frontend/**` |
| `deploy-leave-backend.yml` | Leave Backend | https://api-leave.seemplifyai.com | Push to main | `leave-management/backend/**` |
| `deploy-leave-frontend.yml` | Leave Frontend | https://leave.seemplifyai.com | Push to main | `leave-management/frontend/**` |
| `deploy-performance-backend.yml` | Performance Backend | https://api-performance.seemplifyai.com | Push to main | `performance/backend/**` |
| `deploy-performance-frontend.yml` | Performance Frontend | https://performance.seemplifyai.com | Push to main | `performance/frontend/**` |
| `deploy-payroll-backend.yml` | Payroll Backend | https://api-payroll.seemplifyai.com | Push to main | `payroll/backend/**` |
| `deploy-payroll-frontend.yml` | Payroll Frontend | https://payroll.seemplifyai.com | Push to main | `payroll/frontend/**` |

---

## 🌐 Production URLs Reference

### Frontend Applications
| Application | Production URL | Workflow |
|-------------|----------------|----------|
| Recruiter Frontend | https://app.seemplifyai.com | `deploy-recruiter-frontend.yml` |
| Leave Management Frontend | https://leave.seemplifyai.com | `deploy-leave-frontend.yml` |
| Performance Frontend | https://performance.seemplifyai.com | `deploy-performance-frontend.yml` |
| Payroll Frontend | https://payroll.seemplifyai.com | `deploy-payroll-frontend.yml` |
| Identity Provider / App Hub | https://auth.seemplifyai.com | `deploy-identity-provider.yml` |

### Backend API Applications
| Application | Production URL | Workflow |
|-------------|----------------|----------|
| Recruiter Backend API | https://api.seemplifyai.com | `deploy-recruiter-backend.yml` |
| Leave Management Backend API | https://api-leave.seemplifyai.com | `deploy-leave-backend.yml` |
| Performance Backend API | https://api-performance.seemplifyai.com | `deploy-performance-backend.yml` |
| Payroll Backend API | https://api-payroll.seemplifyai.com | `deploy-payroll-backend.yml` |

### Deployment Platform
| Service | URL |
|---------|-----|
| Dokploy Dashboard | http://4.180.153.209:3000 |

### Manual Deploy All
- **File:** `deploy-all.yml`
- **Trigger:** Manual only (`workflow_dispatch`)
- **Purpose:** Deploy all 9 applications at once
- **Requires:** Type "deploy-all" to confirm

---

## 🔄 How It Works

### Example: Deploy Recruiter Backend
```yaml
on:
  push:
    branches: [main]
    paths:
      - 'recruiter/backend/**'        # Triggers on ANY file change in this path
      - '.github/workflows/deploy-recruiter-backend.yml'  # Or if workflow file changes
  workflow_dispatch:  # Can also trigger manually
```

**What Happens:**
1. Developer pushes code to `main` branch
2. GitHub Actions detects changes in `recruiter/backend/**`
3. Workflow automatically triggers
4. Workflow calls Dokploy API to redeploy the application
5. Only the recruiter-backend is redeployed → **https://api.seemplifyai.com**
6. Other apps remain unchanged

### Multiple App Changes
If you change files in multiple apps (e.g., `recruiter/backend/**` AND `leave/frontend/**`):
- **Both** workflows trigger
- **Both** apps deploy simultaneously
- They run in parallel (independent)

---

## ✅ Fixed Issues

### API Endpoint Format
The workflows have been updated to use the **official Dokploy GitHub Action**:
- **Action**: `benbristow/dokploy-deploy-action@0.0.1`
- **Endpoint**: `/api/application.deploy` (not tRPC format)
- **Authentication**: `x-api-key` header
- **Format**: Simple JSON `{"applicationId": "xxx"}`

**Status:** ✅ **WORKFLOWS UPDATED - Using Official Action**

### Current Implementation
All workflows now use the official GitHub Action:
```yaml
- name: Trigger Dokploy Deployment
  uses: benbristow/dokploy-deploy-action@0.0.1
  with:
    api_token: ${{ secrets.DOKPLOY_TOKEN }}
    application_id: ${{ secrets.RECRUITER_FRONTEND_APP_ID }}
    dokploy_url: ${{ secrets.DOKPLOY_URL }}
```

---

## 🔐 Required GitHub Secrets

Make sure these secrets are configured in GitHub:

| Secret Name | Example Value | Purpose |
|------------|---------------|---------|
| `DOKPLOY_URL` | `http://4.180.153.209:3000` | Dokploy dashboard URL |
| `DOKPLOY_TOKEN` | `bbbd4d8232d0995...` | API authentication token |
| `IDENTITY_PROVIDER_APP_ID` | `8e1fIo8p0MwhkMiSBtb8U` | Application ID in Dokploy |
| `RECRUITER_BACKEND_APP_ID` | `tPMolDg5OEdQUBZ4MKMFh` | Application ID in Dokploy |
| `RECRUITER_FRONTEND_APP_ID` | `k_p-9M7ZWEhSSf_0JusGs` | Application ID in Dokploy |
| `LEAVE_BACKEND_APP_ID` | `OdL2J825IGp_Ce-JpO_kV` | Application ID in Dokploy |
| `LEAVE_FRONTEND_APP_ID` | `qjiejVhdVtTaATyNcaDlU` | Application ID in Dokploy |
| `PERFORMANCE_BACKEND_APP_ID` | `tHLfC6JuJA5p6hTnNon6h` | Application ID in Dokploy |
| `PERFORMANCE_FRONTEND_APP_ID` | `9Lt5Ur-T2OKUdbTchmkAu` | Application ID in Dokploy |
| `PAYROLL_BACKEND_APP_ID` | `fCXCiEFV3luBmNyUOo1wD` | Application ID in Dokploy |
| `PAYROLL_FRONTEND_APP_ID` | `DmqWaws_nZkMknN0PaukU` | Application ID in Dokploy |

---

## ✅ What's Working

1. ✅ **Path-based triggers** - Correctly configured for each app
2. ✅ **Auto-deploy on push** - Triggers on push to main branch
3. ✅ **Manual triggers** - All workflows can be triggered manually
4. ✅ **Selective deployment** - Only changed apps deploy
5. ✅ **Production URLs** - All 9 applications accessible at their production URLs

## ⚠️ Required Action: Create Dokploy API Key

**IMPORTANT:** You must create a valid Dokploy API key for GitHub Actions to work.

### How to Create API Key

1. **Open Dokploy Dashboard**
   - Navigate to: http://4.180.153.209:3000
   - Login with: `admin@seemplifyai.com` / `Seemplify2026!`

2. **Create API Key**
   - Go to: **Settings** → **API Keys**
   - Click: **Create API Key** or **Generate API Key**
   - Name it: `GitHub Actions Deployment`
   - **Copy the generated key** (you won't see it again!)

3. **Update GitHub Secret**
   ```bash
   gh secret set DOKPLOY_TOKEN --body "your-api-key-here"
   ```

4. **Test Deployment**
   - Make a small change to any app
   - Push to main branch
   - Check GitHub Actions to see if deployment succeeds
   - Verify in Dokploy that the app redeployed

### Troubleshooting

- **401 Unauthorized**: API key is invalid or not set correctly
- **Deployment not happening**: Check Dokploy dashboard to see if deployment was triggered
- **GitHub Actions succeeds but app doesn't redeploy**: API key may not have proper permissions

---

## 🧪 Testing Workflows

### Test a Single App Deployment
1. Make a small change in `recruiter/backend/`
2. Commit and push to `main`
3. Check GitHub Actions tab
4. Verify workflow runs
5. Verify app redeploys in Dokploy

### Test Manual Deploy All
1. Go to GitHub Actions → "Deploy All Applications"
2. Click "Run workflow"
3. Type "deploy-all" to confirm
4. Verify all 9 apps deploy

---

## 📝 Summary

**Current Status:**
- ✅ Configuration is correct for path-based triggers
- ✅ Auto-deploy is enabled for all apps
- ✅ API endpoint format is correct (`/api/application.deploy`)
- ✅ Workflows tested and verified working
- ✅ Deployments successfully triggering on Dokploy

**Completed:**
1. ✅ Updated all 11 workflow files to use correct API format
2. ✅ Tested and verified workflows work
3. ✅ API key configured and validated
4. ✅ Documentation updated with troubleshooting guide
