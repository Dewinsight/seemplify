# Complete Email Settings - Michael & Ryan

**Date:** January 19, 2026  
**Domain:** paddie.io  
**Mail Server:** mail.seemplifyai.com

---

## 📧 Michael - Complete Settings

### Account Information
- **Full Name:** Michael
- **Email Address:** `michael@paddie.io`
- **Password:** `MichaelPass123!`

### Incoming Mail (IMAP)
- **IMAP Server:** `mail.seemplifyai.com`
- **IMAP Port:** `993`
- **Encryption:** `SSL/TLS` (or `SSL`)
- **Username:** `michael@paddie.io`
- **Password:** `MichaelPass123!`
- **Authentication:** Required

### Outgoing Mail (SMTP)
- **SMTP Server:** `mail.seemplifyai.com`
- **SMTP Port:** `587` (recommended) or `465`
- **Encryption:** `STARTTLS` (port 587) or `SSL/TLS` (port 465)
- **Username:** `michael@paddie.io`
- **Password:** `MichaelPass123!`
- **Authentication:** Required ✅
- **Use same credentials as incoming:** Yes

### Webmail Access
- **URL:** https://mail.seemplifyai.com/SOGo/
- **Username:** `michael@paddie.io`
- **Password:** `MichaelPass123!`

### Calendar (CalDAV)
- **CalDAV URL:** `https://mail.seemplifyai.com/SOGo/dav/michael@paddie.io/Calendar/`
- **Username:** `michael@paddie.io`
- **Password:** `MichaelPass123!`

### Contacts (CardDAV)
- **CardDAV URL:** `https://mail.seemplifyai.com/SOGo/dav/michael@paddie.io/Contacts/`
- **Username:** `michael@paddie.io`
- **Password:** `MichaelPass123!`

---

## 📧 Ryan - Complete Settings

### Account Information
- **Full Name:** Ryan
- **Email Address:** `ryan@paddie.io`
- **Password:** `RyanPass123!`

### Incoming Mail (IMAP)
- **IMAP Server:** `mail.seemplifyai.com`
- **IMAP Port:** `993`
- **Encryption:** `SSL/TLS` (or `SSL`)
- **Username:** `ryan@paddie.io`
- **Password:** `RyanPass123!`
- **Authentication:** Required

### Outgoing Mail (SMTP)
- **SMTP Server:** `mail.seemplifyai.com`
- **SMTP Port:** `587` (recommended) or `465`
- **Encryption:** `STARTTLS` (port 587) or `SSL/TLS` (port 465)
- **Username:** `ryan@paddie.io`
- **Password:** `RyanPass123!`
- **Authentication:** Required ✅
- **Use same credentials as incoming:** Yes

### Webmail Access
- **URL:** https://mail.seemplifyai.com/SOGo/
- **Username:** `ryan@paddie.io`
- **Password:** `RyanPass123!`

### Calendar (CalDAV)
- **CalDAV URL:** `https://mail.seemplifyai.com/SOGo/dav/ryan@paddie.io/Calendar/`
- **Username:** `ryan@paddie.io`
- **Password:** `RyanPass123!`

### Contacts (CardDAV)
- **CardDAV URL:** `https://mail.seemplifyai.com/SOGo/dav/ryan@paddie.io/Contacts/`
- **Username:** `ryan@paddie.io`
- **Password:** `RyanPass123!`

---

## 📋 Quick Reference Table

| Setting | Michael | Ryan |
|---------|---------|------|
| **Email** | michael@paddie.io | ryan@paddie.io |
| **Password** | MichaelPass123! | RyanPass123! |
| **IMAP Server** | mail.seemplifyai.com | mail.seemplifyai.com |
| **IMAP Port** | 993 | 993 |
| **IMAP Encryption** | SSL/TLS | SSL/TLS |
| **SMTP Server** | mail.seemplifyai.com | mail.seemplifyai.com |
| **SMTP Port** | 587 | 587 |
| **SMTP Encryption** | STARTTLS | STARTTLS |
| **Webmail URL** | https://mail.seemplifyai.com/SOGo/ | https://mail.seemplifyai.com/SOGo/ |

---

## 🔧 Client-Specific Configuration

### Outlook Desktop (Windows/Mac)
```
Account Type: IMAP
Incoming Server: mail.seemplifyai.com
Incoming Port: 993
Incoming Encryption: SSL/TLS
Outgoing Server: mail.seemplifyai.com
Outgoing Port: 587
Outgoing Encryption: STARTTLS
Username: [full email address]
Password: [account password]
✅ My outgoing server requires authentication
✅ Use same settings as incoming mail server
```

### Outlook Mobile (iOS/Android)
```
Account Type: IMAP
Incoming Server: mail.seemplifyai.com
Incoming Port: 993
Incoming Security: SSL/TLS
Outgoing Server: mail.seemplifyai.com
Outgoing Port: 587
Outgoing Security: STARTTLS
Username: [full email address]
Password: [account password]
```

### Apple Mail (macOS/iOS)
```
Account Type: IMAP
Incoming Mail Server: mail.seemplifyai.com
Port: 993
Use SSL: Yes
Outgoing Mail Server: mail.seemplifyai.com
Port: 587
Use SSL: Yes
Authentication: Password
Username: [full email address]
Password: [account password]
```

### Gmail (Add Account)
```
Incoming: mail.seemplifyai.com:993 (SSL)
Outgoing: mail.seemplifyai.com:587 (STARTTLS)
Username: [full email address]
Password: [account password]
```

### Thunderbird
```
Incoming: mail.seemplifyai.com
Port: 993
SSL/TLS: Yes
Outgoing: mail.seemplifyai.com
Port: 587
STARTTLS: Yes
Username: [full email address]
Password: [account password]
```

---

## 📱 Mobile Calendar Setup

### iPhone/iPad
1. Settings → Calendar → Accounts → Add Account
2. Other → Add CalDAV Account
3. Server: `mail.seemplifyai.com`
4. Username: `michael@paddie.io` (or `ryan@paddie.io`)
5. Password: Account password
6. Description: `Mailcow Calendar`

### Android
1. Install CalDAV client (e.g., DAVx⁵)
2. Add account:
   - Server URL: `https://mail.seemplifyai.com/SOGo/dav/[EMAIL]/Calendar/`
   - Username: Full email address
   - Password: Account password

---

## 💻 Application Integration (SMTP)

### Node.js (nodemailer)
```javascript
const transporter = nodemailer.createTransport({
  host: 'mail.seemplifyai.com',
  port: 587,
  secure: false, // true for 465, false for 587
  auth: {
    user: 'michael@paddie.io', // or ryan@paddie.io
    pass: 'MichaelPass123!' // or RyanPass123!
  }
});
```

### Python (smtplib)
```python
smtp_server = 'mail.seemplifyai.com'
smtp_port = 587
username = 'michael@paddie.io'  # or ryan@paddie.io
password = 'MichaelPass123!'    # or RyanPass123!

server = smtplib.SMTP(smtp_server, smtp_port)
server.starttls()
server.login(username, password)
```

### PHP (PHPMailer)
```php
$mail->Host = 'mail.seemplifyai.com';
$mail->Port = 587;
$mail->SMTPAuth = true;
$mail->Username = 'michael@paddie.io'; // or ryan@paddie.io
$mail->Password = 'MichaelPass123!';   // or RyanPass123!
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
```

---

## ⚠️ Important Notes

1. **Username Format:** Always use **full email address** (e.g., `michael@paddie.io`, not just `michael`)

2. **Authentication:** Both IMAP and SMTP require authentication with the same credentials

3. **Ports:**
   - IMAP: `993` (SSL/TLS) - **Required**
   - SMTP: `587` (STARTTLS) - **Recommended** or `465` (SSL/TLS)

4. **Security:** All connections use encryption (SSL/TLS or STARTTLS)

5. **Password Security:** These are default passwords - **change them after first login!**

---

## 🔍 Troubleshooting

### Can't Connect
- Verify server: `mail.seemplifyai.com`
- Check ports: IMAP `993`, SMTP `587`
- Ensure SSL/TLS is enabled

### Authentication Failed
- Verify username is full email: `michael@paddie.io` (not `michael`)
- Check password is correct (case-sensitive)
- Ensure "Require authentication" is enabled for SMTP

### Can't Send Email
- Verify SMTP port is `587` (not `25`)
- Check "My outgoing server requires authentication" is enabled
- Ensure STARTTLS is selected (not SSL for port 587)

---

## ✅ Verification Checklist

- [ ] IMAP connection working (can receive emails)
- [ ] SMTP connection working (can send emails)
- [ ] Webmail accessible (https://mail.seemplifyai.com/SOGo/)
- [ ] Calendar sync working (if using CalDAV)
- [ ] Test email sent and received successfully

---

**Last Updated:** January 19, 2026  
**Status:** ✅ Complete Settings Ready
