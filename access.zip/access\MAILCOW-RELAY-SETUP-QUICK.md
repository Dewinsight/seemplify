# Quick Setup: Configure Mailcow to Use Port 587 for Outbound Mail

## ✅ Why This Works

- **Port 587 works** - Azure allows outbound connections on port 587
- **Port 25 is blocked** - Azure blocks outbound port 25
- **Solution:** Configure Mailcow to send all outbound mail through an SMTP relay on port 587

---

## 🚀 Quick Setup (5 minutes)

### Step 1: Choose a Relay Service

**Recommended: SendGrid (Free tier: 100 emails/day)**

1. Sign up at: https://sendgrid.com
2. Go to: **Settings** → **API Keys**
3. Create API Key: **"Mailcow Relay"**
4. Copy the API key (you'll need it)

**Alternative: Mailgun (Free tier: 5,000 emails/month)**
- Sign up at: https://www.mailgun.com
- Get SMTP credentials from dashboard

---

### Step 2: Configure in Mailcow UI

1. **Login to Mailcow:**
   - URL: https://mail.seemplifyai.com
   - Username: `admin`
   - Password: `moohoo`

2. **Add Relay Host:**
   - Go to: **Configuration** → **Routing** tab
   - Click: **Add sender-dependent transport**
   - Fill in:
     ```
     Host: smtp.sendgrid.net
     Port: 587
     Username: apikey
     Password: [Your SendGrid API Key]
     Security: STARTTLS
     ```
   - Click: **Save**

3. **Assign to Domain:**
   - Go to: **Mail setup** → **Domains**
   - Click: **Edit** on `seemplifyai.com`
   - Under **Sender-dependent transports**, select your relay host
   - Click: **Save**

---

### Step 3: Test Email Delivery

```bash
# SSH into server
ssh seemplify@4.180.153.209

# Send test email
docker exec mailcowdockerized-postfix-mailcow-1 sendmail -v your-email@gmail.com <<EOF
Subject: Test Email from Mailcow
From: info@seemplifyai.com

This is a test email sent via port 587 relay!
EOF

# Check mail queue
docker exec mailcowdockerized-postfix-mailcow-1 mailq

# Check logs
docker logs mailcowdockerized-postfix-mailcow-1 --tail 50
```

---

## ✅ Verification

After configuration, Mailcow will:
1. ✅ Accept incoming mail on port 25 (inbound - works fine)
2. ✅ Accept client connections on port 587 (inbound - works fine)
3. ✅ Send outbound mail via port 587 relay (outbound - works!)

**All mail traffic uses port 587, which Azure allows!**

---

## 🔧 Alternative: Configure via CLI (Advanced)

If you prefer CLI configuration:

```bash
ssh seemplify@4.180.153.209

# Access MySQL
docker exec -it mailcowdockerized-mysql-mailcow-1 mysql -u mailcow -p3w8aLaw8jyknrgbs3qFfDgdD4LRQ mailcow

# Add relay host (example for SendGrid)
INSERT INTO sender_dependent_relayhost_maps (id, relayhost, username, password, active)
VALUES (1, '[smtp.sendgrid.net]:587', 'apikey', 'YOUR_SENDGRID_API_KEY', 1);

# Assign to domain
UPDATE domain SET relayhost = 1 WHERE domain = 'seemplifyai.com';

# Exit MySQL
exit

# Restart Postfix
docker restart mailcowdockerized-postfix-mailcow-1
```

---

## 📊 Port Usage Summary

| Direction | Port | Purpose | Status |
|-----------|------|---------|--------|
| **Inbound** | 25 | Receive mail from internet | ✅ Works |
| **Inbound** | 587 | Client submission (Outlook, etc.) | ✅ Works |
| **Outbound** | 587 | **Send mail via relay** | ✅ **Works!** |
| **Outbound** | 25 | Direct delivery | ❌ Blocked by Azure |

---

## 🎯 Result

After this configuration:
- ✅ Users can send emails via Mailcow (port 587)
- ✅ Mailcow can send emails to external recipients (via port 587 relay)
- ✅ No need to request Azure port 25 unblock
- ✅ Better deliverability (relay services have good IP reputation)

---

## 📚 More Information

See `AZURE-PORT-25-SOLUTION.md` for:
- Detailed explanation
- Alternative relay services
- Troubleshooting
- Azure port 25 unblock request (if needed)

---

**Last Updated:** January 6, 2026
