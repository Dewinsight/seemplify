# Fix Outlook "App Password" Error - Complete Solution

**Date:** January 19, 2026  
**Issue:** Outlook says "something went wrong, you may need an app password"

---

## 🔍 Root Cause

Outlook is trying to use **OAuth/modern authentication** instead of **basic IMAP/SMTP authentication**. Mailcow uses standard basic authentication - you don't need an app password, but you need to configure Outlook correctly.

**IMPORTANT:** Make sure you're using **Manual Setup** and selecting **POP or IMAP** (NOT Exchange/Office 365) to force basic authentication.

---

## ✅ Solution: Use Basic Authentication (Not OAuth)

### Option 1: Manual Account Setup (Recommended)

**This forces Outlook to use basic authentication instead of OAuth:**

1. **Remove existing account** from Outlook if already added

2. **Add Account Manually:**
   - **File** → **Add Account**
   - Select **"Manual setup or additional server types"**
   - Click **Next**

3. **Choose Account Type:**
   - Select **"POP or IMAP"** (NOT Exchange/Office 365)
   - Click **Next**

4. **Enter Account Settings:**

   **For Michael:**
   ```
   Your Name: Michael
   Email Address: michael@paddie.io
   Account Type: IMAP
   Incoming mail server: mail.seemplifyai.com
   Outgoing mail server: mail.seemplifyai.com
   User Name: michael@paddie.io
   Password: MichaelPass123!
   ✅ Remember password
   ```

   **For Ryan:**
   ```
   Your Name: Ryan
   Email Address: ryan@paddie.io
   Account Type: IMAP
   Incoming mail server: mail.seemplifyai.com
   Outgoing mail server: mail.seemplifyai.com
   User Name: ryan@paddie.io
   Password: RyanPass123!
   ✅ Remember password
   ```

5. **Click "More Settings"**

6. **Outgoing Server Tab:**
   - ✅ Check **"My outgoing server (SMTP) requires authentication"**
   - Select **"Use same settings as my incoming mail server"**

7. **Advanced Tab:**
   - **Incoming server (IMAP):**
     - Port: `993`
     - Encryption: **SSL/TLS**
     - ✅ Check **"This server requires an encrypted connection (SSL/TLS)"**
   - **Outgoing server (SMTP):**
     - Port: `587`
     - Encryption: **STARTTLS**
     - ✅ Check **"This server requires an encrypted connection"**

8. **Security Tab (if available):**
   - **Authentication:** Select **"Basic Authentication"** or **"Password"**
   - **Do NOT** select OAuth or Modern Authentication

9. **Click OK** → **Next** → **Finish**

---

## 🔧 Option 2: Fix Existing Account

If account is already added:

1. **File** → **Account Settings** → **Account Settings**

2. **Select your account** → **Change**

3. **Click "More Settings"**

4. **Security Tab:**
   - Change authentication to **"Basic Authentication"**
   - Remove any OAuth settings

5. **Advanced Tab:**
   - Verify ports: IMAP `993`, SMTP `587`
   - Verify encryption: IMAP `SSL/TLS`, SMTP `STARTTLS`

6. **Click OK** → **Next** → **Test Account Settings**

---

## 📱 Outlook Mobile Fix

### iOS/Android Outlook App

1. **Remove the account** from Outlook app

2. **Add Account:**
   - Tap **Add Account**
   - Select **"Advanced Setup"** or **"IMAP"**
   - **Do NOT** use "Add Account" auto-setup

3. **Enter Settings:**
   ```
   Email: michael@paddie.io (or ryan@paddie.io)
   Password: [your password]
   IMAP Server: mail.seemplifyai.com
   IMAP Port: 993
   IMAP Security: SSL/TLS
   SMTP Server: mail.seemplifyai.com
   SMTP Port: 587
   SMTP Security: STARTTLS
   Username: michael@paddie.io (full email)
   ```

4. **Save**

---

## ⚠️ Important Notes

1. **No App Password Needed:** Mailcow uses basic authentication - use your regular password

2. **Use Full Email as Username:** Always use `michael@paddie.io` (not just `michael`)

3. **Disable OAuth:** Make sure Outlook is NOT trying to use OAuth/modern authentication

4. **Certificate Warning:** If you see SSL certificate warning, accept it (Mailcow uses self-signed certificate)

---

## 🧪 Test Connection

After setup, Outlook should:
- ✅ Connect to IMAP server (port 993)
- ✅ Connect to SMTP server (port 587)
- ✅ Authenticate successfully
- ✅ Send test email
- ✅ Receive emails

---

## 🔍 Troubleshooting

### Still Getting "App Password" Error?

1. **Check Outlook Version:**
   - Older Outlook versions work better with basic auth
   - New Outlook (2021+) may require disabling modern auth

2. **Registry Fix (Windows):**
   ```
   HKEY_CURRENT_USER\Software\Microsoft\Office\16.0\Outlook\AutoDiscover
   EnableOAuth = 0 (DWORD)
   ```

3. **Use Webmail Instead:**
   - If Outlook continues to have issues, use SOGo webmail:
   - https://mail.seemplifyai.com/SOGo/
   - Login with your email and password

---

## ✅ Correct Settings Summary

**For Michael:**
- Server: `mail.seemplifyai.com`
- IMAP: Port `993`, SSL/TLS
- SMTP: Port `587`, STARTTLS
- Username: `michael@paddie.io`
- Password: `MichaelPass123!`
- Authentication: **Basic** (NOT OAuth)

**For Ryan:**
- Server: `mail.seemplifyai.com`
- IMAP: Port `993`, SSL/TLS
- SMTP: Port `587`, STARTTLS
- Username: `ryan@paddie.io`
- Password: `RyanPass123!`
- Authentication: **Basic** (NOT OAuth)

---

**Last Updated:** January 19, 2026  
**Status:** ✅ Solution Ready - Use Basic Authentication
