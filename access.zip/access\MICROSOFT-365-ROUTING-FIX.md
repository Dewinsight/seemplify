# Microsoft 365 Internal Routing Fix for paddie.io

**Date:** January 19, 2026  
**Issue:** Emails from Microsoft 365 Business accounts going to old Microsoft mailbox instead of Mailcow

---

## 🔍 Problem Identified

**Root Cause:** Microsoft 365 routes emails **internally** when both sender and recipient domains are configured in Microsoft 365 tenants. It does **NOT** check external DNS for internal routing.

**What's Happening:**
1. Gmail sends to `michael@paddie.io` → Checks DNS → Finds MX record → Routes to Mailcow ✅
2. Microsoft 365 sends to `michael@paddie.io` → Sees domain in tenant → Routes internally → Goes to old Microsoft mailbox ❌

---

## ✅ DNS Configuration (Already Correct)

- ✅ **MX Record:** `mail.seemplifyai.com` (correct)
- ✅ **SPF Record:** Includes Mailcow and Brevo
- ✅ **DKIM:** Configured
- ✅ **DMARC:** Configured
- ✅ **No Microsoft DNS records**

**DNS is NOT the problem.** The issue is Microsoft 365 tenant configuration.

---

## 🛠️ Solution: Remove Domain from Microsoft 365 Tenant

### Step 1: Access Microsoft 365 Admin Center

1. Go to: https://admin.microsoft.com
2. Login with Microsoft 365 admin credentials
3. Navigate to: **Settings** → **Domains**

### Step 2: Remove paddie.io Domain

1. Find `paddie.io` in the domains list
2. Click on `paddie.io`
3. Click **Remove domain** or **Delete**
4. Follow the prompts to confirm removal

**⚠️ IMPORTANT:** This will:
- Remove all mailboxes using `@paddie.io` addresses in Microsoft 365
- Remove all users with `@paddie.io` email addresses
- Stop internal routing to Microsoft 365 mailboxes

### Step 3: Verify Removal

After removal:
1. Wait 5-10 minutes for Microsoft's internal systems to update
2. Send a test email from Microsoft 365 Business account to `michael@paddie.io`
3. Email should now route to Mailcow (checks DNS)

---

## 🔄 Alternative: If Domain Cannot Be Removed

If you cannot remove the domain (e.g., other services depend on it):

### Option 1: Remove Mailbox Only
1. In Microsoft 365 Admin Center → **Users** → **Active users**
2. Find `michael@paddie.io` mailbox
3. Delete or disable the mailbox
4. This stops emails from being delivered to that mailbox

### Option 2: Disable Email for Domain
1. In Microsoft 365 Admin Center → **Settings** → **Domains** → `paddie.io`
2. Remove Exchange Online license
3. This disables email routing for the domain while keeping the domain in tenant

---

## 📋 Verification Checklist

After removing domain/mailbox from Microsoft 365:

- [ ] Domain removed from Microsoft 365 tenant
- [ ] Old `michael@paddie.io` mailbox deleted in Microsoft 365
- [ ] Wait 5-10 minutes for Microsoft systems to update
- [ ] Test email from Microsoft 365 Business account
- [ ] Email arrives in Mailcow mailbox ✅
- [ ] Email does NOT arrive in old Microsoft mailbox ✅

---

## 🧪 Testing

**Test 1: From Gmail (Already Working)**
- Send from Gmail to `michael@paddie.io`
- Should arrive in Mailcow ✅

**Test 2: From Microsoft 365 (After Fix)**
- Send from Microsoft 365 Business account to `michael@paddie.io`
- Should now arrive in Mailcow ✅ (after domain removal)

**Test 3: Check Mailcow Logs**
```bash
docker logs mailcowdockerized-postfix-mailcow-1 --tail 50 | grep michael@paddie.io
```
Should show emails arriving from Microsoft 365 servers.

---

## ⚠️ Important Notes

1. **DNS is Correct:** The MX record is already pointing to Mailcow. This is not a DNS issue.

2. **Microsoft 365 Internal Routing:** Microsoft 365 prioritizes internal routing over DNS. If the domain exists in the tenant, it routes internally.

3. **Propagation Time:** After removing the domain, allow 5-10 minutes for Microsoft's systems to update.

4. **No DNS Changes Needed:** All DNS records are already correct. Only Microsoft 365 tenant configuration needs to change.

---

## 📞 If You Need Help

If you don't have access to Microsoft 365 Admin Center:
1. Contact your Microsoft 365 administrator
2. Request removal of `paddie.io` domain from the tenant
3. Or request deletion of the `michael@paddie.io` mailbox

---

**Last Updated:** January 19, 2026  
**Status:** ⚠️ Requires Microsoft 365 Admin Action
