# Mailcow Configuration Verification - Complete

**Date:** January 19, 2026  
**Status:** ✅ Mailcow Configured - Outlook Setup Required

---

## ✅ Mailcow Server Status

### Services Running
- ✅ **Dovecot (IMAP):** Running - Port 993 open
- ✅ **Postfix (SMTP):** Running - Ports 587, 465, 25 open
- ✅ **SOGo (Webmail):** Running

### Mailbox Configuration
- ✅ **michael@paddie.io:** Active, IMAP enabled, SMTP enabled, SOGo enabled
- ✅ **ryan@paddie.io:** Active, IMAP enabled, SMTP enabled, SOGo enabled
- ✅ **App passwords:** Enabled in user_acl

### Ports Verified
- ✅ **993** (IMAP SSL): Listening
- ✅ **587** (SMTP STARTTLS): Listening
- ✅ **465** (SMTP SSL): Listening
- ✅ **25** (SMTP): Listening

### SSL Certificate
- ⚠️ **Self-signed certificate** (this is normal for Mailcow)
- Outlook may show certificate warning - **accept it**

---

## 📧 Correct Settings for Outlook

### Michael (`michael@paddie.io`)
```
Account Type: IMAP (NOT Exchange)
Server: mail.seemplifyai.com
IMAP Port: 993 (SSL/TLS)
SMTP Port: 587 (STARTTLS)
Username: michael@paddie.io
Password: MichaelPass123!
Authentication: Basic (NOT OAuth)
```

### Ryan (`ryan@paddie.io`)
```
Account Type: IMAP (NOT Exchange)
Server: mail.seemplifyai.com
IMAP Port: 993 (SSL/TLS)
SMTP Port: 587 (STARTTLS)
Username: ryan@paddie.io
Password: RyanPass123!
Authentication: Basic (NOT OAuth)
```

---

## 🔑 Key Points for Outlook

1. **Use Manual Setup:** Don't use auto-discover
2. **Select "POP or IMAP":** NOT Exchange/Office 365
3. **Basic Authentication:** NOT OAuth/modern auth
4. **Full Email as Username:** `michael@paddie.io` (not just `michael`)
5. **Accept SSL Certificate:** If prompted (self-signed is normal)

---

## 🧪 Test Connection

**Before Outlook, test with webmail:**
1. Go to: https://mail.seemplifyai.com/SOGo/
2. Login: `michael@paddie.io` / `MichaelPass123!`
3. If webmail works, Mailcow is fine - issue is Outlook configuration
4. If webmail doesn't work, check password

---

## 📋 Outlook Setup Checklist

- [ ] Removed existing account (if any)
- [ ] Used "Manual setup or additional server types"
- [ ] Selected "POP or IMAP" (NOT Exchange)
- [ ] Entered full email as username
- [ ] Set IMAP port 993 with SSL/TLS
- [ ] Set SMTP port 587 with STARTTLS
- [ ] Enabled SMTP authentication
- [ ] Selected Basic Authentication (NOT OAuth)
- [ ] Accepted SSL certificate warning (if shown)
- [ ] Test account settings successful

---

**Last Updated:** January 19, 2026  
**Mailcow Status:** ✅ Fully Configured and Working  
**Outlook Setup:** Use Manual Setup with Basic Authentication
