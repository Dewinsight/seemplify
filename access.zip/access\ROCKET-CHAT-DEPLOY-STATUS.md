# Rocket.Chat Deploy Status

**Date:** January 30, 2026  
**Goal:** Deploy Rocket.Chat to Dokploy, configure domain, GitHub workflow

---

## ✅ Completed (automated)

### 1. Cloudflare DNS
- **Record:** `chat.seemplifyai.com` → A → `4.180.153.209`
- **Proxied:** Yes (orange cloud)
- **Zone ID:** bbc142d2d661d64011e2e4becae7a5c3 (seemplifyai.com)
- **API:** Cloudflare REST API (token from CLOUD-INFRASTRUCTURE.md)

### 2. GitHub
- **Commit:** `cd5bb13` – Add Rocket.Chat: docker-compose, IDP hub + OIDC client, deploy workflow
- **Pushed to:** `main` on https://github.com/michaelegbo/seemplify.git
- **Paths:** `rocket-chat/`, `.github/workflows/deploy-rocket-chat.yml`, `Identityprovider/clients.json`, `Identityprovider/src/config/hubApps.js`, `Identityprovider/src/index.js`

### 3. Identity Provider
- **OIDC client:** `rocket-chat` in `Identityprovider/clients.json` (redirect URIs for chat.seemplifyai.com, chat-dev, localhost)
- **Hub app:** Rocket.Chat added as "Team Chat" in `hubApps.js` (dev + prod), category `communication`
- **Hub launch:** SSO redirect from hub to IDP then Rocket.Chat `/_oauth/seemplify` (in `Identityprovider/src/index.js`)

---

## ⏳ Manual step required

### Create Rocket.Chat app in Dokploy and enable GitHub deploy

1. **Dokploy UI:** http://4.180.153.209:3000  
   - Login: see `access/DOKPLOY-CREDENTIALS.md`
   - Open project **seemplify** (or create it).
   - Create new **Application** (or **Docker Compose** if your Dokploy has a Compose type):
     - **Name:** e.g. `rocket-chat`
     - **Source:** GitHub – repo `michaelegbo/seemplify`, branch `main`, **build path:** `rocket-chat`
     - Or: Docker Compose type, paste/upload `rocket-chat/docker-compose.yml`, set env from `rocket-chat/.env.example` (at least `ROOT_URL=https://chat.seemplifyai.com`).
   - Set **domain:** `chat.seemplifyai.com` (Traefik/ingress) if your stack uses it.
   - Deploy once from UI, then note the **Application ID** (from URL or app settings).

2. **GitHub Secrets**
   - Add secret: `ROCKET_CHAT_APP_ID` = the Application ID from step 1.
   - Ensure `DOKPLOY_URL` and `DOKPLOY_TOKEN` are set (see `access/DOKPLOY-API-CREDENTIALS-COMPLETE.md`).

3. **Trigger deploy**
   - **Actions** → **Deploy Rocket.Chat** → **Run workflow**,  
   - or push changes under `rocket-chat/` to `main`.

4. **Rocket.Chat admin (after first deploy)**
   - Open https://chat.seemplifyai.com, complete setup wizard, create first admin.
   - **Administration** → **Workspace** → **Settings** → **OAuth** → **Add Custom OAuth** (name: **Seemplify**).
   - Configure with IDP URL, paths, client id `rocket-chat`, secret from `Identityprovider/clients.json` (see `rocket-chat/README.md`).

---

## Summary

| Item              | Status |
|-------------------|--------|
| DNS chat.seemplifyai.com | ✅ Done |
| Code on GitHub    | ✅ Pushed |
| Deploy workflow   | ✅ Added (needs `ROCKET_CHAT_APP_ID`) |
| IDP client + hub | ✅ Done |
| Dokploy app       | ⏳ Create in UI, then set `ROCKET_CHAT_APP_ID` |
| First deploy      | ⏳ After app created, run workflow or push |
