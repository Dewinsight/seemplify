# Paddie.io Email - Quick Reference Card

## 📧 Email Accounts

| Email | Password | Webmail |
|-------|----------|---------|
| **info@paddie.io** | `TestEmail123!` | https://mail.seemplifyai.com/SOGo |
| **michael@paddie.io** | `MichaelPass123!` | https://mail.seemplifyai.com/SOGo |
| **ryan@paddie.io** | `RyanPass123!` | https://mail.seemplifyai.com/SOGo |

## 🔧 Email Client Settings

**IMAP (Incoming):**
- Server: `mail.seemplifyai.com`
- Port: `993`
- Security: `SSL/TLS`
- Username: Full email address
- Password: See above

**SMTP (Outgoing):**
- Server: `mail.seemplifyai.com`
- Port: `587` (STARTTLS) or `465` (SSL/TLS)
- Authentication: Required
- Username: Full email address
- Password: See above

## 🌐 Web Access

- **Webmail:** https://mail.seemplifyai.com/SOGo
- **Admin Panel:** https://mail.seemplifyai.com (admin / moohoo)

## 📝 Quick Commands

```bash
# Check mailboxes
ssh seemplify@4.180.153.209
docker exec mailcowdockerized-mysql-mailcow-1 mysql -u mailcow -p3w8aLaw8jyknrgbs3qFfDgdD4LRQ mailcow -e "SELECT username, active FROM mailbox WHERE domain = 'paddie.io';"
```

---
**Full Documentation:** See `PADDIE-IO-EMAIL-CREDENTIALS.md`
