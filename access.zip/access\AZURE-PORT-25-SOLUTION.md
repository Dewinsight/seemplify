# Azure Port 25 Block - Solution Guide

## ✅ SOLVED!

Azure blocks **outbound** traffic on port 25 (SMTP) by default. We solved this by configuring Brevo SMTP relay on port 587.

**Current Status:**
- ✅ Port 587 (Submission) - **WORKING** (client connections)
- ✅ Port 587 (Brevo Relay) - **WORKING** (outbound mail delivery)
- ❌ Port 25 (Direct) - Blocked (not needed anymore)

**Solution Implemented:** Brevo SMTP relay on port 587

| Setting | Value |
|---------|-------|
| **Relay Host** | `[smtp-relay.brevo.com]:587` |
| **Login** | `93ea9d001@smtp-brevo.com` |
| **Status** | ✅ **OPERATIONAL** |

## ✅ Solutions

### Option 1: Configure SMTP Relay Service on Port 587 ✅ (Recommended)

**This is the solution!** Use port 587 (which Azure allows) to send all outbound mail through an authenticated SMTP relay service.

#### Popular SMTP Relay Services:

1. **SendGrid** (Recommended)
   - Free tier: 100 emails/day
   - SMTP: `smtp.sendgrid.net:587`
   - Requires API key

2. **Mailgun**
   - Free tier: 5,000 emails/month
   - SMTP: `smtp.mailgun.org:587`
   - Requires API key

3. **Amazon SES**
   - Pay-as-you-go pricing
   - SMTP: `email-smtp.us-east-1.amazonaws.com:587`
   - Requires AWS credentials

4. **Microsoft 365 Exchange**
   - If you have Office 365
   - SMTP: `smtp.office365.com:587`
   - Requires OAuth or app password

#### How to Configure Mailcow Relay:

1. **Get SMTP Relay Credentials**
   - Sign up for your chosen service
   - Get SMTP server, port, username, and password/API key

2. **Configure in Mailcow UI:**
   - Login to: https://mail.seemplifyai.com
   - Go to: **Configuration** → **Routing** tab
   - Click: **Add sender-dependent transport**
   - Fill in:
     - **Host:** `smtp.sendgrid.net` (or your relay service)
     - **Port:** `587`
     - **Username:** Your relay service username/API key
     - **Password:** Your relay service password/API key
     - **Security:** `STARTTLS` or `TLS`
   - Click: **Save**

3. **Assign Relay to Domain:**
   - Go to: **Mail setup** → **Domains**
   - Edit: `seemplifyai.com`
   - Select: Your relay host from **Sender-dependent transports** dropdown
   - Click: **Save**

4. **Test Email Delivery:**
   ```bash
   # Send test email from Mailcow
   docker exec mailcowdockerized-postfix-mailcow-1 sendmail -v test@example.com <<EOF
   Subject: Test Email
   From: info@seemplifyai.com
   
   This is a test email from Mailcow relay.
   EOF
   ```

---

### Option 2: Request Azure Port 25 Unblock

**⚠️ Note:** This may not be available for all subscription types.

#### Eligibility:
- ✅ Enterprise Agreement (EA) subscriptions
- ✅ Microsoft Customer Agreement for enterprise (MCA-E)
- ✅ Enterprise Dev/Test subscriptions
- ❌ Pay-As-You-Go subscriptions (may require approval)
- ❌ Free Trial subscriptions

#### Steps to Request Unblock:

1. **Via Azure Portal:**
   - Navigate to: **Virtual Networks** → Your VM's network
   - Go to: **Diagnose and Solve** section
   - Run: **"Cannot send email (SMTP-Port 25)"** diagnostic
   - Follow the exemption process

2. **Via Azure Support:**
   - Open Azure Support ticket
   - Request: "Remove port 25 outbound restriction"
   - Provide justification: "Running legitimate mail server (Mailcow)"

3. **After Approval:**
   ```bash
   # Stop and deallocate VM
   az vm deallocate --resource-group <resource-group> --name seemplify-vm
   
   # Start VM
   az vm start --resource-group <resource-group> --name seemplify-vm
   
   # Test port 25
   ssh seemplify@4.180.153.209 "timeout 5 nc -zv smtp.gmail.com 25"
   ```

---

### Option 3: Use Port 587 for All Outbound (Alternative)

**Note:** This only works if your relay service supports port 587. Most external mail servers expect port 25 for direct delivery.

---

## 🔍 Current Configuration Status

### Port Status:
| Port | Service | Direction | Status |
|------|---------|------------|--------|
| 25 | SMTP | Outbound | ❌ Blocked by Azure |
| 25 | SMTP | Inbound | ✅ Open (NSG rule exists) |
| 587 | Submission | Inbound | ✅ Working |
| 587 | Submission | Outbound | ✅ Working (to relay) |

### Mailcow Configuration:
- **Relayhost:** Not configured (empty)
- **Default Transport:** `smtp` (direct delivery on port 25)
- **Action Required:** Configure relay service

---

## 📋 Recommended Action Plan

### Immediate (Recommended):
1. ✅ Sign up for SendGrid (free tier: 100 emails/day)
2. ✅ Configure Mailcow relay using SendGrid SMTP
3. ✅ Test email delivery
4. ✅ Document relay credentials in `MAILCOW-CREDENTIALS.md`

### Alternative:
1. ⚠️ Check Azure subscription type
2. ⚠️ Request port 25 unblock if eligible
3. ⚠️ Wait for approval (can take 24-48 hours)
4. ⚠️ Restart VM after approval
5. ⚠️ Test direct delivery on port 25

---

## 🔐 Security Considerations

### Using SMTP Relay:
- ✅ Better IP reputation (relay service handles reputation)
- ✅ Higher deliverability rates
- ✅ No need to manage SPF/DKIM for relay IPs
- ⚠️ Additional cost (if exceeding free tier)
- ⚠️ Dependency on third-party service

### Direct Delivery (Port 25):
- ✅ No additional cost
- ✅ Full control
- ⚠️ Need to manage IP reputation
- ⚠️ May face deliverability issues
- ⚠️ Need proper SPF/DKIM/DMARC setup

---

## 📚 References

- [Azure SMTP Troubleshooting](https://learn.microsoft.com/en-us/azure/virtual-network/troubleshoot-outbound-smtp-connectivity)
- [Mailcow Relay Host Documentation](https://docs.mailcow.email/manual-guides/Postfix/u_e-postfix-relayhost/)
- [SendGrid SMTP Setup](https://docs.sendgrid.com/for-developers/sending-email/getting-started-smtp)
- [Mailgun SMTP Setup](https://documentation.mailgun.com/en/latest/user_manual.html#sending-via-smtp)

---

## ✅ Next Steps

1. **Choose relay service** (SendGrid recommended for free tier)
2. **Configure relay in Mailcow UI**
3. **Test email delivery**
4. **Update this document with chosen solution**

---

**Last Updated:** January 6, 2026
**Status:** Port 25 blocked - Relay configuration pending
