# Update SPF Record to Include Brevo Relay

**Date:** January 13, 2026  
**Priority:** HIGH - SPF soft-fail warnings  
**Status:** Ready to implement  
**Estimated Time:** 5 minutes

---

## Problem Identified

Current SPF record for seemplifyai.com:
```
v=spf1 mx -all
```

**Issues:**
1. Only authorizes `mx` (Mailcow's mail server: mail.seemplifyai.com)
2. Does NOT authorize Brevo relay (smtp-relay.brevo.com)
3. When Brevo sends email on your behalf via port 587, SPF soft-fails
4. Some email providers may reject or mark as spam due to SPF mismatch

**Current Brevo Configuration:**
- Relay: `[smtp-relay.brevo.com]:587`
- Login: `93ea9d001@smtp-brevo.com`
- Status: Active and working

---

## Implementation Steps

### Step 1: Login to Cloudflare (1 minute)

1. Access Cloudflare Dashboard:
   ```
   URL: https://dash.cloudflare.com
   Email: your Cloudflare login credentials
   ```

2. Select Domain:
   - Click: seemplifyai.com in domain list
   - Click: **DNS** > **Records**

---

### Step 2: Update SPF TXT Record (3 minutes)

1. Find Current SPF Record:
   - Look for TXT record with:
     - **Name:** `@`
     - **Content:** `v=spf1 mx -all`
   - Click: **Edit** button

2. Update SPF Content:
   - Replace content with:
     ```
     v=spf1 mx include:spf.brevo.com -all
     ```

3. Save Changes:
   - Click: **Save** button
   - Wait for confirmation message

**Explanation of Changes:**
```
OLD: v=spf1 mx -all
                  ^^^
                  Only authorizes Mailcow MX

NEW: v=spf1 mx include:spf.brevo.com -all
                  ^^^                     ^^^^^^^^^^^^^^^^^^^^
                  Authorizes: Mailcow MX + Brevo relay
```

---

### Step 3: Verify SPF Update (1 minute)

**Wait 5-10 minutes** for Cloudflare to propagate DNS changes.

#### Verification via CLI:
```bash
nslookup -type=TXT seemplifyai.com 8.8.8.8

# Should show:
# seemplifyai.com text = "v=spf1 mx include:spf.brevo.com -all"
```

#### Verification via Web Tool:
```
URL: https://mxtoolbox.com/SPF.aspx
Domain: seemplifyai.com
Expected: SPF Record Valid - PASS
```

---

## Why This Change is Needed

### Current SPF Behavior:
```
Email from: info@seemplifyai.com
     ↓
Mailcow Server (mail.seemplifyai.com)
     ↓
  Direct delivery (port 25 blocked) ✗
     ↓
  Via Brevo relay (port 587) ✓
     ↓
  Brevo sends to: recipient@gmail.com
     ↓
  Gmail checks SPF
     ↓
  SPF query: seemplifyai.com
     ↓
  DNS result: v=spf1 mx -all
     ↓
  Gmail: Is smtp-relay.brevo.com listed? NO
     ↓
  Gmail: SPF soft-fail ⚠️
```

### Updated SPF Behavior:
```
Email from: info@seemplifyai.com
     ↓
Mailcow Server (mail.seemplifyai.com)
     ↓
  Via Brevo relay (port 587) ✓
     ↓
  Brevo sends to: recipient@gmail.com
     ↓
  Gmail checks SPF
     ↓
  SPF query: seemplifyai.com
     ↓
  DNS result: v=spf1 mx include:spf.brevo.com -all
     ↓
  Gmail: Is smtp-relay.brevo.com listed? YES (via include:spf.brevo.com)
     ↓
  Gmail: SPF pass ✓
```

---

## Testing SPF Configuration

### Test 1: Verify Brevo SPF Record:
```bash
# Check what Brevo's SPF allows
dig txt spf.brevo.com +short

# Should return something like:
# v=spf1 ip4:52.27.0.0.0/24 include:sendgrid.net include:mailgun.org ~all
```

### Test 2: Email Authentication Test:
```bash
# Send test email to verifier
echo "Test email" | docker exec mailcowdockerized-postfix-mailcow-1 sendmail -f info@seemplifyai.com check-auth@verifier.port25.com

# Check response for:
# SPF Record: pass
```

---

## Expected Results

### Before SPF Update:
- SPF for direct Mailcow sends: PASS
- SPF for Brevo-relayed sends: SOFT-FAIL
- Email headers may show: `Received-SPF: softfail`
- Some providers may reject

### After SPF Update:
- SPF for direct Mailcow sends: PASS
- SPF for Brevo-relayed sends: PASS
- Email headers show: `Received-SPF: pass`
- All emails pass SPF authentication

---

## Troubleshooting

### SPF Still Fails After Update:
```bash
# Verify DNS propagation
nslookup -type=TXT seemplifyai.com 8.8.8.8

# If shows old SPF record:
# Wait another 5-10 minutes
# Check Cloudflare dashboard for errors
```

### Multiple SPF Records Warning:
```
# Cloudflare sometimes creates multiple TXT records
# You should only have ONE SPF record at @

# Check current SPF records:
nslookup -type=TXT seemplifyai.com 8.8.8.8

# If you see multiple "v=spf1" lines:
# Delete extras, keep only one
```

---

## References

### Documentation:
- [`access/MAILCOW-CREDENTIALS.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/MAILCOW-CREDENTIALS.md) - SPF configuration notes
- [`access/BREVO-CONFIGURATION.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/BREVO-CONFIGURATION.md) - Brevo relay details
- [`access/MAILCOW-SETUP-COMPLETE.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/MAILCOW-SETUP-COMPLETE.md) - DNS configuration

### External Resources:
- https://mxtoolbox.com/SPF.aspx - SPF verification tool
- https://www.dmarcianalyzer.com/spf/ - SPF analyzer
- https://support.google.com/mail/answer/33678 - SPF best practices

---

## Completion Checklist

- [ ] Login to Cloudflare dashboard
- [ ] Navigate to seemplifyai.com DNS records
- [ ] Find SPF TXT record for @
- [ ] Update SPF to: v=spf1 mx include:spf.brevo.com -all
- [ ] Save changes
- [ ] Wait 5-10 minutes for DNS propagation
- [ ] Verify SPF via nslookup
- [ ] Verify SPF passes at mxtoolbox.com
- [ ] Test email delivery to Gmail
- [ ] Check email headers for Received-SPF: pass

---

**After completing this task, SPF will pass for both direct Mailcow sends AND Brevo-relayed emails!**

**Next Task:** Fix DMARC record conflict (Task 3)
