# Test Email Deliverability - Complete Validation

**Date:** January 13, 2026  
**Priority:** VALIDATION - Verify all authentication methods  
**Status:** Ready to implement (after Tasks 1-4 complete)  
**Estimated Time:** 10 minutes

---

## Purpose

After completing Tasks 1-4 (DKIM, SPF, DMARC, PTR), validate that email deliverability has improved and all authentication methods pass.

**Testing Sequence:**
1. DKIM signing verification
2. SPF validation
3. DMARC policy verification
4. Comprehensive deliverability score
5. Real-world Gmail delivery test

---

## Prerequisites

**Required Before Testing:**
- DKIM TXT record added to Cloudflare (Task 1)
- SPF record updated to include Brevo (Task 2)
- Duplicate DMARC record deleted (Task 3)
- PTR record requested from Azure (Task 4)
- DNS propagation complete (wait 10+ minutes after DNS changes)

**Wait Times:**
- Cloudflare DNS: 5-10 minutes
- PTR record: 24-72 hours (after Azure approval)

---

## Test 1: DKIM Signing Verification

### via Command Line (Automated):
```bash
# SSH to server
ssh seemplify@4.180.153.209

# Check Postfix DKIM signing
docker logs mailcowdockerized-postfix-mailcow-1 --tail 100 | grep -i dkim

# Expected output:
# Signing DKIM for dkim._domainkey.seemplifyai.com
# DKIM signature added
```

### via Email Delivery (Manual):
```bash
# Send test email with detailed headers
echo "Test email body" | docker exec mailcowdockerized-postfix-mailcow-1 sendmail -v your-personal-email@gmail.com <<EOF
Subject: DKIM Signing Test - $(date)
From: info@seemplifyai.com
Message-ID: <$(uuidgen)@seemplifyai.com>

Testing DKIM cryptographic signature.
This email should be signed by Mailcow using DKIM.
EOF

# Check Postfix logs for DKIM signing
docker logs mailcowdockerized-postfix-mailcow-1 --tail 20
```

### Manual Verification:
1. Send email from info@seemplifyai.com to your personal Gmail
2. Open email in Gmail
3. Click: **Show original** (top right, 3 dots menu)
4. Click: **Show all**
5. Look for header: `DKIM-Signature`

**Expected Result:**
```
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;
  s=seemplifyai.com; d=example.com; h=Date:From:To:Subject;
  bh=base64hash; b=base64signature
```

---

## Test 2: SPF Validation

### via Automated Service:
```bash
# Send test email to Port25 verifier
echo "Test email" | docker exec mailcowdockerized-postfix-mailcow-1 sendmail -f info@seemplifyai.com check-auth@verifier.port25.com <<EOF
Subject: SPF Test
From: info@seemplifyai.com

Testing SPF, DKIM, and DMARC authentication.
EOF
```

### Verification:
You'll receive automated reply within 1-2 minutes at the same address. Check for:

**Expected Pass Results:**
```
==========================================================
Summary of Results
==========================================================
SPF check:          PASS
IP Address Heuristic check: PASS
DKIM check:           PASS (should be PASS after DKIM configured)
SpamAssassin check:   PASS
==========================================================
```

---

## Test 3: DMARC Policy Verification

### via Gmail Headers:
1. Send email from info@seemplifyai.com to your Gmail
2. Open email in Gmail
3. Click: **Show original** > **Show all**
4. Look for Authentication Results

**Expected Result:**
```
Authentication-Results: spf=pass dkim=pass dmarc=pass
From DKIM: seemplifyai.com
Policy: p=quarantine
```

### via Online Tool:
```
URL: https://mxtoolbox.com/DMARC.aspx
Domain: seemplifyai.com
Expected: DMARC Record Found - Valid - PASS
```

---

## Test 4: Comprehensive Deliverability Score

### mail-tester.com:
```bash
1. Go to: https://www.mail-tester.com
2. Get test email address (refreshes frequently)
3. Send email from info@seemplifyai.com to test address
4. Wait 1-2 minutes
5. Check score

Expected Results:
```
Email deliverability:
  - DKIM: ✅ Pass
  - SPF: ✅ Pass
  - DMARC: ✅ Pass
  - Score: 9/10 or 10/10

Spam analysis:
  - Spam flags: 0
  - Viruses: 0
  - Blacklisted: 0
```
```

### Gmail Spam Folder Test:
1. Send 10 test emails to your personal Gmail
2. Check inbox vs spam folder
3. Mark any in spam as "Not spam" to train Gmail
4. Repeat over 24 hours

**Goal:** 90%+ of emails should reach inbox

---

## Test 5: PTR Record Verification

### via Command Line:
```bash
# Check if PTR exists for your IP
nslookup 4.180.153.209

# Expected output:
# 209.153.180.4.in-addr.arpa name = mail.seemplifyai.com
```

### Alternative (dig):
```bash
dig +noall +answer 4.180.153.209 PTR

# Expected output:
# 4.180.153.209.in-addr.arpa. 100 IN PTR mail.seemplifyai.com
```

---

## Before vs After Comparison

### Before Fixes (Current State):
| Metric | Status | Impact |
|--------|--------|---------|
| DKIM | ❌ Missing | Emails go to spam |
| SPF | ⚠️ Weak | Brevo relay soft-fails |
| DMARC | ⚠️ Conflict | Inconsistent policy |
| PTR | ❌ Missing | Poor IP reputation |
| Overall Score | 5-6/10 | High spam placement |

### After Fixes (Expected):
| Metric | Expected Status | Improvement |
|--------|---------------|-------------|
| DKIM | ✅ Pass | Emails verified as legitimate |
| SPF | ✅ Pass | Brevo relay authorized |
| DMARC | ✅ Pass | Consistent quarantine policy |
| PTR | ✅ Configured | Better IP reputation |
| Overall Score | 9-10/10 | Emails reach inbox |

---

## Success Criteria

**All Tests Must Show:**
1. DKIM-Signature header present in emails
2. SPF check: PASS (from verifier.port25.com)
3. DMARC check: PASS (from verifier.port25.com)
4. Gmail Authentication-Results: spf=pass dkim=pass dmarc=pass
5. mail-tester.com score: 9/10 or higher
6. PTR record: 4.180.153.209 → mail.seemplifyai.com
7. 90%+ of test emails reach Gmail inbox (not spam)

---

## Troubleshooting Failed Tests

### DKIM Still Fails:
```bash
# Check if DKIM is enabled in Mailcow
ssh seemplify@4.180.153.209
docker exec mailcowdockerized-mysql-mailcow-1 mysql -u mailcow -p3w8aLaw8jyknrgbs3qFfDgdD4LRQ mailcow -e "SELECT * FROM dkim WHERE domain LIKE 'seemplify%';"

# If no rows found:
# 1. Login to Mailcow UI: https://mail.seemplifyai.com
# 2. Configuration > DKIM keys
# 3. Enable DKIM for seemplifyai.com
# 4. Save changes
```

### SPF Still Fails:
```bash
# Verify DNS propagation
nslookup -type=TXT seemplifyai.com 8.8.8.8

# If shows old SPF:
# Wait 5-10 more minutes
# Check Cloudflare dashboard for errors
```

### DMARC Still Conflicts:
```bash
# Check for duplicate DMARC records
nslookup -type=TXT _dmarc.seemplifyai.com 8.8.8.8

# If still shows two records:
# 1. Delete Brevo's DMARC record
# 2. Wait 5-10 minutes for propagation
# 3. Re-check with nslookup
```

### PTR Still Missing:
```bash
# If PTR not configured after 24-72 hours:
# 1. Check Azure Portal for PTR status
# 2. Contact Azure support via support ticket
# 3. Verify subscription type supports PTR
```

### Emails Still Going to Spam:
```bash
# Check spam filter scores
docker logs mailcowdockerized-rspamd-mailcow-1 --tail 50

# Look for high scores (>5)
# Check for blacklisted IPs
# Review content being flagged

# Send email to check-auth@verifier.port25.com
# Review detailed report for specific issues
```

---

## Quick Validation Commands

### Check All DNS Records:
```bash
# Check SPF
nslookup -type=TXT seemplifyai.com 8.8.8.8 | grep "v=spf1"

# Check DKIM
nslookup -type=TXT dkim._domainkey.seemplifyai.com 8.8.8.8 | grep "v=DKIM1"

# Check DMARC
nslookup -type=TXT _dmarc.seemplifyai.com 8.8.8.8 | grep "v=DMARC1"

# Check PTR
nslookup 4.180.153.209
```

### Check Mailcow Logs:
```bash
# DKIM signing logs
docker logs mailcowdockerized-postfix-mailcow-1 2>&1 | grep -i dkim

# SPF/DMARC authentication logs
docker logs mailcowdockerized-postfix-mailcow-1 --tail 100

# Spam filter activity
docker logs mailcowdockerized-rspamd-mailcow-1 --tail 50
```

---

## References

### Documentation:
- [`access/IMPLEMENT-DKIM-AUTHENTICATION.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/IMPLEMENT-DKIM-AUTHENTICATION.md) - DKIM setup
- [`access/UPDATE-SPF-RECORD.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/UPDATE-SPF-RECORD.md) - SPF update
- [`access/FIX-DMARC-CONFLICT.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/FIX-DMARC-CONFLICT.md) - DMARC fix
- [`access/REQUEST-PTR-RECORD.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/REQUEST-PTR-RECORD.md) - PTR request
- [`access/MAILCOW-CREDENTIALS.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/MAILCOW-CREDENTIALS.md) - Mailcow config

### Testing Tools:
- https://www.mail-tester.com - Comprehensive email testing
- https://mxtoolbox.com/DMARC.aspx - DMARC verification
- https://mxtoolbox.com/SPF.aspx - SPF verification
- https://mxtoolbox.com/DKIM.aspx - DKIM verification
- check-auth@verifier.port25.com - Automated authentication test
- https://www.dmarcianalyzer.com - DMARC analysis
- https://www.mailflow.ai - Email deliverability insights

---

## Completion Checklist

- [ ] Wait 10+ minutes after DNS changes (DKIM, SPF, DMARC)
- [ ] Wait 24-72 hours after PTR request approval
- [ ] Send test email to check-auth@verifier.port25.com
- [ ] Verify SPF: PASS in response
- [ ] Verify DKIM: PASS in response
- [ ] Verify DMARC: PASS in response
- [ ] Send test email to personal Gmail account
- [ ] Check Gmail headers for DKIM-Signature
- [ ] Check Gmail headers for Authentication-Results: spf=pass dkim=pass dmarc=pass
- [ ] Test at mail-tester.com (score 9/10+)
- [ ] Check PTR record via nslookup 4.180.153.209
- [ ] Send 10 test emails over 24 hours
- [ ] Verify 90%+ reach inbox (not spam)
- [ ] Review mail-tester.com detailed report
- [ ] Document final scores and improvement

---

**After completing this task, you'll have complete email deliverability validation with all authentication methods working properly!**

This completes the email deliverability improvement plan. All 5 tasks are now documented and ready for implementation.
