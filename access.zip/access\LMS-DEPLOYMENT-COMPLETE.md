# Frappe LMS - Deployment Complete ✅

**Date:** January 13, 2026  
**Last Updated:** January 14, 2026  
**Status:** 🚀 **FULLY OPERATIONAL & LIVE**  
**CI/CD:** ✅ GitHub Actions Auto-Deploy Enabled  
**Hub:** ✅ Added to IDP Hub (https://auth.seemplifyai.com)  
**Branding:** ✅ "Seemplify LMS" (login page, sidebar, emails)  
**SSO:** ✅ **WORKING!** OIDC SSO with Seemplify IDP + LMS Roles

---

## 🔐 Login Credentials

### LMS Web Application
```
URL:        https://lms.seemplifyai.com/lms/
Username:   Administrator
Password:   admin123
```

### Direct Access Links
| Page | URL |
|------|-----|
| **Home** | https://lms.seemplifyai.com/lms/ |
| **Login** | https://lms.seemplifyai.com/ |
| **Admin Desk** | https://lms.seemplifyai.com/app |

---

## 📊 Service Status

### Docker Services
```bash
# Check service status
ssh seemplify@4.180.153.209 "docker service ls | grep lms"
```

| Service | Status | Image |
|---------|--------|-------|
| lms_frappe | ✅ 1/1 | frappe/bench:latest |
| lms_mariadb | ✅ 1/1 | mariadb:10.8 |
| lms_redis | ✅ 1/1 | redis:alpine |

---

## 🗄️ Database Credentials

### MariaDB
```
Host:       lms_mariadb (internal Docker network)
Port:       3306
Root Password: LmsSecure2026! (or env variable MYSQL_ROOT_PASSWORD)
Database:   _<site_name> (auto-created by Frappe)
```

### Redis
```
Host:       lms_redis (internal Docker network)
Port:       6379
Password:   None (internal only)
```

---

## 🌐 DNS Configuration

### Cloudflare DNS Record
```
Type:       A
Name:       lms
Content:    4.180.153.209
Proxy:      ✅ Enabled (orange cloud)
TTL:        Auto
Record ID:  f1018bf5e47c732d21f74aabbc95d33d
```

### DNS Verification
```bash
nslookup lms.seemplifyai.com 8.8.8.8
# Returns Cloudflare proxy IPs (188.114.96.0, 188.114.97.0)
```

---

## 🔧 Server Access

### SSH Access
```bash
ssh seemplify@4.180.153.209
```

### View LMS Logs
```bash
# All logs
ssh seemplify@4.180.153.209 "docker service logs lms_frappe --tail 100"

# Web server logs
ssh seemplify@4.180.153.209 "docker service logs lms_frappe 2>&1 | grep web.1"

# Database logs
ssh seemplify@4.180.153.209 "docker service logs lms_mariadb --tail 50"
```

### Service Management
```bash
# Restart LMS
ssh seemplify@4.180.153.209 "docker service update --force lms_frappe"

# Scale service
ssh seemplify@4.180.153.209 "docker service scale lms_frappe=2"

# Remove stack (CAUTION!)
ssh seemplify@4.180.153.209 "docker stack rm lms"

# Redeploy stack
ssh seemplify@4.180.153.209 "cd ~/lms-deploy/lms/docker && docker stack deploy -c docker-compose.yml lms"
```

---

## 📁 File Locations

### On Server
```
Repository Clone: ~/lms-deploy/
Docker Compose:   ~/lms-deploy/lms/docker/docker-compose.yml
Init Script:      ~/lms-deploy/lms/docker/init.sh
```

### On GitHub
```
Repository:       https://github.com/michaelegbo/seemplify.git
Branch:           main
Docker Compose:   lms/docker/docker-compose.yml
Init Script:      lms/docker/init.sh
Deployment Plan:  lms/DOKPLOY-DEPLOYMENT-PLAN.md
```

---

## 🎓 LMS Features Available

### For Administrators
- 📚 **Courses** - Create and manage courses
- 📋 **Programs** - Learning program management
- 👥 **Batches** - Student batch management
- 💼 **Jobs** - Job board integration
- 📊 **Statistics** - Analytics dashboard

### For Instructors
- ✍️ **Quizzes** - Create and grade quizzes
- 📝 **Assignments** - Assignment creation and grading
- 💻 **Programming Exercises** - Code exercise management

### For Students
- 📖 Course enrollment
- 📋 Progress tracking
- 🏆 Certifications

---

## 🔑 Login with Seemplify (SSO) - ✅ WORKING!

### Feature Status: FULLY OPERATIONAL
The LMS login page has a branded "Login with Seemplify" button that enables SSO via the Identity Provider.

**Tested & Verified:** January 14, 2026 - User "Michael Tony Egbo" successfully logged in via SSO.

### How it Works
1. User visits LMS at `https://lms.seemplifyai.com/lms-login` (custom branded page)
2. Clicks "Login with Seemplify" button
3. Redirects to `https://auth.seemplifyai.com/auth` for authentication
4. After IDP login, redirects back to LMS callback
5. LMS exchanges code for token and creates/updates user
6. User is logged in with their name displayed in sidebar

### OIDC Configuration
```
Client ID:       lms
Client Secret:   lms-secret
Authorize URL:   https://auth.seemplifyai.com/auth
Token URL:       https://auth.seemplifyai.com/token
Userinfo URL:    https://auth.seemplifyai.com/me
Callback URL:    https://lms.seemplifyai.com/api/method/frappe.integrations.oauth2_logins.custom/Seemplify
Scopes:          openid email profile
Auth Method:     client_secret_post
```

### LMS Role Claim Structure
```json
{
  "lms_role": {
    "role": "course_creator",
    "frappe_role_name": "Course Creator",
    "permissions": ["create_courses", "manage_courses", "grade_assignments", ...],
    "organization_id": "..."
  }
}
```

### Role Mapping (IDP → Frappe)
| IDP Role | Frappe Role | User Type |
|----------|-------------|-----------|
| student | LMS Student | Website User |
| course_creator | Course Creator | System User |
| moderator | Moderator | System User |
| batch_evaluator | Batch Evaluator | System User |
| course_evaluator | Course Evaluator | System User |

### Files Involved
- `Identityprovider/clients.json` - OIDC client config
- `Identityprovider/src/models/LmsRole.js` - LMS role model
- `lms/lms/fixtures/social_login_key.json` - Social Login fixture
- `lms/lms/public/js/seemplify_login.js` - Login button JS

---

## 🔒 Security Notes

1. **Change Admin Password**: After first login, change the default password
2. **SSL/TLS**: Handled by Traefik via Let's Encrypt (auto-renewed)
3. **Cloudflare Proxy**: DDoS protection and CDN enabled
4. **Internal Networks**: Database and Redis only accessible within Docker network

### Change Admin Password
1. Login to https://lms.seemplifyai.com/
2. Click user icon → Settings
3. Change password in Profile settings

---

## 🛠️ Troubleshooting

### LMS Not Loading
```bash
# Check if services are running
ssh seemplify@4.180.153.209 "docker service ls | grep lms"

# Check frappe logs for errors
ssh seemplify@4.180.153.209 "docker service logs lms_frappe --tail 100 2>&1 | grep -i error"

# Restart the service
ssh seemplify@4.180.153.209 "docker service update --force lms_frappe"
```

### Database Connection Issues
```bash
# Check MariaDB status
ssh seemplify@4.180.153.209 "docker service logs lms_mariadb --tail 50"

# Verify network connectivity
ssh seemplify@4.180.153.209 "docker network inspect lms_lms-network"
```

### SSL Certificate Issues
```bash
# Check Traefik logs
ssh seemplify@4.180.153.209 "docker logs dokploy-traefik --tail 100 | grep lms"
```

---

## 📋 Deployment Summary

| Component | Value |
|-----------|-------|
| **Application** | Frappe LMS |
| **Domain** | lms.seemplifyai.com |
| **Server IP** | 4.180.153.209 |
| **Deployment Method** | Docker Swarm Stack |
| **Reverse Proxy** | Traefik (via Dokploy) |
| **SSL** | Let's Encrypt (auto) |
| **CDN/Proxy** | Cloudflare |
| **Database** | MariaDB 10.8 |
| **Cache** | Redis Alpine |

---

## 🎨 Branding Configuration

### Login Page
- **Title:** "Login to Seemplify LMS"
- **Source:** `site_config.json` → `app_name` field

### Sidebar Title
- **Title:** "Seemplify LMS"  
- **Source:** Vue.js components (`AppSidebar.vue`, etc.)

### How Branding is Applied
1. `site_config.json` sets `app_name: "Seemplify Learning"`
2. Database `tabSingles` → `System Settings` → `app_name`
3. Database `tabSingles` → `Website Settings` → `app_name`
4. Vue.js components use these values

### To Change Branding
```bash
# Update via database (run on server via SSH)
ssh seemplify@4.180.153.209

# Inside server - update database (DB: _931a599d893c0e21 = lms.seemplifyai.com, 17 courses)
docker exec -i $(docker ps -q -f name=lms_mariadb) mysql -uroot -pLmsSecure2026! _931a599d893c0e21 << 'SQL'
DELETE FROM tabSingles WHERE field='app_name';
INSERT INTO tabSingles (doctype, field, value) VALUES ('System Settings', 'app_name', 'Your New Name');
INSERT INTO tabSingles (doctype, field, value) VALUES ('Website Settings', 'app_name', 'Your New Name');
SQL

# Flush Redis cache
docker exec $(docker ps -q -f name=lms_redis) redis-cli FLUSHALL
```

---

## 🏠 IDP Hub Integration

### App Visible in Hub
```
App ID:       lms
Display Name: Seemplify LMS
Icon:         academic-cap
Color:        #06b6d4 (cyan)
Category:     productivity
Auth Type:    oidc (SSO via Seemplify)
```

### LMS Role System (Frappe LMS Roles)
The LMS requires users to have a role before accessing. Roles are managed in the IDP and passed to Frappe LMS via OIDC claims:

| IDP Role | Frappe Role | Desk Access | Permissions |
|----------|-------------|-------------|-------------|
| **student** | LMS Student | ❌ No | Enroll courses, submit work, take quizzes, earn certificates |
| **course_creator** | Course Creator | ✅ Yes | Create/edit courses, chapters, lessons, quizzes, exercises |
| **moderator** | Moderator | ✅ Yes | Full LMS admin - publish courses, manage all content & settings |
| **batch_evaluator** | Batch Evaluator | ✅ Yes | Manage batches, grade assignments, view student progress |
| **course_evaluator** | Course Evaluator | ✅ Yes | Evaluate certifications, issue & manage certificates |

### Role Management UI
- **Location:** IDP → Organizations → [Org Name] → 🎓 LMS Roles
- **URL:** `https://auth.seemplifyai.com/organizations/{orgId}/lms-roles`
- **Features:** Assign roles to members, view pending access requests, approve/deny requests

### Access via Hub
1. Go to https://auth.seemplifyai.com/
2. Login to the hub
3. Click on "Seemplify LMS" tile
4. **If no LMS role:** Admin selects role, Non-admin requests access
5. **If has role:** SSO login to LMS

### API Endpoints for LMS Roles
```bash
# Get my LMS role
curl -s https://auth.seemplifyai.com/api/lms/roles/{orgId}/my-role

# Assign LMS role (admin only)
curl -X POST https://auth.seemplifyai.com/api/lms/roles/{orgId} \
  -H "Content-Type: application/json" \
  -d '{"userId": "...", "role": "course_creator"}'

# Request access (non-admin)
curl -X POST https://auth.seemplifyai.com/api/lms/access-requests/{orgId} \
  -H "Content-Type: application/json" \
  -d '{"role": "student", "reason": "I want to learn!"}'

# Get role options
curl -s https://auth.seemplifyai.com/api/lms/role-options

# Approve access request (admin only)
curl -X PUT https://auth.seemplifyai.com/api/lms/access-requests/{orgId}/{requestId}/approve

# Deny access request (admin only)
curl -X PUT https://auth.seemplifyai.com/api/lms/access-requests/{orgId}/{requestId}/deny
```

### API Verification
```bash
# Check LMS is in apps list
curl -s https://auth.seemplifyai.com/api/apps | jq '.[] | select(.appId=="lms")'
```

---

## 🔄 CI/CD Auto-Deployment

### GitHub Actions Workflow
```
Workflow File:  .github/workflows/deploy-lms.yml
Trigger:        Push to main branch with changes in lms/** folder
Secret Used:    SSH_PRIVATE_KEY (configured in repo secrets)
```

### How Auto-Deploy Works
1. Push code changes to `main` branch in `lms/` folder
2. GitHub Actions workflow triggers automatically
3. Workflow SSHs into the Azure VM
4. Pulls latest code from GitHub
5. Re-deploys Docker Swarm stack
6. Verifies services are running

### Manual Trigger
```bash
# Via GitHub CLI
gh workflow run "Deploy LMS"

# Or make a code change and push
git add . && git commit -m "update" && git push origin main
```

### View Deployment Status
```bash
# List recent runs
gh run list --workflow=deploy-lms.yml --limit 5

# Watch current run
gh run watch <run-id>

# View logs
gh run view <run-id> --log
```

---

## 🔗 Related Documentation

- [Server Access Guide](./SERVER-ACCESS.md)
- [Dokploy Credentials](./DOKPLOY-CREDENTIALS.md)
- [GitHub Actions Config](./GITHUB-ACTIONS-CONFIG.md)

---

## 📞 Quick Reference

| What | Where |
|------|-------|
| **LMS URL** | https://lms.seemplifyai.com/lms/ |
| **Admin Login** | Administrator / admin123 |
| **Server IP** | 4.180.153.209 |
| **SSH Access** | ssh seemplify@4.180.153.209 |
| **Dokploy Dashboard** | http://4.180.153.209:3000 |

---

**🎉 Frappe LMS is live and ready for use!**

---

## 🐛 Issues Fixed (January 14, 2026)

### OIDC SSO Issues Resolved

1. **`invalid_request` error on `/oidc/auth`**
   - **Cause:** Wrong OIDC endpoint path
   - **Fix:** Changed from `/oidc/auth` to `/auth` (oidc-provider mounts at root)

2. **`redirect_uri mismatch` error**
   - **Cause:** Frappe was sending relative redirect_uri, IDP expected absolute
   - **Fix:** Set `host_name: "lms.seemplifyai.com"` in site_config.json

3. **`sign_ups` configuration error**
   - **Cause:** Frappe expected string "Allow" not integer 1
   - **Fix:** Updated fixture to use `"sign_ups": "Allow"`

4. **Token endpoint authentication failure**
   - **Cause:** Frappe's rauth library uses `client_secret_post`, IDP expected `client_secret_basic`
   - **Fix:** Changed `token_endpoint_auth_method` to `client_secret_post` in clients.json

5. **Two login pages (old and new)**
   - **Cause:** Default `/login` route still active
   - **Fix:** Added redirect rule in hooks.py: `/login` → `/lms-login`

### Key Configuration Files Changed
- `lms/lms/fixtures/social_login_key.json` - Absolute redirect_url, sign_ups: "Allow"
- `Identityprovider/clients.json` - token_endpoint_auth_method: "client_secret_post"
- `Identityprovider/src/index.js` - Debug logging, PKCE disabled for LMS
- `lms/lms/hooks.py` - Website route rules for login redirect

---

**Last Updated:** January 14, 2026
