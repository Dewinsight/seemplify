# Frappe LMS Email Queue Access Methods

**Date:** February 2, 2026  
**Status:** Research Complete - Multiple Methods Available

---

## Overview

This document provides methods to access and check pending emails in Frappe LMS via API, command line, or other approaches.

---

## Method 1: REST API Access (Requires Authentication)

### Endpoint Structure
```
GET /api/resource/Email Queue
```

### URL Parameters
| Parameter | Description | Example |
|-----------|-------------|---------|
| `filters` | Filter by status | `[["Email Queue","status","=","Pending"]]` |
| `fields[]` | Specific fields to return | `["name","sender","recipient","subject"]` |
| `limit_page_length` | Number of records | `100` |
| `limit_start` | Pagination offset | `0` |

### Example URLs
```
# Get pending emails
GET /api/resource/Email Queue?filters=[["Email Queue","status","=","Pending"]]

# Get failed emails
GET /api/resource/Email Queue?filters=[["Email Queue","status","=","Failed"]]

# Get all emails with specific fields
GET /api/resource/Email Queue?fields=["name","sender","recipient","subject","creation","status"]
```

### Authentication
```
Authorization: token api_key:api_secret
```

### Common Filters
```python
# Filter by status
filters = [["Email Queue", "status", "=", "Pending"]]

# Filter by date range
filters = [["Email Queue", "creation", ">", "2026-01-01"]]

# Filter by recipient
filters = [["Email Queue", "recipient", "=", "user@example.com"]]
```

---

## Method 2: Python API Script

### Basic Script Template
```python
import requests
import json

api_key = "YOUR_API_KEY"
api_secret = "YOUR_API_SECRET"
site_url = "https://lms.seemplifyai.com"

def get_pending_emails():
    url = f"{site_url}/api/resource/Email Queue"
    params = {
        "filters": json.dumps([["Email Queue", "status", "=", "Pending"]]),
        "fields": json.dumps(["name", "sender", "recipient", "subject", "creation"]),
        "limit_page_length": 100
    }
    
    response = requests.get(url, params=params, auth=(api_key, api_secret))
    
    if response.status_code == 200:
        data = response.json()
        return data.get("data", [])
    else:
        print(f"Error: {response.status_code}")
        return []
```

---

## Method 3: Bench Commands (Server Access Required)

### Check Email Queue Status
```bash
# SSH to server
ssh seemplify@4.180.153.209

# List pending emails (if command available)
bench --site lms.seemplifyai.com execute frappe.email.doctype.email_queue.email_queue.get_queue_count

# Check background jobs
bench --site lms.seemplifyai.com list-background-jobs

# Restart scheduler to process pending emails
bench --site lms.seemplifyai.com restart-scheduler
```

### Manual Email Processing
```bash
# Process email queue manually
bench --site lms.seemplifyai.com execute frappe.email.queue.flush

# Clear stuck emails
bench --site lms.seemplifyai.com execute frappe.email.queue.clear_failed
```

---

## Method 4: Via Docker Container

### Exec into Container
```bash
ssh seemplify@4.180.153.209

# Get container name
docker ps | grep lms

# Exec into container
docker exec -it lms_frappe.1.i5avptg297rhj3f94797wpcez bash

# Inside container, check database
cd /home/frappe/frappe-bench
bench --site lms.seemplifyai.com execute frappe.email.doctype.email_queue.email_queue.get_queue_count
```

### Query Database Directly
```bash
# Inside Docker container
mysql -h lms_mariadb -u root -p

# Query email queue
USE _abd03c6e65a3520d;
SELECT COUNT(*) FROM tabEmailQueue WHERE status = 'Pending';
SELECT * FROM tabEmailQueue WHERE status = 'Pending' LIMIT 10;
```

---

## Method 5: Via Frappe Desk (UI)

### Easiest Method - No Code Required

1. **Access Frappe Desk:**
   - Go to: `https://lms.seemplifyai.com/app/email-queue`
   - Or navigate through: Desk > Email > Email Queue

2. **View Pending Emails:**
   - The Email Queue list shows all pending, sent, and failed emails
   - Filter by "Status = Pending" to see stuck emails
   - Click on any email to view details

3. **Actions Available:**
   - View email details
   - See sender/recipient info
   - Check creation date
   - See error messages (for failed emails)
   - Resend failed emails manually

4. **Related DocTypes:**
   - `/app/email-queue` - Main email queue
   - `/app/email-account` - Email account settings
   - `/app/email-unsubscribe` - Unsubscribe requests

---

## Method 6: Background Jobs API

### Check Processing Status
```bash
# API endpoint
GET /api/method/frappe.core.doctype.background_jobs.background_jobs.get_info

# Response includes:
# - Number of queued jobs
# - Number of running jobs  
# - Failed jobs
# - Last run time
```

---

## Method 7: Direct Database Query (via Docker)

### Script for Database Access
```bash
# SSH to server
ssh seemplify@4.180.153.209

# Copy SQL script to container
docker cp check_emails.sql lms_frappe.1.i5avptg297rhj3f94797wpcez:/tmp/check_emails.sql

# Execute
docker exec lms_frappe.1.i5avptg297rhj3f94797wpcez mysql -h lms_mariadb -u _abd03c6e65a3520d -p DATABASE_NAME < /tmp/check_emails.sql
```

### SQL Queries
```sql
-- Count pending emails
SELECT COUNT(*) as pending_count FROM tabEmailQueue WHERE status = 'Pending';

-- Count failed emails  
SELECT COUNT(*) as failed_count FROM tabEmailQueue WHERE status = 'Failed';

-- Get pending emails with details
SELECT name, sender, recipient, subject, creation, status 
FROM tabEmailQueue 
WHERE status = 'Pending' 
ORDER BY creation DESC 
LIMIT 50;

-- Get failed emails with errors
SELECT name, sender, recipient, subject, error, creation 
FROM tabEmailQueue 
WHERE status = 'Failed' 
ORDER BY creation DESC 
LIMIT 50;
```

---

## Troubleshooting

### API Authentication Issues

**Problem:** Getting 401 Authentication Error

**Solutions:**
1. Verify API credentials are correct
2. Check if API key has proper permissions
3. Try generating new API credentials:
   - Go to `/app/user/YOUR_USER`
   - Scroll to "API Access"
   - Generate new API key/secret

### API Returns 417 Error

**Problem:** Precondition Failed (417)

**Solutions:**
1. Endpoint requires authentication - include Authorization header
2. Session may have expired - refresh session
3. Check if method exists - verify endpoint URL

### Cannot Connect to Docker MySQL

**Problem:** MySQL connection errors

**Solutions:**
1. Verify container is running: `docker ps | grep mariadb`
2. Check database credentials in `site_config.json`
3. Use correct database host: `lms_mariadb` (not localhost)

---

## Quick Reference - Access Methods

| Method | Difficulty | Requires Server Access | Real-time | Best For |
|--------|-----------|------------------------|-----------|----------|
| Frappe Desk UI | Easy | No | Yes | Quick checks |
| REST API | Medium | No | Yes | Automation |
| Bench Commands | Medium | Yes | Yes | Server management |
| Docker + MySQL | Hard | Yes | Yes | Deep diagnostics |
| Python Script | Medium | No | Yes | Custom reports |

---

## Recommended Approach

**For Quick Checks:**
1. Go to `/app/email-queue` in Frappe Desk
2. View pending emails visually
3. Take action (resend, delete, etc.)

**For Automation:**
1. Use REST API with proper authentication
2. Create Python scripts to monitor queue
3. Set up alerts for failed emails

**For Troubleshooting:**
1. SSH into server
2. Use bench commands
3. Check Docker logs: `docker logs lms_frappe.1.i5avptg297rhj3f94797wpcez --tail 100`

---

## Next Steps

1. **Try Frappe Desk UI** - Go to `/app/email-queue` to see pending emails
2. **Check Docker logs** - Look for email-related errors
3. **Verify email configuration** - Ensure Brevo SMTP is working
4. **Test signup flow** - Create a test user to verify emails are sent

---

**Document Created:** February 2, 2026  
**Research Status:** Complete ✅
