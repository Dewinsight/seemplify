# Outlook Connection Fix - Complete Guide

**Date:** January 19, 2026  
**Issue:** "Something went wrong, you may need an app password"

---

## ✅ Solution: Use Manual Setup with Basic Authentication

**The key is to force Outlook to use basic authentication instead of OAuth.**

---

## 📋 Step-by-Step Outlook Setup

### 1. Remove Existing Account (if any)
- **File** → **Account Settings** → **Account Settings**
- Select account → **Remove**

### 2. Add Account Manually

**File** → **Add Account** → **Manual setup or additional server types** → **Next**

### 3. Select Account Type

**Choose: "POP or IMAP"** (NOT Exchange/Office 365) → **Next**

### 4. Enter Account Information

**For Michael:**
```
Your Name: Michael
Email Address: michael@paddie.io
Account Type: IMAP
Incoming mail server: mail.seemplifyai.com
Outgoing mail server (SMTP): mail.seemplifyai.com
User Name: michael@paddie.io
Password: MichaelPass123!
✅ Remember password
```

**For Ryan:**
```
Your Name: Ryan
Email Address: ryan@paddie.io
Account Type: IMAP
Incoming mail server: mail.seemplifyai.com
Outgoing mail server (SMTP): mail.seemplifyai.com
User Name: ryan@paddie.io
Password: RyanPass123!
✅ Remember password
```

### 5. Click "More Settings"

### 6. Outgoing Server Tab
- ✅ **"My outgoing server (SMTP) requires authentication"**
- Select **"Use same settings as my incoming mail server"**

### 7. Advanced Tab

**Incoming server (IMAP):**
- Port: `993`
- Encryption: **SSL/TLS**
- ✅ **"This server requires an encrypted connection (SSL/TLS)"**

**Outgoing server (SMTP):**
- Port: `587`
- Encryption: **STARTTLS**
- ✅ **"This server requires an encrypted connection"**

### 8. Security Tab (if available)
- Authentication: **"Basic Authentication"** or **"Password"**
- **Do NOT** select OAuth

### 9. Click OK → Next → Test Account Settings

---

## ⚠️ Critical Points

1. **Use "POP or IMAP"** - NOT Exchange/Office 365
2. **Full email as username:** `michael@paddie.io` (not just `michael`)
3. **Basic Authentication** - NOT OAuth
4. **Ports:** IMAP `993`, SMTP `587`
5. **Encryption:** IMAP `SSL/TLS`, SMTP `STARTTLS`

---

## 🔧 If Still Not Working

### Option 1: Reset Password via Webmail
1. Login to https://mail.seemplifyai.com/SOGo/
2. Go to **Preferences** → **Security** → **Change Password**
3. Set new password
4. Use new password in Outlook

### Option 2: Use Webmail Instead
- Access: https://mail.seemplifyai.com/SOGo/
- Login: `michael@paddie.io` / `MichaelPass123!`
- Full email functionality in browser

### Option 3: Check Mailcow Admin
1. Login to https://mail.seemplifyai.com (admin)
2. Go to **Configuration** → **Mailboxes**
3. Find `michael@paddie.io` or `ryan@paddie.io`
4. Click **Edit** → **Change Password**
5. Set new password
6. Use in Outlook

---

## 📱 Outlook Mobile

1. **Remove account** from Outlook app
2. **Add Account** → **Advanced Setup** → **IMAP**
3. Enter settings manually (same as desktop)
4. **Do NOT** use auto-setup

---

## ✅ Verified Settings

**Server:** `mail.seemplifyai.com`  
**IMAP:** Port `993`, SSL/TLS  
**SMTP:** Port `587`, STARTTLS  
**Authentication:** Basic (Password)  
**Username:** Full email address  
**Password:** Account password

---

**Last Updated:** January 19, 2026  
**Status:** ✅ Use Manual Setup with Basic Authentication
