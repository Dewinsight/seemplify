# Huly and Zulip Cleanup Report

**Date:** February 3, 2026
**Performed by:** Deploy Subagent

---

## Summary

Successfully cleaned up orphaned Huly and Zulip applications from the Dokploy deployment system. Both applications were compose applications with no corresponding Docker containers running.

---

## Database Records Deleted

### Compose Applications (Primary Records)

#### Huly
- **Compose ID:** `jE26KpK1rS0GNC75TvHXM`
- **Name:** huly
- **Status:** Deleted from `compose` table
- **Related Records Removed:**
  - 1 deployment record
  - 1 domain record (seemplify-huly-c4a475-127-0-0-1.traefik.me)

#### Zulip (seemplify-zulip)
- **Compose ID:** `QS_-rfrjZ5wEYJ2Bvm0gE`
- **Name:** seemplify-zulip
- **Status:** Deleted from `compose` table
- **Related Records Removed:**
  - 6 deployment records
  - 1 domain record (chat.seemplifyai.com)

### Foreign Key Cascade Deletion

All related records were automatically deleted due to CASCADE delete constraints on:
- `deployment` table (composeId foreign key)
- `domain` table (composeId foreign key)
- `mount` table (composeId foreign key)
- `schedule` table (composeId foreign key)
- `volume_backup` table (composeId foreign key)
- `backup` table (composeId foreign key)

---

## Docker Resources Checked and Verified Clean

### Containers
- **Result:** No Huly or Zulip containers found
- **Verification:** `docker ps -a | grep -iE 'huly|zulip'` returned no results

### Networks
- **Result:** No Huly or Zulip networks found
- **Verification:** `docker network ls | grep -iE 'huly|zulip'` returned no results

### Volumes
- **Result:** No Huly or Zulip volumes found
- **Verification:** `docker volume ls | grep -iE 'huly|zulip'` returned no results

---

## Remaining Compose Applications

After cleanup, the following compose applications remain:

1. **open-webui** (ID: 352AfhGq59BmN5xH5dkGg)
2. **outline** (ID: JW_3pgIHX65k41uUO-wVC)

---

## Verification Commands Used

```bash
# Database queries
docker exec dokploy-postgres.1.* psql -U dokploy -d dokploy -c "SELECT \"composeId\", name FROM compose ORDER BY name;"
docker exec dokploy-postgres.1.* psql -U dokploy -d dokploy -c "SELECT COUNT(*) FROM compose WHERE name ILIKE '%huly%' OR name ILIKE '%zulip%';"

# Docker resource checks
docker ps -a | grep -iE 'huly|zulip'
docker network ls | grep -iE 'huly|zulip'
docker volume ls | grep -iE 'huly|zulip'
```

---

## Notes

1. **Domain DNS Record for chat.seemplifyai.com:** The domain record for chat.seemplifyai.com was associated with the orphaned Zulip application and has been removed from the Dokploy database. However, the actual DNS record in Cloudflare was not modified. If this domain is no longer needed, it should be manually removed from Cloudflare DNS.

2. **No Application Table Entries:** Neither Huly nor Zulip had entries in the regular `application` table - they were only compose applications.

3. **Automatic Cascade Deletion:** The PostgreSQL foreign key constraints with `ON DELETE CASCADE` ensured that all related records (deployments, domains, etc.) were automatically removed when the compose applications were deleted.

---

## Commands Executed

```bash
# Connected to server
ssh seemplify@4.180.153.209

# Accessed Dokploy PostgreSQL
docker exec dokploy-postgres.1.khhkgir9v9mt1s3e9zjqn7cs2 psql -U dokploy -d dokploy

# Deleted orphaned applications
DELETE FROM compose WHERE "composeId" = 'jE26KpK1rS0GNC75TvHXM';  -- Huly
DELETE FROM compose WHERE "composeId" = 'QS_-rfrjZ5wEYJ2Bvm0gE';  -- Zulip
```

---

**Status:** ✅ COMPLETE - All orphaned Huly and Zulip applications have been successfully removed from Dokploy.
