# Paddie.io SOGo Unauthorized Fix

**Date:** January 19, 2026  
**Issue:** SOGo shows "Unauthorized" when clicking webmail button after Mailcow login

---

## 🔴 Problem

After logging into Mailcow UI successfully, clicking the "Webmail" button redirects to SOGo but shows "Unauthorized" (403 error).

**Root Cause:**  
According to Mailcow GitHub issue #6442, when mailboxes are created via SQL (not through Mailcow UI), SOGo sessions aren't initialized. Users need to enable "Direct forwarding to SOGo" at least once to initialize the SOGo session.

---

## ✅ Solution

### Step 1: Enable Direct Forwarding to SOGo (One-Time)

**Via Mailcow Admin UI:**
1. Login to https://mail.seemplifyai.com as **admin** (admin / moohoo)
2. Go to **Configuration** → **Mail setup** → **Mailboxes**
3. Find and edit **michael@paddie.io**
4. Look for setting: **"Direct forwarding to SOGo"** or **"After logging in, the user is automatically redirected to SOGo"**
5. ✅ **Enable this option**
6. Click **Save**

### Step 2: User Login (Initializes SOGo)

1. Logout from Mailcow UI
2. Login again at https://mail.seemplifyai.com
3. Username: `michael@paddie.io`
4. Password: `MichaelPass123!`
5. You should be **automatically redirected to SOGo** (this initializes the session)
6. Verify SOGo loads successfully

### Step 3: Disable Redirect (Optional)

After successful SOGo initialization:
1. Login as admin again
2. Edit **michael@paddie.io** mailbox
3. Disable "Direct forwarding to SOGo" (if you don't want auto-redirect)
4. Click **Save**

**Result:** The webmail button will now work even with redirect disabled!

---

## 🔍 Why This Works

According to GitHub issue #6442:
- The auto-redirect triggers SOGo session initialization
- This creates necessary SOGo authentication tokens
- After initialization, SOGo works even without the redirect enabled
- This is a one-time requirement per mailbox

---

## 📋 Apply to All Paddie.io Mailboxes

Repeat the process for:
- ✅ michael@paddie.io
- ⚠️ info@paddie.io (if needed)
- ⚠️ ryan@paddie.io (if needed)

---

## 🚀 Quick Fix Script (If Admin UI Access Available)

If you have admin access, you can:
1. Enable redirect for all paddie.io mailboxes
2. Have each user log in once
3. Disable redirects if desired

---

## 📝 Alternative: Check Mailcow API

If the redirect setting is accessible via API, we could automate this. However, based on the GitHub issue, it's recommended to use the UI method.

---

**Status:** ⚠️ Requires admin UI access to enable redirect setting  
**Next Action:** Enable "Direct forwarding to SOGo" in Mailcow UI for michael@paddie.io
