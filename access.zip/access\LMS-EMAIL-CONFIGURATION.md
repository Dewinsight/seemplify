# LMS Email Configuration - Successfully Configured

**Date:** February 2, 2026  
**Status:** ✅ Configured & Testing

---

## What Was Done

Successfully configured Brevo SMTP email settings for Frappe LMS:

### Configuration Details

**SMTP Server:** `smtp-relay.brevo.com`  
**Port:** `587` (STARTTLS)  
**Login:** `93ea9d001@smtp-brevo.com`  
**Password:** `xsmtpsib-65f677712f19a7adae324dcbf4b913c473f37b7baf209f07bd8a753d327c2bf0-8rhBHTyMJrZFoCub`  
**Sender Email:** `michael.egbo@aiinnigeria.com`  
**TLS Encryption:** Enabled

### File Modified

- `/home/frappe/frappe-bench/sites/lms.seemplifyai.com/site_config.json`

### Service Restarted

- ✅ LMS Frappe Docker container restarted successfully
- ✅ Container ID: `lms_frappe.1.i5avptg297rhj3f94797wpcez`
- ✅ SMTP connection verified: `Connection successful`

---

## Next Steps - What to Test

### 1. Test User Signup Flow

**Scenario:** New user registers on LMS

**Expected behavior:**
- [ ] User fills out signup form
- [ ] User receives verification email at their email address
- [ ] Email contains link to complete registration
- [ ] User clicks link and creates password
- [ ] User can now log in successfully

### 2. Check Pending Emails

If you have users who already signed up but got stuck:

1. Go to **Email Queue** in Frappe Desk (`/app/email-queue`)
2. Look for pending emails from before the configuration
3. These should now start sending automatically
4. Or manually trigger resend if needed

### 3. Test Password Reset

**To verify email delivery works:**
1. Go to LMS login page
2. Click "Forgot Password"
3. Enter a test user's email
4. Check if password reset email is received

### 4. Monitor Email Logs

Check for any email-related issues:
- Container logs: `docker logs lms_frappe.1.i5avptg297rhj3f94797wpcez --tail 100`
- Look for email sending errors or success messages

---

## Troubleshooting

### If emails are still not sending:

1. **Check Email Queue:**
   ```
   Go to /app/email-queue in Frappe Desk
   Look for failed or pending emails
   Check error messages
   ```

2. **Verify container is running:**
   ```
   docker ps | grep lms
   ```

3. **Check container logs:**
   ```
   docker logs lms_frappe.1.i5avptg297rhj3f94797wpcez --tail 50
   ```

4. **Test SMTP manually:**
   ```bash
   docker exec -it lms_frappe.1.i5avptg297rhj3f94797wpcez python3 -c "
   import smtplib
   server = smtplib.SMTP('smtp-relay.brevo.com', 587)
   server.starttls()
   print('SMTP connection successful')
   server.quit()
   "
   ```

### If users still can't sign up:

1. Ensure "Disable Signup" is unchecked in **LMS Settings**
2. Go to `/app/lms-settings/LMS Settings`
3. Look for "Signup Settings" tab
4. Uncheck "Disable Signup"
5. Save settings

---

## Credentials Reference

All credentials are stored in `access/BREVO-CONFIGURATION.md`:
- **SMTP Login:** `93ea9d001@smtp-brevo.com`
- **SMTP Password:** `xsmtpsib-65f677712f19a7adae324dcbf4b913c473f37b7baf209f07bd8a753d327c2bf0-8rhBHTyMJrZFoCub`

---

## Verification Checklist

- [x] SMTP connection to Brevo verified (port 587)
- [x] Configuration added to site_config.json
- [x] LMS container restarted with new config
- [ ] Test email sent successfully
- [ ] User signup flow tested
- [ ] Pending emails in queue processed

---

**Configuration completed successfully! 🎉**

The LMS should now be able to send verification emails to users who sign up. The stuck users should receive their verification emails once the email queue processes them.
