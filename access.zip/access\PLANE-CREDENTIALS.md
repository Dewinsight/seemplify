﻿# Plane Credentials

Created: 2026-05-26T00:07:02
URL: https://plane.seemplifyai.com
God Mode: https://plane.seemplifyai.com/god-mode/
Email: admin@seemplifyai.com
Password: +m$uWGrAm9AFniZC88VHU6CF4A8r%$xv

Notes:
- Plane is deployed as Dokploy compose app plane.
- SMTP notifications are configured through Brevo SMTP.
- This file is inside ccess/, which is ignored by git.
