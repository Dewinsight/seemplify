# Mailcow DKIM Setup Guide

**Last Updated:** January 6, 2026  
**Status:** DKIM authentication for seemplifyai.com

---

## ⚠️ Why Email Went to Spam

Your email to tonyegboo@gmail.com went to spam because:

1. **No DKIM authentication** - Gmail couldn't verify the email is really from seemplifyai.com
2. **New domain with no reputation** - Gmail doesn't trust seemplifyai.com yet
3. **Missing DKIM record in DNS** - No way to authenticate your domain

**DKIM is CRITICAL** for email deliverability!

---

## 📋 Option 1: Configure DKIM via Mailcow UI (Recommended)

This is the easiest method:

### Step 1: Enable DKIM in Mailcow

1. **Login to Mailcow:**
   ```
   URL: https://mail.seemplifyai.com
   Username: admin
   Password: moohoo ⚠️
   ```

2. **Go to Configuration:**
   - Navigate to: **Configuration** → **Configuration & Details**
   - Click: **DKIM keys** tab

3. **Enable DKIM for seemplifyai.com:**
   - Find: `seemplifyai.com` in the domain list
   - Click: **Edit** (pencil icon)
   - Check: **Enable** (checkbox)
   - Click: **Save**

4. **Get DKIM Key:**
   - After saving, click **Show** next to seemplifyai.com
   - You'll see the DKIM DNS record like:
   ```
   dkim._domainkey.seemplifyai.com TXT "v=DKIM1; k=rsa; p=MIGfMA0GCS...s=...; h=sha256"
   ```
   - Click: **Copy** to clipboard

5. **Add to Cloudflare DNS:**
   - Go to: https://dash.cloudflare.com
   - Select: seemplifyai.com
   - Click: **DNS** → **Records**
   - Click: **Add Record**
   - **Type:** TXT
   - **Name:** `dkim._domainkey.seemplifyai.com`
   - **Content:** Paste the DKIM record from step 4
   - **TTL:** 3600
   - Click: **Save**

6. **Verify:**
   - Wait 5-10 minutes for DNS propagation
   - Test at: https://www.mail-tester.com/test-a-key.html?domain=seemplifyai.com

---

## 🔧 Option 2: Configure via CLI (Advanced)

If you want to check if DKIM is already configured:

```bash
# SSH into server
ssh seemplify@4.180.153.209

# Check if DKIM is enabled in database
docker exec mailcowdockerized-mysql-mailcow-1 mysql -u mailcow -p3w8aLaw8jyknrgbs3qFfDgdD4LRQ mailcow -e "
SELECT domain, dkim_enabled 
FROM domain 
WHERE domain='seemplifyai.com';
"
```

**Expected output if enabled:**
```
domain              dkim_enabled
seemplifyai.com     1
```

**Expected output if disabled:**
```
domain              dkim_enabled
seemplifyai.com     0
```

---

## 📊 Understanding DKIM

### What is DKIM?

**DKIM (DomainKeys Identified Mail)** = Email authentication that:

- **Proves** an email is really from your domain
- **Prevents** email spoofing/spamming
- **Improves** deliverability (Gmail requires it)
- **Required** by Gmail, Outlook, Yahoo, etc.

### How DKIM Works:

```
Sender (You)            Mailcow Server
  │                              (signs with DKIM)
  ▼
  ┌────────────────────────┐
  │ Digital Signature │  ✅ "This email is from seemplifyai.com"
  └────────────────────────┘
  │
  ▼
Recipient's Mail Server      Gmail/Outlook
  (verifies DKIM signature against DNS)
```

---

## 🔍 How DKIM is Stored in Mailcow

Mailcow generates DKIM keys when enabled. They're stored as:

### In Files:
- **Private Key:** `/var/lib/postfix/dkim/private/{selector}.private`
- **Public Key:** `/var/lib/postfix/dkim/{selector}.public`
- **Selector:** Usually `dkim` or `mail`

### In Database (if enabled):
```sql
-- Domain table stores DKIM enable status
SELECT domain, dkim_enabled FROM domain WHERE domain='seemplifyai.com';

-- DKIM table (may or may not exist)
SELECT dkim_selector, dkim_pubkey FROM dkim WHERE domain='seemplifyai.com';
```

---

## 📋 Configuration Steps Summary

| Step | Task | Method |
|------|-------|---------|
| 1 | Enable DKIM in Mailcow | UI: Configuration → DKIM keys |
| 2 | Copy DKIM record | UI: Click "Show" button |
| 3 | Add TXT record to Cloudflare | Cloudflare DNS panel |
| 4 | Wait for propagation | 5-10 minutes |
| 5 | Verify authentication | mail-tester.com or mxtoolbox.com |

---

## 🧪 After Configuration

### Check DKIM Status:

```bash
# Method 1: Via Mailcow UI (best)
# Login to Mailcow and check Configuration → DKIM keys

# Method 2: Via command line
curl -s "https://mail-tester.com/test-a-key.html?domain=seemplifyai.com" | grep "pass"
```

### Test Email Deliverability:

After DKIM is configured and propagated:

```bash
# Send test email
docker exec mailcowdockerized-postfix-mailcow-1 sendmail -f info@seemplifyai.com check-auth@verifier.port25.com <<EOF
Subject: DKIM Test Email
From: info@seemplifyai.com

This is a test email to verify DKIM, SPF, and DMARC configuration.
EOF
```

**Check for:**
- ✅ DKIM: Pass
- ✅ SPF: Pass
- ✅ DMARC: Pass

---

## 📚 Additional Resources

### DKIM Testing Tools:
- https://www.mail-tester.com
- https://mxtoolbox.com/DKIM.aspx
- https://www.dmarcianalyzer.com/dkim/

### Cloudflare DKIM Guide:
- https://developers.cloudflare.com/dns/manage-dns-records/reference/dns-records/

---

## ✅ Verification Checklist

- [ ] Enable DKIM for seemplifyai.com in Mailcow UI
- [ ] Copy DKIM TXT record from Mailcow
- [ ] Add dkim._domainkey.seemplifyai.com TXT record to Cloudflare
- [ ] Wait for DNS propagation (5-10 minutes)
- [ ] Verify DKIM passes at mail-tester.com
- [ ] Send test email to verify authentication

---

## 🆘 Expected Result After DKIM Configuration

**Before DKIM:**
- Emails go to spam/junk folder
- Gmail doesn't trust your domain
- High bounce rate

**After DKIM:**
- ✅ Emails go to inbox
- ✅ Gmail verifies seemplifyai.com is legitimate
- ✅ Higher deliverability
- ✅ Better sender reputation

---

## 📝 DKIM vs SPF vs DMARC

| Authentication | Purpose | Status |
|--------------|---------|--------|
| **DKIM** | Cryptographic signature | ⚠️ Not configured |
| **SPF** | Lists allowed senders | ✅ Configured |
| **DMARC** | Policy for failed auth | ✅ Configured |

**All three work together for maximum deliverability!**

---

**Important:** DKIM is the MOST IMPORTANT for new domains to avoid spam folders!

---

**Next Step:** Go to Mailcow UI → Configuration → DKIM keys → Enable DKIM for seemplifyai.com
