# Pull Request: Add Blocking Invitation Modal System

## Summary
Implements a blocking modal system that forces users to accept or decline pending organization invitations on every IdentityProvider page visit.

## Changes

### Backend
- **Identityprovider/src/routes/invitations.js**
  - Added `POST /api/invitations/decline/:invitationId` endpoint
  - Validates invitation ownership and email match
  - Calls existing `reject()` method
  - Returns success/error response

### Frontend
- **Identityprovider/src/public/js/invitation-gatekeeper.js** (NEW FILE)
  - Created `InvitationGatekeeper` class
  - Checks `/api/invitations/pending` on page load
  - Shows full-screen blocking modal with backdrop blur
  - Prevents dismissal (no close button, no escape key, no click-outside)
  - Handles single and multiple invitations
  - Only Accept or Decline buttons work
  - Reloads page after decision

- **Updated IdentityProvider page templates:**
  - `organizations.ejs` - Added gatekeeper script
  - `profile.ejs` - Added gatekeeper script
  - `teams.ejs` - Added gatekeeper script
  - `members.ejs` - Added gatekeeper script

## Features
- ✅ Full-screen blocking modal (cannot be dismissed)
- ✅ Backdrop blur effect
- ✅ Supports single or multiple pending invitations
- ✅ Email verification on accept/decline
- ✅ Success/error handling with alerts
- ✅ Page reload after decision

## Testing
1. Create a pending invitation via `/organizations/:orgId/invitations`
2. Visit any IdentityProvider page (organizations, profile, teams, members)
3. Modal should appear and block all interaction
4. Accept or decline invitation
5. Modal should disappear and page should reload

## Notes
- The modal automatically checks for pending invitations on every page load
- No localStorage or session-based dismissal - forces decision
- Existing `/invitations/pending` page still shows all invitations for management
- Gatekeeper script is self-initializing and handles both loading and interactive DOM states

## Merge Strategy
This should be merged to `main` branch as it contains production-ready changes.
