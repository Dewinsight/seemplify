# Open WebUI Integration with Seemplify IdP

**Status**: ✅ Completed  
**Date**: January 7, 2026  
**Domain**: https://ai.seemplifyai.com  
**Integration Type**: OIDC (OpenID Connect)

---

## Overview

Open WebUI has been successfully integrated with the Seemplify Identity Provider, enabling single sign-on (SSO) for AI chat functionality with multiple model support.

---

## Configuration Details

### 1. Seemplify IdP Configuration

#### OIDC Client (`Identityprovider/clients.json`)
```json
{
  "client_id": "openwebui",
  "client_secret": "openwebui-seemplify-secret-2026",
  "redirect_uri_patterns": [
    "https://ai.seemplifyai.com/oauth/oidc/callback",
    "http://localhost:8080/oauth/oidc/callback"
  ],
  "allowed_origins": [
    "https://ai.seemplifyai.com",
    "http://localhost:8080",
    "https://auth.seemplifyai.com"
  ],
  "response_types": ["code"],
  "grant_types": ["authorization_code", "refresh_token"],
  "token_endpoint_auth_method": "client_secret_post"
}
```

#### Hub App Configuration (`Identityprovider/src/config/hubApps.js`)
- **App ID**: `openwebui`
- **Name**: Open WebUI
- **Icon**: chat
- **Color**: #7c3aed (purple)
- **Category**: ai
- **Order**: 6

#### PKCE Exception (`Identityprovider/src/index.js`)
```javascript
const noPkceClients = ['outline', 'openwebui'];
```

#### Hub Launch Handler (`Identityprovider/src/index.js`)
```javascript
if (app.appId === 'openwebui') {
  const openwebuiAuthUrl = `${app.url}/oauth/oidc`
  return res.redirect(openwebuiAuthUrl)
}
```

---

### 2. Open WebUI Configuration

#### Docker Compose Environment Variables
```yaml
environment:
  # Base Configuration
  - WEBUI_SECRET_KEY=${webui_secret_key}
  - OLLAMA_BASE_URL=http://ollama:11434
  - WEBUI_URL=https://ai.seemplifyai.com
  
  # Seemplify IdP OIDC Configuration
  - ENABLE_OAUTH_SIGNUP=true
  - OAUTH_MERGE_ACCOUNTS_BY_EMAIL=true
  - OAUTH_CLIENT_ID=openwebui
  - OAUTH_CLIENT_SECRET=openwebui-seemplify-secret-2026
  - OPENID_PROVIDER_URL=https://auth.seemplifyai.com/.well-known/openid-configuration
  - OAUTH_PROVIDER_NAME=Seemplify
  - OAUTH_SCOPES=openid email profile
  - OPENID_REDIRECT_URI=https://ai.seemplifyai.com/oauth/oidc/callback
  - ENABLE_OAUTH_ROLE_MANAGEMENT=false
```

#### Traefik Labels
```yaml
labels:
  - traefik.enable=true
  - traefik.http.routers.seemplify-openwebui-rbjanx-15-web.rule=Host(`ai.seemplifyai.com`)
  - traefik.http.routers.seemplify-openwebui-rbjanx-15-web.entrypoints=web
  - traefik.http.routers.seemplify-openwebui-rbjanx-15-web.middlewares=redirect-to-https@file
  - traefik.http.routers.seemplify-openwebui-rbjanx-15-websecure.rule=Host(`ai.seemplifyai.com`)
  - traefik.http.routers.seemplify-openwebui-rbjanx-15-websecure.entrypoints=websecure
  - traefik.http.routers.seemplify-openwebui-rbjanx-15-websecure.tls.certresolver=letsencrypt
```

#### Networks
- `dokploy-network` (for Traefik routing)
- `seemplify-openwebui-rbjanx` (internal)

---

### 3. DNS Configuration

**Cloudflare DNS Record** (Added via API)
```
Type:    A
Name:    ai
Content: 4.180.153.209
TTL:     Auto (1)
Proxied: ✓ (Cloudflare proxy enabled)
```

**Record ID**: `1606f4e58b1f4c6c0762a637a0e3cc84`

---

## OIDC Flow

### Direct Login
1. User visits `https://ai.seemplifyai.com`
2. Clicks "Sign in with Seemplify"
3. Redirected to `https://auth.seemplifyai.com/auth`
4. Logs in with Seemplify credentials
5. Redirected to callback: `https://ai.seemplifyai.com/oauth/oidc/callback`
6. Open WebUI creates session and redirects to dashboard

### Hub Launch
1. User visits `https://auth.seemplifyai.com` (IdP hub)
2. Clicks "Open WebUI" card
3. IdP redirects to `https://ai.seemplifyai.com/oauth/oidc`
4. Open WebUI initiates OIDC flow with existing session
5. User is logged in automatically

---

## Key Features

✅ **Single Sign-On**: Users log in with Seemplify credentials  
✅ **Account Merging**: Accounts merged by email if user already exists  
✅ **Auto Signup**: New users automatically created on first login  
✅ **Hub Integration**: Accessible from Seemplify IdP hub  
✅ **No PKCE Required**: IdP configured to skip PKCE for Open WebUI  
✅ **Secure HTTPS**: Let's Encrypt SSL via Traefik  
✅ **Cloudflare Proxy**: Protected and accelerated by Cloudflare

---

## Verification

### Status Checks
- ✅ Open WebUI container: Running (healthy)
- ✅ DNS Resolution: `ai.seemplifyai.com` → Cloudflare proxied
- ✅ HTTPS Access: HTTP 200 response
- ✅ Traefik Routing: Correctly configured
- ✅ IdP Integration: Client registered, hub card visible
- ✅ OIDC Environment: All variables correctly set

### Testing Commands
```bash
# Check DNS
nslookup ai.seemplifyai.com

# Test HTTPS access
curl -I https://ai.seemplifyai.com

# Verify OIDC config
ssh seemplify@4.180.153.209 "docker exec seemplify-openwebui-rbjanx-open-webui-1 printenv | grep OAUTH"
```

---

## Git Commits

1. **IdP Changes**: 
   - Commit: `a94dab0`
   - Message: "feat(idp): add Open WebUI OIDC integration with hub support on ai.seemplifyai.com"
   - Files: `clients.json`, `hubApps.js`, `index.js`

---

## Troubleshooting

### If OIDC login fails:

1. **Check IdP logs**:
   ```bash
   ssh seemplify@4.180.153.209 "docker service logs identity-provider-skj7oj --tail 50"
   ```

2. **Check Open WebUI logs**:
   ```bash
   ssh seemplify@4.180.153.209 "docker logs seemplify-openwebui-rbjanx-open-webui-1 --tail 50"
   ```

3. **Verify OIDC discovery**:
   ```bash
   curl https://auth.seemplifyai.com/.well-known/openid-configuration
   ```

4. **Verify redirect URI**:
   - Must be: `https://ai.seemplifyai.com/oauth/oidc/callback`
   - Check in IdP `clients.json`

### If hub launch doesn't work:

Check that the hub launch handler is present:
```bash
ssh seemplify@4.180.153.209 "docker exec [container] grep 'openwebui' /app/src/index.js"
```

---

## Related Applications

This configuration mirrors the Outline setup:
- **Outline Docs**: `https://docs.seemplifyai.com` (knowledge base)
- **Open WebUI**: `https://ai.seemplifyai.com` (AI chat)

Both use the same OIDC integration pattern with Seemplify IdP.

---

## Next Steps

✅ **Ready to use!**

1. Go to https://ai.seemplifyai.com
2. Click "Sign in with Seemplify"
3. Log in with your Seemplify credentials
4. Start chatting with AI models

**OR** launch from hub:
1. Go to https://auth.seemplifyai.com
2. Click the "Open WebUI" card
3. Automatically logged in with SSO
