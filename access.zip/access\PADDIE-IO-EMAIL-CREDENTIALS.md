# Paddie.io Email Accounts - Credentials & Configuration

**Date:** January 19, 2026  
**Status:** ✅ Domain and Mailboxes Fully Configured

---

## 🌐 Domain Configuration

| Item | Value | Status |
|------|-------|--------|
| **Domain** | paddie.io | ✅ Added to Mailcow |
| **Max Mailboxes** | Unlimited | ✅ Configured |
| **Domain Quota** | Unlimited | ✅ Configured |
| **Per-Mailbox Quota** | 3 GB | ✅ Configured |

---

## 📧 Email Accounts Created

### info@paddie.io
- **Username:** `info@paddie.io`
- **Password:** `TestEmail123!`
- **Full Name:** Info
- **Quota:** 3 GB
- **Status:** ✅ Active
- **IMAP Access:** ✅ Enabled
- **SMTP Access:** ✅ Enabled
- **SOGo Access:** ✅ Enabled

### michael@paddie.io
- **Username:** `michael@paddie.io`
- **Password:** `MichaelPass123!`
- **Full Name:** Michael
- **Quota:** 3 GB
- **Status:** ✅ Active
- **IMAP Access:** ✅ Enabled
- **SMTP Access:** ✅ Enabled
- **SOGo Access:** ✅ Enabled

### ryan@paddie.io
- **Username:** `ryan@paddie.io`
- **Password:** `RyanPass123!`
- **Full Name:** Ryan
- **Quota:** 3 GB
- **Status:** ✅ Active
- **IMAP Access:** ✅ Enabled
- **SMTP Access:** ✅ Enabled
- **SOGo Access:** ✅ Enabled

⚠️ **IMPORTANT:** Change these passwords after first login!

---

## 🔐 Mailcow Admin Access

- **URL:** https://mail.seemplifyai.com
- **Username:** `admin`
- **Password:** `moohoo`
- **Note:** Same admin panel as seemplifyai.com domain

---

## 🌍 DNS Records (Cloudflare)

### Fully Configured ✅

| Type | Name | Content | Status |
|------|------|---------|--------|
| MX | @ | mail.seemplifyai.com (priority 10) | ✅ Active |
| TXT (SPF) | @ | v=spf1 mx a:mail.seemplifyai.com -all | ✅ Active |
| TXT (DMARC) | _dmarc | v=DMARC1; p=quarantine; rua=mailto:admin@seemplifyai.com | ✅ Active |
| TXT (DKIM) | dkim._domainkey | v=DKIM1; k=rsa; p=[DKIM_KEY] | ✅ Active |

**Note:** 
- ✅ All DNS records are configured and verified
- ✅ **Microsoft records removed** - No longer connected to Microsoft 365/Outlook
- ✅ Emails from @paddie.io should pass SPF, DKIM, and DMARC checks
- ✅ All email routing now goes through Mailcow (mail.seemplifyai.com)

---

## 🔧 Email Client Configuration (IMAP/SMTP)

For use with Outlook, Thunderbird, Apple Mail, Gmail, etc:

### Incoming Mail (IMAP):
- **Server:** mail.seemplifyai.com
- **Port:** 993
- **Security:** SSL/TLS (Encryption)
- **Username:** Full email address (e.g., info@paddie.io)
- **Password:** Account password (see above)

### Outgoing Mail (SMTP):
- **Server:** mail.seemplifyai.com
- **Port:** 587 (recommended) or 465
- **Security:** STARTTLS (587) or SSL/TLS (465)
- **Authentication:** Required
- **Username:** Full email address
- **Password:** Account password

### Example Configuration:

**Outlook:**
```
Account Type: IMAP
Incoming: mail.seemplifyai.com:993 (SSL)
Outgoing: mail.seemplifyai.com:587 (STARTTLS)
```

**Apple Mail:**
```
Account Type: IMAP
Incoming: mail.seemplifyai.com:993 (SSL)
Outgoing: mail.seemplifyai.com:587 (STARTTLS)
```

**Thunderbird:**
```
Incoming: mail.seemplifyai.com:993 (SSL/TLS)
Outgoing: mail.seemplifyai.com:587 (STARTTLS)
```

---

## 🌐 Webmail Access (SOGo)

- **URL:** https://mail.seemplifyai.com/SOGo
- **Login:** Use full email address (e.g., info@paddie.io)
- **Password:** Account password (see above)

**Direct Links:**
- **Info:** https://mail.seemplifyai.com/SOGo (login: info@paddie.io)
- **Michael:** https://mail.seemplifyai.com/SOGo (login: michael@paddie.io)
- **Ryan:** https://mail.seemplifyai.com/SOGo (login: ryan@paddie.io)

---

## 💻 SMTP for Application Integration

For your applications that need to send emails from @paddie.io:

### Node.js (nodemailer):
```javascript
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: 'mail.seemplifyai.com',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: 'info@paddie.io',
    pass: 'TestEmail123!'
  }
});

// Send email
await transporter.sendMail({
  from: 'info@paddie.io',
  to: 'recipient@example.com',
  subject: 'Test Email',
  text: 'Hello from paddie.io!'
});
```

### Python (smtplib):
```python
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

smtp_server = 'mail.seemplifyai.com'
smtp_port = 587
username = 'info@paddie.io'
password = 'TestEmail123!'

# Create message
msg = MIMEMultipart()
msg['From'] = 'info@paddie.io'
msg['To'] = 'recipient@example.com'
msg['Subject'] = 'Test Email'

body = 'Hello from paddie.io!'
msg.attach(MIMEText(body, 'plain'))

# Send email
server = smtplib.SMTP(smtp_server, smtp_port)
server.starttls()
server.login(username, password)
server.send_message(msg)
server.quit()
```

### PHP:
```php
<?php
$smtp_host = 'mail.seemplifyai.com';
$smtp_port = 587;
$username = 'info@paddie.io';
$password = 'TestEmail123!';

// Using PHPMailer
use PHPMailer\PHPMailer\PHPMailer;

$mail = new PHPMailer(true);
$mail->isSMTP();
$mail->Host = $smtp_host;
$mail->SMTPAuth = true;
$mail->Username = $username;
$mail->Password = $password;
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->Port = $smtp_port;

$mail->setFrom('info@paddie.io', 'Paddie.io');
$mail->addAddress('recipient@example.com');
$mail->Subject = 'Test Email';
$mail->Body = 'Hello from paddie.io!';

$mail->send();
?>
```

---

## 📊 Quick Reference

| Service | URL/Address | Credentials |
|---------|-------------|-------------|
| **Webmail (SOGo)** | https://mail.seemplifyai.com/SOGo | See accounts above |
| **Admin Panel** | https://mail.seemplifyai.com | admin / moohoo |
| **IMAP Server** | mail.seemplifyai.com:993 | Full email / password |
| **SMTP Server** | mail.seemplifyai.com:587 | Full email / password |
| **Server SSH** | seemplify@4.180.153.209 | SSH key |

---

## ✅ Configuration Status Checklist

- [x] Domain added to Mailcow (paddie.io)
- [x] info@paddie.io mailbox created
- [x] michael@paddie.io mailbox created
- [x] ryan@paddie.io mailbox created
- [x] Cloudflare DNS: MX record configured
- [x] Cloudflare DNS: SPF record configured
- [x] Cloudflare DNS: DMARC record configured
- [x] Cloudflare DNS: DKIM record configured
- [x] user_acl records created (fixed UI loading issue)
- [x] mailbox attributes configured (fixed imap_access error)
- [x] Mailboxes visible in Mailcow admin UI
- [ ] ⚠️ Email account passwords changed (recommended)
- [ ] ⚠️ Test email sent/received between accounts

---

## 🧪 Test Email Functionality

### Test Between Accounts:
1. Login to https://mail.seemplifyai.com/SOGo as `info@paddie.io`
2. Send email to `michael@paddie.io` or `ryan@paddie.io`
3. Login as recipient and verify email received

### Test External Email:
1. Send email from `info@paddie.io` to your personal email
2. Check spam folder if not in inbox
3. Verify email headers show:
   - ✅ SPF: Pass
   - ✅ DKIM: Pass
   - ✅ DMARC: Pass

### Test Authentication:
Send email to: `check-auth@verifier.port25.com`
- This will return a detailed authentication report

---

## 🆘 Troubleshooting

### Can't Login to Webmail
- **Check:** Are you using the full email address as username?
- **Check:** Is the password correct? (case-sensitive)
- **Check:** Is https://mail.seemplifyai.com accessible?

### Can't Send Email
- **Check:** Are mail ports (25, 465, 587) open in Azure NSG?
- **Check:** Is DKIM configured in DNS?
- **Check:** Run: `docker logs mailcowdockerized-postfix-mailcow-1`

### Can't Receive Email
- **Check:** Is MX record pointing to mail.seemplifyai.com?
- **Check:** Run: `nslookup -type=MX paddie.io`
- **Check:** Run: `docker logs mailcowdockerized-dovecot-mailcow-1`

### Email Goes to Spam
- **Check:** SPF, DKIM, DMARC records in DNS
- **Check:** Use mail-tester.com to test email deliverability
- **Test:** Send email to check-auth@verifier.port25.com

### Mailbox Page Not Loading
- **Fixed:** user_acl records added ✅
- **Fixed:** mailbox attributes configured ✅
- **If still issues:** Hard refresh browser (Ctrl+F5)

---

## 📝 Password Reset Instructions

### Via Webmail:
1. Login to https://mail.seemplifyai.com/SOGo
2. Go to **Preferences** → **Security** → **Change Password**
3. Enter current password and new password

### Via Admin Panel:
1. Login to https://mail.seemplifyai.com as admin
2. Go to **Configuration** → **Mailboxes**
3. Find the mailbox (e.g., info@paddie.io)
4. Click **Edit** → **Change Password**
5. Enter new password and save

### Via Database (Advanced):
```bash
ssh seemplify@4.180.153.209
docker exec mailcowdockerized-dovecot-mailcow-1 doveadm pw -s SSHA256 -p 'NewPassword123!'
# Copy the hash output
docker exec mailcowdockerized-mysql-mailcow-1 mysql -u mailcow -p3w8aLaw8jyknrgbs3qFfDgdD4LRQ mailcow -e "UPDATE mailbox SET password = '{SSHA256}HASH_HERE' WHERE username = 'info@paddie.io';"
```

---

## 🔒 Security Recommendations

1. **Change Default Passwords:** All accounts should change passwords after first login
2. **Use Strong Passwords:** Minimum 12 characters, mix of letters, numbers, symbols
3. **Enable 2FA:** Consider enabling two-factor authentication for admin account
4. **Regular Updates:** Keep Mailcow updated to latest version
5. **Monitor Logs:** Regularly check mail logs for suspicious activity

---

## 📞 Support & Maintenance

### Check Mailbox Status:
```bash
ssh seemplify@4.180.153.209
docker exec mailcowdockerized-mysql-mailcow-1 mysql -u mailcow -p3w8aLaw8jyknrgbs3qFfDgdD4LRQ mailcow -e "SELECT username, domain, active FROM mailbox WHERE domain = 'paddie.io';"
```

### View Mail Logs:
```bash
# SMTP logs
docker logs mailcowdockerized-postfix-mailcow-1 --tail 50

# IMAP logs
docker logs mailcowdockerized-dovecot-mailcow-1 --tail 50
```

### Restart Mailcow Services:
```bash
cd /data/mailcow && docker compose restart
```

---

**Last Updated:** January 19, 2026  
**Domain Status:** ✅ Fully Configured and Operational  
**Next Action:** Change default passwords and test email functionality
