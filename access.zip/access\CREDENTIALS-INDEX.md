# Credentials Index – All Passwords & Secrets

**Last Updated:** January 30, 2026  
**Purpose:** Single reference for where every password, secret, and credential is stored or set.

---

## Quick reference

| Credential type | Where stored / set | Access file |
|-----------------|-------------------|-------------|
| Dokploy dashboard login | Access doc | `DOKPLOY-CREDENTIALS.md` |
| Dokploy API keys & app IDs | Access doc | `DOKPLOY-API-CREDENTIALS-COMPLETE.md` |
| GitHub Actions secrets | GitHub repo → Settings → Secrets | See `GITHUB-SECRETS-SETUP-GUIDE.md` |
| Zulip (Chat) env vars & passwords | Dokploy compose app env | `ZULIP-CREDENTIALS.md` |
| Brevo (SMTP / API) | Access doc | `BREVO-CONFIGURATION.md` |
| Cloudflare DNS/API | Access doc (if present) | `CLOUDFLARE-CREDENTIALS.md` or grep `access/` |
| Server / SSH | Access doc | `SERVER-ACCESS.md` |
| Identity Provider OIDC clients | Repo (no secrets in clients) | `Identityprovider/clients.json` + Dokploy env |
| Mailcow / email | Access docs | `MAILCOW-CREDENTIALS.md`, `SMTP-CREDENTIALS.md` |

---

## 1. Dokploy

| What | Where | File |
|------|--------|------|
| Dashboard URL | `http://4.180.153.209:3000` | `DOKPLOY-CREDENTIALS.md` |
| Dashboard email | In access doc | `DOKPLOY-CREDENTIALS.md` |
| Dashboard password | In access doc | `DOKPLOY-CREDENTIALS.md` |
| API token (GitHub Actions) | In access doc | `DOKPLOY-API-CREDENTIALS-COMPLETE.md` |
| All application IDs | In access doc | `DOKPLOY-API-CREDENTIALS-COMPLETE.md` |
| Compose app IDs (e.g. Zulip) | In access doc | `DOKPLOY-API-CREDENTIALS-COMPLETE.md` |

---

## 2. GitHub Secrets

Used by GitHub Actions for deploy. Set in: **Repo → Settings → Secrets and variables → Actions**.

| Secret name | Purpose | Where to get value |
|-------------|---------|--------------------|
| `DOKPLOY_URL` | Dokploy base URL | `http://4.180.153.209:3000` |
| `DOKPLOY_TOKEN` | Dokploy API key | `DOKPLOY-API-CREDENTIALS-COMPLETE.md` |
| `CANDIDATE_PORTAL_APP_ID` | Candidate portal production deploy | `CANDIDATE-PORTAL-DOKPLOY-DEPLOYMENT.md` |
| `CANDIDATE_PORTAL_DEV_APP_ID` | Candidate portal dev deploy | `CANDIDATE-PORTAL-DOKPLOY-DEPLOYMENT.md` |
| `ZULIP_COMPOSE_ID` | Zulip compose deploy | Dokploy compose app ID |
| `IDENTITY_PROVIDER_APP_ID` | IDP app deploy | `DOKPLOY-API-CREDENTIALS-COMPLETE.md` |
| `*_APP_ID` / `*_DEV_APP_ID` | Other app deploys | `DOKPLOY-API-CREDENTIALS-COMPLETE.md`, `GITHUB-SECRETS-SETUP-GUIDE.md` |
| `SSH_PRIVATE_KEY` | Server SSH (if used by workflows) | Server/key doc in `access/` |

Full list and setup: `GITHUB-SECRETS-SETUP-GUIDE.md`.

---

## 3. Zulip (Seemplify Chat)

All runtime secrets are **environment variables** on the Zulip **compose application** in Dokploy (not in repo).

| Variable | Purpose | Set in |
|----------|---------|--------|
| `POSTGRES_PASSWORD` | PostgreSQL | Dokploy env |
| `MEMCACHED_PASSWORD` | Memcached | Dokploy env |
| `RABBITMQ_PASSWORD` | RabbitMQ | Dokploy env |
| `REDIS_PASSWORD` | Redis | Dokploy env |
| `SECRET_KEY` | Zulip app secret | Dokploy env |
| `OIDC_CLIENT_SECRET` | IDP OIDC client secret for Zulip | Dokploy env (match `Identityprovider/clients.json` zulip client) |
| `BREVO_SMTP_PASSWORD` | Brevo SMTP | Dokploy env |
| `BREVO_SMTP_USER` | Brevo SMTP login | Dokploy env |
| `ADMIN_EMAIL` | Zulip admin email | Dokploy env |

Details and optional vars: `ZULIP-CREDENTIALS.md`.

---

## 4. Brevo (Sendinblue)

| What | Where | File |
|------|--------|------|
| API key | In access doc | `BREVO-CONFIGURATION.md` |
| SMTP key / password | In access doc | `BREVO-CONFIGURATION.md` |
| SMTP server, port, login | In access doc | `BREVO-CONFIGURATION.md` |

Used by: Mailcow relay, IDP, recruiter/performance backends, Zulip (via Dokploy env).

---

## 5. Cloudflare

| What | Where | File |
|------|--------|------|
| API token / credentials | `SERVER-ACCESS.md` (same token as in API examples) | `ACCESS-GUIDE.md` § Cloudflare |
| Zone ID (seemplifyai.com) | Docs | `bbc142d2d661d64011e2e4becae7a5c3` |
| Zone ID (aiinnigeria.com — Jetstone / Akwa Ibom) | Docs | `25e5c8be7e4c31cbc39619cc3f1c223d` |

---

## 6. Server & SSH

| What | Where | File |
|------|--------|------|
| Host | `4.180.153.209` | `SERVER-ACCESS.md` |
| User | `seemplify` | `SERVER-ACCESS.md` |
| SSH key path | `access/id_rsa` (if present) | `SERVER-ACCESS.md` |

---

## 7. Identity Provider (IDP)

| What | Where | Notes |
|------|--------|-------|
| OIDC client configs (no secrets) | `Identityprovider/clients.json` | Client IDs, redirect URIs; secrets in Dokploy/env |
| Zulip OIDC client secret | Must match Zulip’s `OIDC_CLIENT_SECRET` | Set in Dokploy for Zulip; value not in repo |

---

## 8. Other apps (backend .env)

Backend apps (recruiter, leave, performance, payroll, etc.) get env (e.g. Brevo, DB, OIDC) from:

- **Production:** Dokploy application environment variables.
- **Local:** `.env` files (not in repo); copy from `.env.example` and fill from this index / `access/` docs.

Do **not** commit real passwords or API keys to the repo.

---

## Deploy-agent usage

When acting as **deploy-agent**:

1. **Resolve any credential** using this index: find the row for the credential type, then open the listed **Access file** (e.g. `DOKPLOY-CREDENTIALS.md`, `ZULIP-CREDENTIALS.md`).
2. **Never hardcode** credentials in repo code or in committed files; use `access/` or Dokploy/GitHub.
3. **For “where is X?”** → Check this index first, then the referenced file.

---

**Security:** `access/` is gitignored. Keep all credential files only in `access/` and never commit them.
