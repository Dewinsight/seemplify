# Outlook Connection Troubleshooting - Mailcow Verification

**Date:** January 19, 2026  
**Status:** Checking Mailcow Configuration

---

## ✅ Verified Mailcow Configuration

### Services Status
- ✅ **Dovecot (IMAP):** Running - Port 993 open
- ✅ **Postfix (SMTP):** Running - Ports 587, 465, 25 open
- ✅ **SOGo (Webmail):** Running

### Mailbox Configuration
- ✅ **michael@paddie.io:** Active, IMAP enabled, SMTP enabled
- ✅ **ryan@paddie.io:** Active, IMAP enabled, SMTP enabled
- ✅ **Mailbox paths:** Correctly configured

### Ports Open
- ✅ **993** (IMAP SSL): Listening
- ✅ **587** (SMTP STARTTLS): Listening
- ✅ **465** (SMTP SSL): Listening
- ✅ **25** (SMTP): Listening

---

## ⚠️ Potential Issues Found

### 1. SSL Certificate Warning
Logs show: `SSL_read failed: error:0A000418:SSL routines::tlsv1 alert unknown ca`

**This may cause Outlook to reject the connection if:**
- Certificate is self-signed
- Certificate chain is incomplete
- Certificate doesn't match the hostname

### 2. Authentication Configuration
- SASL authentication is configured
- Both IMAP and SMTP require authentication

---

## 🔧 Correct Outlook Settings

### For Michael (`michael@paddie.io`)

**IMAP Settings:**
```
Server: mail.seemplifyai.com
Port: 993
Encryption: SSL/TLS
Username: michael@paddie.io
Password: MichaelPass123!
```

**SMTP Settings:**
```
Server: mail.seemplifyai.com
Port: 587
Encryption: STARTTLS
Username: michael@paddie.io
Password: MichaelPass123!
✅ My outgoing server requires authentication
✅ Use same settings as incoming mail server
```

### For Ryan (`ryan@paddie.io`)

**IMAP Settings:**
```
Server: mail.seemplifyai.com
Port: 993
Encryption: SSL/TLS
Username: ryan@paddie.io
Password: RyanPass123!
```

**SMTP Settings:**
```
Server: mail.seemplifyai.com
Port: 587
Encryption: STARTTLS
Username: ryan@paddie.io
Password: RyanPass123!
✅ My outgoing server requires authentication
✅ Use same settings as incoming mail server
```

---

## 🛠️ Common Outlook Errors & Fixes

### Error: "Cannot connect to server"
**Possible Causes:**
1. Firewall blocking ports
2. Wrong server address
3. SSL/TLS certificate issue

**Fixes:**
- Verify server: `mail.seemplifyai.com`
- Check ports: IMAP `993`, SMTP `587`
- Try disabling SSL validation (temporary test)

### Error: "Authentication failed"
**Possible Causes:**
1. Wrong username format
2. Wrong password
3. Account disabled

**Fixes:**
- Use full email: `michael@paddie.io` (not just `michael`)
- Verify password is correct (case-sensitive)
- Check account is active in Mailcow

### Error: "SSL/TLS certificate error"
**Possible Causes:**
1. Self-signed certificate
2. Certificate doesn't match hostname
3. Certificate expired

**Fixes:**
- Accept certificate in Outlook (if self-signed)
- Check certificate validity
- Verify hostname matches certificate

### Error: "Outgoing server requires authentication"
**Fixes:**
- Enable "My outgoing server requires authentication"
- Select "Use same settings as incoming mail server"
- Enter full email and password

---

## 🧪 Testing Steps

### 1. Test IMAP Connection
```bash
# From your computer, test IMAP
openssl s_client -connect mail.seemplifyai.com:993
```

### 2. Test SMTP Connection
```bash
# Test SMTP STARTTLS
openssl s_client -connect mail.seemplifyai.com:587 -starttls smtp
```

### 3. Test Authentication
```bash
# Test login (from server)
docker exec mailcowdockerized-dovecot-mailcow-1 doveadm auth test michael@paddie.io MichaelPass123!
```

---

## 📋 Outlook Setup Checklist

- [ ] Server address: `mail.seemplifyai.com`
- [ ] IMAP port: `993` with SSL/TLS
- [ ] SMTP port: `587` with STARTTLS
- [ ] Username: Full email address (`michael@paddie.io`)
- [ ] Password: Correct password
- [ ] SMTP authentication: Enabled
- [ ] Use same credentials for SMTP: Yes
- [ ] Certificate warning: Accept if prompted (if self-signed)

---

## 🔍 What to Check Next

1. **What specific error is Outlook showing?**
   - "Cannot connect to server"
   - "Authentication failed"
   - "SSL certificate error"
   - Other error message

2. **Which connection is failing?**
   - IMAP (receiving)
   - SMTP (sending)
   - Both

3. **Test from webmail first:**
   - Login to https://mail.seemplifyai.com/SOGo/
   - If webmail works, issue is with Outlook configuration
   - If webmail doesn't work, issue is with account/password

---

**Last Updated:** January 19, 2026  
**Next Step:** Need specific Outlook error message to diagnose further
