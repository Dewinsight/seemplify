# Zulip (Seemplify Chat) – Passwords & Environment Variables

**Last Updated:** January 30, 2026  
**Where set:** Dokploy → Compose application “Seemplify Chat” (Zulip) → Environment variables  
**Repo:** No secrets in repo; see `zulip/.env.example` for variable names only.

---

## Required environment variables (Dokploy)

Set these in **Dokploy** for the Zulip compose app. Do **not** put real values in the repo.

### Site

| Variable | Purpose | Example (non-secret) |
|----------|---------|----------------------|
| `EXTERNAL_HOST` | Public hostname | `chat.seemplifyai.com` |
| `ADMIN_EMAIL` | Zulip admin email | Your admin email |
| `ORG_NAME` | Default org name | `Seemplify` |

### Database & services (passwords)

| Variable | Purpose |
|----------|---------|
| `POSTGRES_PASSWORD` | PostgreSQL password |
| `MEMCACHED_PASSWORD` | Memcached SASL password |
| `RABBITMQ_PASSWORD` | RabbitMQ password |
| `REDIS_PASSWORD` | Redis password |
| `SECRET_KEY` | Zulip Django secret key (long random string) |

### OIDC (Identity Provider)

| Variable | Purpose |
|----------|---------|
| `OIDC_CLIENT_SECRET` | Must match the `zulip` client secret in `Identityprovider/clients.json` |

### Brevo SMTP

| Variable | Purpose |
|----------|---------|
| `BREVO_SMTP_HOST` | `smtp-relay.brevo.com` |
| `BREVO_SMTP_PORT` | `587` |
| `BREVO_SMTP_USER` | Brevo SMTP login (see `BREVO-CONFIGURATION.md`) |
| `BREVO_SMTP_PASSWORD` | Brevo SMTP key (see `BREVO-CONFIGURATION.md`) |
| `NOREPLY_EMAIL` | Sender for Zulip emails (e.g. `noreply@seemplifyai.com`) |

---

## Where to get values

| Variable | Source |
|----------|--------|
| All Brevo values | `access/BREVO-CONFIGURATION.md` |
| `OIDC_CLIENT_SECRET` | Same value as zulip client in `Identityprovider/clients.json` (stored in Dokploy only) |
| DB/service passwords, `SECRET_KEY` | Generate strong values; store only in Dokploy |
| `ADMIN_EMAIL`, `EXTERNAL_HOST`, `ORG_NAME` | Your choice; no secret |

---

## GitHub Actions (deploy only)

Zulip is deployed by workflow using:

| GitHub Secret | Purpose |
|---------------|---------|
| `DOKPLOY_URL` | Dokploy base URL |
| `DOKPLOY_TOKEN` | Dokploy API key |
| `ZULIP_COMPOSE_ID` | Dokploy compose application ID for Zulip |

Values: see `access/DOKPLOY-API-CREDENTIALS-COMPLETE.md` and `access/GITHUB-SECRETS-SETUP-GUIDE.md`.

---

## Master index

For all credentials (Dokploy, GitHub, Brevo, SSH, etc.): **`access/CREDENTIALS-INDEX.md`**.
