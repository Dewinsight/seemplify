# Fix DMARC Record Conflict

**Date:** January 13, 2026  
**Priority:** MEDIUM - Remove duplicate/conflicting DMARC record  
**Status:** Ready to implement  
**Estimated Time:** 3 minutes

---

## Problem Identified

Two DMARC TXT records currently exist for `_dmarc.seemplifyai.com`:

**Record 1 (Mailcow):**
```
Name: _dmarc
Value: v=DMARC1; p=quarantine; rua=mailto:admin@seemplifyai.com
```

**Record 2 (Brevo):**
```
Name: _dmarc
Value: v=DMARC1; p=none; rua=mailto:rua@dmarc.brevo.com
```

**Issues:**
1. **Conflict:** Multiple DMARC records create confusion and potential DNS errors
2. **Policy Inconsistency:** One has `p=quarantine`, other has `p=none`
3. **Recovery Email Confusion:** Mailcow sends reports to admin@seemplifyai.com, Brevo tries to send to rua@dmarc.brevo.com
4. **Brevo's Record Weaker:** `p=none` means no enforcement, Mailcow's `p=quarantine` is better

---

## Implementation Steps

### Step 1: Login to Cloudflare (1 minute)

1. Access Cloudflare Dashboard:
   ```
   URL: https://dash.cloudflare.com
   Email: your Cloudflare login credentials
   ```

2. Select Domain:
   - Click: seemplifyai.com in domain list
   - Click: **DNS** > **Records**

---

### Step 2: Identify Duplicate DMARC Records (1 minute)

1. Look for DMARC records in DNS list:
   - Type: TXT
   - Name: `_dmarc`
   - You should see TWO records with this name

2. Identify which record to delete:
   - **KEEP:** `v=DMARC1; p=quarantine; rua=mailto:admin@seemplifyai.com` (Mailcow)
   - **DELETE:** `v=DMARC1; p=none; rua=mailto:rua@dmarc.brevo.com` (Brevo)

---

### Step 3: Delete Brevo's DMARC Record (1 minute)

1. Find the DMARC record with content:
   ```
   v=DMARC1; p=none; rua=mailto:rua@dmarc.brevo.com
   ```

2. Click: **Edit** button on this record
3. Click: **Delete** (trash can icon)
4. Confirm deletion when prompted

5. Verify only one DMARC record remains:
   ```
   Type: TXT
   Name: _dmarc
   Value: v=DMARC1; p=quarantine; rua=mailto:admin@seemplifyai.com
   ```

---

### Step 4: Verify DMARC Update (optional, 1 minute)

**Wait 5-10 minutes** for Cloudflare to propagate DNS changes.

#### Verification via CLI:
```bash
# Check for single DMARC record
nslookup -type=TXT _dmarc.seemplifyai.com 8.8.8.8

# Should show ONLY one record:
# _dmarc.seemplifyai.com text = "v=DMARC1; p=quarantine; rua=mailto:admin@seemplifyai.com"
```

#### Verification via Web Tool:
```
URL: https://mxtoolbox.com/DMARC.aspx
Domain: seemplifyai.com
Expected: DMARC Record Found - Single record
```

---

## Why Keep Mailcow's DMARC Record?

**Mailcow's Record:** `v=DMARC1; p=quarantine; rua=mailto:admin@seemplifyai.com`

**Advantages:**

1. **Better Policy (p=quarantine):**
   - When DMARC fails, email is quarantined (reviewed by recipient)
   - Brevo's `p=none` means failed emails are still delivered (potential spam gets through)
   - Quarantine is safer for new domains

2. **Proper Recovery Email:**
   - Reports sent to `admin@seemplifyai.com`
   - You have full control and access to these reports
   - Brevo sends to `rua@dmarc.brevo.com` (you don't have access to this inbox)

3. **Your Domain Control:**
   - Mailcow-generated record is specific to your infrastructure
   - Brevo's record is generic service record

---

## DMARC Policy Comparison

| Policy | Meaning | Recommendation |
|---------|-----------|----------------|
| **p=none** | No enforcement | ❌ Not for production |
| **p=quarantine** | Quarantine failures | ✅ Good for new domains |
| **p=reject** | Reject failures | ✅ Highest security (future) |

**Current Choice:** Keep `p=quarantine` (Mailcow's record)

---

## Testing DMARC After Fix

### Test 1: Verify Single Record:
```bash
# Check DMARC is consistent
nslookup -type=TXT _dmarc.seemplifyai.com 8.8.8.8

# Expected: ONE record (no "Non-authoritative answer" warning)
```

### Test 2: Email Delivery:
```
1. Send email from info@seemplifyai.com to your personal Gmail
2. Check Gmail headers:
   Click: Show original > Show all headers
3. Look for:
   - "Authentication-Results: dmarc=pass"
   - No conflicting dmarc=pass/fail entries
```

---

## Troubleshooting

### Still Shows Two DMARC Records:
```bash
# Use dig for detailed DNS check
dig +short _dmarc.seemplifyai.com TXT

# If still shows two records:
# 1. Check Cloudflare dashboard - delete Brevo's record
# 2. Check for cached DNS - may need to wait longer
# 3. Check TTL settings - ensure they're consistent
```

### DMARC Record Not Found:
```bash
# Verify all DNS records for seemplifyai.com
nslookup -type=TXT seemplifyai.com 8.8.8.8

# Check if _dmarc subdomain exists
# If not found, you may have deleted the wrong record
```

---

## References

### Documentation:
- [`access/MAILCOW-SETUP-COMPLETE.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/MAILCOW-SETUP-COMPLETE.md) - DMARC configuration notes
- [`access/MAILCOW-CREDENTIALS.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/MAILCOW-CREDENTIALS.md) - Mailcow credentials

### External Resources:
- https://mxtoolbox.com/DMARC.aspx - DMARC verification tool
- https://www.dmarcianalyzer.com/ - DMARC analysis
- https://www.cloudflare.com/learning/dns/dns-records/dns-overview/#dmarc - Cloudflare DMARC guide

---

## Completion Checklist

- [ ] Login to Cloudflare dashboard
- [ ] Navigate to seemplifyai.com DNS records
- [ ] Identify the two _dmarc TXT records
- [ ] Identify Brevo's DMARC record (p=none)
- [ ] Delete Brevo's DMARC record
- [ ] Verify only Mailcow's DMARC remains (p=quarantine)
- [ ] Wait 5-10 minutes for DNS propagation
- [ ] Verify DMARC via nslookup (should show single record)
- [ ] Send test email to Gmail
- [ ] Check email headers for consistent DMARC result

---

**After completing this task, you'll have a single, consistent DMARC policy with proper quarantine enforcement!**

**Next Task:** Request PTR record from Azure (Task 4)
