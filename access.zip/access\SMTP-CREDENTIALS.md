# SMTP Credentials - paddie.io Email Accounts

**Date:** January 19, 2026  
**For:** SMTP Authentication Settings

---

## 🔐 SMTP Username & Password

### Michael (`michael@paddie.io`)
- **SMTP Username:** `michael@paddie.io` (full email address)
- **SMTP Password:** `MichaelPass123!`
- **Server:** `mail.seemplifyai.com`
- **Port:** `587` (STARTTLS) or `465` (SSL)

### Ryan (`ryan@paddie.io`)
- **SMTP Username:** `ryan@paddie.io` (full email address)
- **SMTP Password:** `RyanPass123!`
- **Server:** `mail.seemplifyai.com`
- **Port:** `587` (STARTTLS) or `465` (SSL)

### Info (`info@paddie.io`)
- **SMTP Username:** `info@paddie.io` (full email address)
- **SMTP Password:** `TestEmail123!`
- **Server:** `mail.seemplifyai.com`
- **Port:** `587` (STARTTLS) or `465` (SSL)

---

## ⚙️ SMTP Configuration Summary

**For ALL accounts:**
- **SMTP Server:** `mail.seemplifyai.com`
- **Port:** `587` (recommended) or `465`
- **Encryption:** STARTTLS (port 587) or SSL/TLS (port 465)
- **Authentication:** Required ✅
- **Username:** Full email address (e.g., `michael@paddie.io`)
- **Password:** Account password (see above)

---

## 📋 Quick Reference

| Account | Username | Password | Server | Port |
|---------|----------|----------|--------|------|
| Michael | `michael@paddie.io` | `MichaelPass123!` | `mail.seemplifyai.com` | `587` |
| Ryan | `ryan@paddie.io` | `RyanPass123!` | `mail.seemplifyai.com` | `587` |
| Info | `info@paddie.io` | `TestEmail123!` | `mail.seemplifyai.com` | `587` |

---

## ⚠️ Important Notes

1. **Username Format:** Always use the **full email address** as username (not just the local part)
   - ✅ Correct: `michael@paddie.io`
   - ❌ Wrong: `michael`

2. **Authentication Required:** SMTP authentication is **mandatory** - you must enable it in your email client

3. **Same Credentials:** SMTP uses the **same username and password** as IMAP

4. **Password Security:** These are default passwords - change them after first login!

---

## 🔧 Example Configurations

### Outlook
```
SMTP Server: mail.seemplifyai.com
Port: 587
Encryption: STARTTLS
Username: michael@paddie.io
Password: MichaelPass123!
✅ My outgoing server requires authentication
```

### Gmail/Other Clients
```
SMTP Host: mail.seemplifyai.com
SMTP Port: 587
Security: STARTTLS
Username: michael@paddie.io
Password: MichaelPass123!
```

### Application Code (Node.js)
```javascript
{
  host: 'mail.seemplifyai.com',
  port: 587,
  secure: false, // true for 465, false for 587
  auth: {
    user: 'michael@paddie.io',
    pass: 'MichaelPass123!'
  }
}
```

---

**Last Updated:** January 19, 2026  
**Status:** ✅ Ready to Use
