# Dokploy Dashboard Access

**Quick Reference Card**

---

## 🔐 Login Credentials

```
Dashboard URL:  http://4.180.153.209:3000
Email:          admin@seemplifyai.com
Password:       Seemplify2026!
```

---

## 📋 Quick Access Steps

1. Open your browser
2. Navigate to: **http://4.180.153.209:3000**
3. Enter email: **admin@seemplifyai.com**
4. Enter password: **Seemplify2026!**
5. Click "Sign In"

---

## 🎯 What You Can Do in Dokploy

- ✅ View all deployed applications
- ✅ Check application status (running/stopped)
- ✅ View real-time logs
- ✅ Restart applications
- ✅ Update environment variables
- ✅ Trigger new deployments
- ✅ Manage domains and SSL certificates
- ✅ Monitor resource usage

---

## 📦 Applications in Dokploy

| Application | Status |
|-------------|--------|
| identity-provider | Running |
| recruiter-backend | Running |
| recruiter-frontend | Running |
| leave-backend | Running |
| leave-frontend | Running |
| performance-backend | Running |
| performance-frontend | Running |
| payroll-backend | Running |
| payroll-frontend | Running |

---

## 🔐 Change Password (Recommended)

1. Login to Dokploy dashboard
2. Click on your profile (top right)
3. Go to "Settings" or "User Management"
4. Select "Change Password"
5. Enter new password
6. **Update this document** with new password

---

## 🆘 Troubleshooting

### Can't Access Dashboard?
- Check if VM is running: `ping 4.180.153.209`
- Check if port 3000 is accessible
- Try SSH access: `ssh seemplify@4.180.153.209`

### Forgot Password?
1. SSH into the server
2. Access Dokploy PostgreSQL database
3. Reset password via database (see deployment plan)

---

**⚠️ Security Note:** Keep these credentials secure! Do not share publicly.
