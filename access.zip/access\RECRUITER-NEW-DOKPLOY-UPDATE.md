# Recruiter → recruiter/new Migration: Dokploy Build Path Update

**Created:** February 27, 2026  
**Purpose:** Update Dokploy applications to deploy from `recruiter/new/` instead of `recruiter/`

---

## Overview

The recruiter app has been switched from `recruiter/` (old, Weaviate) to `recruiter/new/` (new, Pinecone). GitHub Actions workflows have been updated. **You must manually update the Build Path in Dokploy** for each recruiter application.

---

## Applications to Update

| Application | Application ID | Current Build Path | New Build Path |
|-------------|----------------|-------------------|----------------|
| recruiter-backend (prod) | `tPMolDg5OEdQUBZ4MKMFh` | `recruiter/backend/` | `recruiter/new/backend/` |
| recruiter-frontend (prod) | `k_p-9M7ZWEhSSf_0JusGs` | `recruiter/frontend/` | `recruiter/new/frontend/` |
| recruiter-backend-dev | `dev-rec-be-001-seemp` | `recruiter/backend/` | `recruiter/new/backend/` |
| recruiter-frontend-dev | `dev-rec-fe-001-seemp` | `recruiter/frontend/` | `recruiter/new/frontend/` |

---

## Automated Update (Recommended)

Run the DB update script via SSH:

```bash
scp scripts/update-recruiter-dokploy-db.sh seemplify@4.180.153.209:/tmp/
ssh seemplify@4.180.153.209 "sed -i 's/\r$//' /tmp/update-recruiter-dokploy-db.sh && bash /tmp/update-recruiter-dokploy-db.sh"
```

Then trigger deploy via API or push to repo.

## Manual Update: Step-by-Step in Dokploy UI

1. **Log into Dokploy:** http://4.180.153.209:3000

2. **For each application above:**
   - Open the application (e.g., `recruiter-backend`)
   - Go to **Settings** or **Build** / **Source** tab
   - Find **Build Path** or **Build Context**
   - Change from `recruiter/backend` → `recruiter/new/backend` (or `recruiter/frontend` → `recruiter/new/frontend`)
   - Save changes

3. **Frontend Dev:** If using a separate Dockerfile for dev, ensure it uses `Dockerfile.dev`:
   - Build Path: `recruiter/new/frontend/`
   - Dockerfile: `Dockerfile.dev` (if Dokploy allows specifying)

4. **Environment variables:** The new backend uses **Pinecone** instead of Weaviate:
   - Add/update: `PINECONE_API_KEY` (from access credentials)
   - Remove or ignore: `WEAVIATE_HOST`, `WEAVIATE_SCHEME`, `WEAVIATE_API_KEY`

---

## Prerequisites Before Deployment

- [x] `recruiter/new/` is committed and pushed to `main` and `dev` branches
- [x] Dokploy build paths updated via `scripts/update-recruiter-dokploy-db.sh` (SSH + PostgreSQL)
- [ ] `PINECONE_API_KEY` set in recruiter-backend and recruiter-backend-dev env vars (grep `access/` for Pinecone)

## Deploy Agent Quick Reference

**Dokploy URL:** http://4.180.153.209:3000  
**API Token:** See `access/DOKPLOY-API-CREDENTIALS-COMPLETE.md` → `github-actions-2026...`

**Trigger deploy after build paths are updated:**
```bash
# Prod backend
curl -X POST "http://4.180.153.209:3000/api/application.deploy" \
  -H "x-api-key: <DOKPLOY_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"applicationId": "tPMolDg5OEdQUBZ4MKMFh"}'

# Prod frontend
curl -X POST "http://4.180.153.209:3000/api/application.deploy" \
  -H "x-api-key: <DOKPLOY_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"applicationId": "k_p-9M7ZWEhSSf_0JusGs"}'

# Dev backend
curl -X POST "http://4.180.153.209:3000/api/application.deploy" \
  -H "x-api-key: <DOKPLOY_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"applicationId": "dev-rec-be-001-seemp"}'

# Dev frontend
curl -X POST "http://4.180.153.209:3000/api/application.deploy" \
  -H "x-api-key: <DOKPLOY_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"applicationId": "dev-rec-fe-001-seemp"}'
```

**Or via GitHub Actions:** Push to `main`/`dev` (paths updated) or `gh workflow run deploy-recruiter-backend.yml`

---

## Verification

After updating and deploying:

- **Prod:** https://api.seemplifyai.com, https://app.seemplifyai.com
- **Dev:** https://api-dev.seemplifyai.com, https://app-dev.seemplifyai.com

---

## Rollback

To revert to the old recruiter:

1. Revert GitHub Actions paths to `recruiter/backend/**` and `recruiter/frontend/**`
2. Revert Dokploy build paths to `recruiter/backend/` and `recruiter/frontend/`
3. Redeploy
