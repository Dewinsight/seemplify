# Open WebUI - Azure OpenAI Setup Guide

**Status**: Configuration Required  
**Date**: January 7, 2026  
**Domain**: https://ai.seemplifyai.com

---

## Current Status

βοΈ OIDC SSO with Seemplify IdP: **Working**  
β Azure OpenAI Models: **Needs Configuration via UI**  
β οΈ Ollama Service: **Not Running** (expected - we're using Azure only)

---

## How to Add Azure OpenAI Models

### Step 1: Login as Admin

1. Go to https://ai.seemplifyai.com
2. Sign up for an account or **Sign in with Seemplify**
3. The first user becomes admin automatically

### Step 2: Add Azure OpenAI Connection

1. Navigate to **Admin Panel** (click your profile β **Admin Panel**)
2. Go to **Settings** β **Connections**
3. Click the **"+"** button to add a new connection
4. Fill in Azure OpenAI details:

```
Connection Name: Azure OpenAI
API Base URL:    https://ai-tranzfarai913527268236.cognitiveservices.azure.com/openai
API Key:         Tj3NdagLJ2ATvfdWkqQjDE1zSm1ibtEXh05ZsEvB5kJSyXW82refJQQJ99BDACYeBjFXJ3w3AAAAACOG2smm
API Version:     2025-01-01-preview
```

βΉοΈ **Note**: The "API Version" field will automatically appear when Open WebUI detects an Azure endpoint.

5. Click **"Verify Connection"**
   - Open WebUI will fetch your deployed models from Azure
   - You'll see your available models (e.g., `gpt-4.1`)

6. **Select the models** you want to use
7. Click **"Save"**

### Step 3: Configure Models

After adding the connection:

1. Go to **Admin Panel** β **Settings** β **Models**
2. Your Azure models should now appear in the list
3. You can:
   - Set default models
   - Configure model parameters
   - Enable/disable specific models for users

---

## Why Azure OpenAI Can't Be Configured via Environment Variables

According to Open WebUI's architecture:

β **Cannot be set via env vars**:
- Azure OpenAI endpoint URLs
- Azure API keys
- Model deployments list

β **Must be configured via Admin UI** because:
- Open WebUI needs to fetch deployment lists from Azure dynamically
- Each Azure resource has different model deployments
- API version varies by model type
- Configuration is stored in the database

---

## Fixing the Ollama Connection Error

The logs show:
```
ERROR - Connection error: Cannot connect to host ollama:11434
```

This is **expected** since you're using Azure OpenAI, not local Ollama. To disable these errors:

### Option 1: Disable Ollama (Recommended)

Update the docker-compose to disable Ollama checks:

```yaml
environment:
  - USE_OLLAMA_DOCKER=false
  - ENABLE_OLLAMA_API=false
```

### Option 2: Keep Both Ollama and Azure

If you want both local and Azure models, deploy an Ollama container.

---

## OIDC Logout/Login Issue

Based on the troubleshooting guide, the common fixes for "not found" errors after logout:

### 1. Check WEBUI_URL is Set Correctly

```bash
# Verify in container
docker exec seemplify-openwebui-rbjanx-open-webui-1 printenv | grep WEBUI_URL
```

Should show: `WEBUI_URL=https://ai.seemplifyai.com`

### 2. Clear Browser Cookies

After logout, clear:
- `oauth_session_id` cookie
- All cookies for `ai.seemplifyai.com`
- Try in **Incognito/Private mode**

### 3. Check Redirect URI Format

Verify in IdP `clients.json`:
```json
"redirect_uri_patterns": [
  "https://ai.seemplifyai.com/oauth/oidc/callback"
]
```

β **Correct**: `/oauth/oidc/callback`  
β **Wrong**: `/oauth/callback/oidc` or `/callback`

---

## Complete Azure OpenAI Configuration Example

### Your Azure Details:

```
Resource Name: ai-tranzfarai913527268236
Region:        East US (or your region)
Endpoint:      https://ai-tranzfarai913527268236.cognitiveservices.azure.com/openai
API Key:       Tj3NdagLJ2ATvfdWkqQjDE1zSm1ibtEXh05ZsEvB5kJSyXW82refJQQJ99BDACYeBjFXJ3w3AAAAACOG2smm
API Version:   2025-01-01-preview

Deployed Models:
- gpt-4.1 (deployment name from your .env)
```

### In Open WebUI Admin Panel:

1. **Connections Tab**:
   - Base URL: `https://ai-tranzfarai913527268236.cognitiveservices.azure.com/openai`
   - API Key: `Tj3NdagLJ2ATvfdWkqQjDE1zSm1ibtEXh05ZsEvB5kJSyXW82refJQQJ99BDACYeBjFXJ3w3AAAAACOG2smm`
   - API Version: `2025-01-01-preview`

2. **Verify and Select Models**:
   - Click "Verify Connection"
   - Wait for model list to load
   - Check the models you want to enable
   - Save

3. **Test**:
   - Go to main chat interface
   - Select your Azure model from dropdown
   - Start chatting!

---

## Alternative: Using LiteLLM Proxy (Advanced)

If you need more control or want to use environment variables, you can deploy LiteLLM as a proxy:

### LiteLLM Configuration File:

```yaml
model_list:
  - model_name: gpt-4.1
    litellm_params:
      model: azure/gpt-4.1
      api_base: https://ai-tranzfarai913527268236.cognitiveservices.azure.com/openai
      api_key: Tj3NdagLJ2ATvfdWkqQjDE1zSm1ibtEXh05ZsEvB5kJSyXW82refJQQJ99BDACYeBjFXJ3w3AAAAACOG2smm
      api_version: 2025-01-01-preview
```

### Deploy LiteLLM:

```bash
docker run -d \
  -v $(pwd)/litellm_config.yaml:/app/config.yaml \
  -p 4000:4000 \
  --name litellm-proxy \
  --restart always \
  ghcr.io/berriai/litellm:main-latest \
  --config /app/config.yaml
```

### Then in Open WebUI:

- Admin Panel β Connections
- API Base URL: `http://litellm-proxy:4000`
- API Key: `anything` (required but can be any value)

---

## Verification Steps

### 1. Test OIDC Login
```bash
# Should work:
curl -I https://ai.seemplifyai.com/oauth/oidc/callback

# Check logs:
ssh seemplify@4.180.153.209 "docker logs seemplify-openwebui-rbjanx-open-webui-1 | grep -i oidc"
```

### 2. Test Azure Connection
- Go to Admin Panel β Connections
- Add Azure OpenAI connection
- Click "Verify" - should list your models

### 3. Test Chat
- Select Azure model
- Send a message
- Should get response from Azure OpenAI

---

## Common Issues & Solutions

### βοΈ "Not Found" Error After Logout

**Cause**: Browser cache or cookie issues  
**Fix**: 
1. Clear all cookies for `ai.seemplifyai.com`
2. Try in Incognito mode
3. Check `WEBUI_URL` is set to `https://ai.seemplifyai.com`

### βοΈ "Cannot Connect to Ollama"

**Cause**: Ollama not deployed (expected)  
**Fix**: Ignore or disable with `USE_OLLAMA_DOCKER=false`

### βοΈ Azure Models Not Appearing

**Cause**: Connection not verified or API version mismatch  
**Fix**:
1. Re-verify connection in Admin Panel
2. Check API key is valid
3. Ensure API version matches your model (use `2025-01-01-preview`)

---

## Model Visibility - Will All Users See Your Models?

### β **YES** - All users will see Azure models you add!

I've configured `BYPASS_MODEL_ACCESS_CONTROL=true`, which means:

- β **Any model added by admin is visible to ALL users**
- β **No need to manually set each model to "Public"**
- β **No group permissions configuration needed**
- β **Works immediately for all current and future users**

### Without Bypass (Default Behavior):

If you want granular control later, you can remove `BYPASS_MODEL_ACCESS_CONTROL` and configure:

1. **Default Settings**: Admin Panel β Settings β Users β Groups β "Default permissions" β Enable "Models Access"

2. **Per-Model Visibility**: Admin Panel β Models β Edit each model β Change "Private" to "Public"

3. **Group-Based Access**: Create groups with specific model access permissions

### Current Configuration:

β **All models public** - Any Azure model you add will be available to all users immediately

---

## Next Steps

1. β Login to https://ai.seemplifyai.com with Seemplify SSO
2. β Add Azure OpenAI connection in Admin Panel
3. β Select your `gpt-4.1` model
4. β Start chatting - **All users will see this model!**
