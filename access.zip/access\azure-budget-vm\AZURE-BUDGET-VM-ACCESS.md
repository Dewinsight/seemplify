# Azure budget VM — access

All **documentation and SSH keys** for this server live in **`access/azure-budget-vm/`** (this directory). Commands below use paths **from the repository root**.

This document describes the Linux VM provisioned for general use. Originally sized for a **roughly sub‑$100/month** pay-as-you-go target; the VM was later **upsized to 16 GiB RAM** (see summary), which **typically increases monthly compute cost**—confirm in Cost Management.

**Provisioned:** 2026-04-09  
**Resized:** **`Standard_D4s_v5`** (16 GiB RAM, 4 vCPU) after initial deploy.

---

## Summary

| Property | Value |
|----------|--------|
| **VM name** | `vm-seemplify-budget` |
| **Resource group** | `rg-seemplify-budget-westus3` |
| **Region** | West US 3 |
| **Size** | `Standard_D4s_v5` (**4 vCPU**, **16 GiB** RAM; Intel) — guest often reports **~15 GiB** total usable |
| **OS** | Ubuntu 22.04 LTS (Ubuntu Server) |
| **OS disk** | 32 GiB managed (**Premium_LRS**); see [Server configuration](#server-configuration-azure) |
| **Public IP (IPv4)** | `172.182.227.84` |
| **Admin user (SSH)** | `seemplify` |
| **SSH private key** | `access/azure-budget-vm/id_rsa_azure_budget_vm` (local; not in git) |
| **SSH public key** | `access/azure-budget-vm/id_rsa_azure_budget_vm.pub` |
| **Developer Linux user** | `developer` (SSH key; **sudo** passwordless on VM; **no** Azure subscription access) |
| **Developer key (admin copy)** | `access/azure-budget-vm/id_ed25519_budget_vm_developer` / `.pub` |

**Note:** The VM was first created as `Standard_D2s_v5` (8 GiB) because `Standard_B2s` was unavailable in several regions. It was **resized to `Standard_D4s_v5`** to reach **16 GiB RAM** (also **4 vCPUs**). That SKU is **usually above** a strict **~$100/month** compute-only estimate at 24/7 Pay-As-You-Go—validate in [Azure pricing](https://azure.microsoft.com/pricing/details/virtual-machines/linux/) and **Cost Management**.

---

## Linux accounts: root vs admin

| Account | Role on the VM |
|---------|----------------|
| **`root`** | The superuser exists but **SSH login as `root` is not how you administer this box** (Ubuntu/Azure images use `PermitRootLogin prohibit-password`; direct `root` SSH is discouraged). Use **`sudo`** from a normal user instead. |
| **`seemplify`** | **Primary admin** created by Azure: member of **`sudo`**, **passwordless sudo** (typical Azure Ubuntu). This is the “main” administrative login for the subscription owner; key: `id_rsa_azure_budget_vm`. |
| **`developer`** | **Also administrative on the OS:** member of **`sudo`** with **passwordless sudo** via `/etc/sudoers.d/90-developer-nopasswd` (so `sudo` works with SSH key only—no login password set). **Still no Azure portal / `az` access** unless you grant that separately. Key: `id_ed25519_budget_vm_developer`. |

**Get a root shell (either admin user):** `sudo -i` or `sudo su -`.

**Remove developer’s sudo later (lock down):** as `seemplify`:

```bash
sudo rm -f /etc/sudoers.d/90-developer-nopasswd
sudo deluser developer sudo
```

---

## Server configuration (Azure)

Details below match the live subscription as queried with Azure CLI (`az vm show -d`, networking resources). Re-run those commands after you change sizing, disks, or networking.

### Compute

| Setting | Value |
|--------|--------|
| **VM size** | `Standard_D4s_v5` (general purpose, Intel, **4 vCPU**, **16 GiB RAM**) |
| **Computer name** | `vm-seemplify-budget` |
| **Azure VM ID** | `1e6f33a9-c9fd-4385-a65e-2f443da466c7` |
| **Location** | `westus3` (West US 3) |
| **Availability zone** | None (regional VM) |
| **Trusted Launch** | **Enabled** — `securityType`: Trusted Launch; **Secure Boot** on; **vTPM** on |
| **VM agent** | Linux guest agent provisioned (`provisionVmAgent`: true) |
| **Managed identity** | None |
| **Extensions** | Default Azure extension operations allowed; no custom extensions recorded at provision time |
| **Patch orchestration** | `patchMode` / assessment: **ImageDefault** (Ubuntu image defaults) |

### Operating system image

| Setting | Value |
|--------|--------|
| **Publisher / offer / SKU** | **Canonical** / `0001-com-ubuntu-server-jammy` / `22_04-lts-gen2` (**Gen2**) |
| **Version** | `latest` (resolved image build at create time: **22.04.202602250**) |
| **Admin username** | `seemplify` |
| **Password auth** | **Disabled** (`disablePasswordAuthentication`: true); SSH keys only for `seemplify` at platform level |
| **Guest OS** | Ubuntu **22.04 LTS** (Jammy) server |

The `developer` account and its keys are **Linux-only** (created after provisioning) and are **not** shown in the Azure portal’s initial SSH key list.

### Storage

| Setting | Value |
|--------|--------|
| **Data disks** | **None** (only OS disk) |
| **OS disk name** | `vm-seemplify-budget_OsDisk_1_98b431003f4c4b3580a7a6558e344f48` |
| **OS disk size** | **32 GiB** |
| **OS disk type** | **Premium_LRS** (Premium SSD) |
| **Host caching** | **ReadWrite** on OS disk |
| **Disk controller** | **SCSI** |
| **OS delete option** | **Detach** (disk is not auto-deleted with VM unless you change this) |

### Networking

| Resource | Name / value |
|----------|----------------|
| **Virtual network** | `vm-seemplify-budgetVNET` — address space **10.0.0.0/16** |
| **Subnet** | `vm-seemplify-budgetSubnet` — **10.0.0.0/24** |
| **Network interface** | `vm-seemplify-budgetVMNic` (type **Standard**, accelerated networking **off**) |
| **Private IPv4** | **10.0.0.4** (allocation: dynamic on the IP configuration) |
| **Public IP resource** | `vm-seemplify-budgetPublicIP` |
| **Public IP (IPv4)** | **172.182.227.84** |
| **Public IP SKU** | **Standard** |
| **Public IP assignment** | **Static** |
| **NSG** | `vm-seemplify-budgetNSG` (associated with the NIC) |
| **Inbound (custom)** | TCP: **22** (1000), **80** (1010), **443** (1020), **5432** (1030), **3001** (1040), **8081** (1050), **8082** (1060) — rule names `open-port-*` / `default-allow-ssh`; source **\*** unless you tighten later |
| **Outbound** | Default Azure NSG rules: allow to VNet and **Internet**, then deny-all fallback |

Internal DNS suffix (Azure-provided): `oejs0jfbet4ejnw0ewshhjia3e.phxx.internal.cloudapp.net` (useful for VM-to-VM name resolution inside the same VNet).

**Web (HTTP/HTTPS):** The NSG now allows **80** and **443** to this VM. You still need something **listening on the guest OS** (e.g. `nginx`, Caddy, Docker-published apps, or `python -m http.server` for a quick test). TLS certificates are your choice on-box (Certbot, Caddy auto-TLS) or terminate TLS in front (Cloudflare, Azure App Gateway, etc.).

**PostgreSQL (5432):** The NSG allows **5432** from the internet. **Strongly prefer** restricting **source IP** in Azure (NSG rule) or using **SSH tunnel** / private networking—exposed Postgres is a common attack surface. The guest must still **run PostgreSQL** (or Docker `-p 5432:5432`) and configure `pg_hba.conf` / firewall to accept connections.

### Azure resources in this deployment

All live in resource group **`rg-seemplify-budget-westus3`**:

| Azure resource type | Resource name |
|---------------------|---------------|
| Virtual machine | `vm-seemplify-budget` |
| OS disk (managed disk) | `vm-seemplify-budget_OsDisk_1_98b431003f4c4b3580a7a6558e344f48` |
| Network interface | `vm-seemplify-budgetVMNic` |
| Public IP address | `vm-seemplify-budgetPublicIP` |
| Virtual network | `vm-seemplify-budgetVNET` |
| Network security group | `vm-seemplify-budgetNSG` |

### Refresh configuration from CLI

```powershell
az vm show -g rg-seemplify-budget-westus3 -n vm-seemplify-budget -d -o json
az network nic list -g rg-seemplify-budget-westus3 -o table
az network nsg show -g rg-seemplify-budget-westus3 -n vm-seemplify-budgetNSG -o json
az network vnet show -g rg-seemplify-budget-westus3 -n vm-seemplify-budgetVNET -o json
```

---

## Azure account

| Property | Value |
|----------|--------|
| **Subscription** | Azure subscription 1 |
| **Subscription ID** | `377ec0a1-1a46-48df-bdfc-9a9664282180` |
| **Signed-in user (at provision time)** | `tonyegboo@gmail.com` |

Sign in from a workstation:

```powershell
az login
az account set --subscription "377ec0a1-1a46-48df-bdfc-9a9664282180"
```

---

## SSH access

**Step-by-step for `seemplify` and `developer` (Windows, macOS, Linux):** [AZURE-BUDGET-VM-SSH-STEP-BY-STEP.md](./AZURE-BUDGET-VM-SSH-STEP-BY-STEP.md)

From the repo root (PowerShell):

```powershell
ssh -i access/azure-budget-vm/id_rsa_azure_budget_vm seemplify@172.182.227.84
```

From WSL or macOS/Linux:

```bash
ssh -i access/azure-budget-vm/id_rsa_azure_budget_vm seemplify@172.182.227.84
```

If you see host key prompts on first connect, verify the fingerprint matches what you expect, then accept.

---

## Developer SSH access (no Azure account required)

Your developer **does not** need the Azure portal, `az login`, or subscription access. They only need:

1. **The private key** you send them through a **secure channel** (1Password, encrypted email, etc.).  
   - Admin copy on your machine: `access/azure-budget-vm/id_ed25519_budget_vm_developer`  
   - **Do not** commit this key to git; keep `access/` gitignored.
2. **Connection details** — give them the standalone handoff doc: [`AZURE-BUDGET-VM-DEVELOPER-SSH.md`](./AZURE-BUDGET-VM-DEVELOPER-SSH.md) (it intentionally omits subscription IDs and admin keys).

**On the VM today:** user `developer` has **`sudo` (passwordless)** on the guest OS—same class of control as `seemplify` for installing packages, editing system files, etc. They still have **no** Azure credentials unless you grant them separately. Login is **public-key only** (no password).

**Developer connects:**

```powershell
ssh -i PATH\TO\THEIR\COPY\OF\id_ed25519_budget_vm_developer developer@172.182.227.84
```

```bash
chmod 600 ~/.ssh/id_ed25519_budget_vm_developer   # if they store it under ~/.ssh
ssh -i ~/.ssh/id_ed25519_budget_vm_developer developer@172.182.227.84
```

### Optional: use the developer’s own key instead

If they already have an SSH key pair, they send you **only** their `.pub` file. As `seemplify` (admin key):

```bash
# Append their pubkey (replace path) to the developer account
sudo mkdir -p /home/developer/.ssh
sudo sh -c 'cat /path/to/their_key.pub >> /home/developer/.ssh/authorized_keys'
sudo chown -R developer:developer /home/developer/.ssh
sudo chmod 700 /home/developer/.ssh
sudo chmod 600 /home/developer/.ssh/authorized_keys
```

Then they connect with **their** private key and user `developer`.

### Revoke or rotate developer access

**Remove only the handoff key** (edit `authorized_keys` on the VM as `seemplify`):

```bash
sudo nano /home/developer/.ssh/authorized_keys
# delete the line matching id_ed25519_budget_vm_developer.pub (comment often ends with budget-vm-developer-handoff)
```

**Disable the account** (keeps files, blocks login):

```bash
sudo passwd -l developer
sudo chsh -s /usr/sbin/nologin developer
```

**Remove the account** (destructive):

```bash
sudo userdel -r developer
```

---

## Useful Azure CLI commands

**VM status**

```powershell
az vm get-instance-view -g rg-seemplify-budget-westus3 -n vm-seemplify-budget --query "instanceView.statuses[?starts_with(code, 'PowerState/')].displayStatus" -o tsv
```

**Stop billing for compute (deallocate — releases compute; disk and IP may still incur cost)**

```powershell
az vm deallocate -g rg-seemplify-budget-westus3 -n vm-seemplify-budget
```

**Start again**

```powershell
az vm start -g rg-seemplify-budget-westus3 -n vm-seemplify-budget
```

**Resize (example — pick a size available in your region)**

```powershell
az vm deallocate -g rg-seemplify-budget-westus3 -n vm-seemplify-budget
az vm resize -g rg-seemplify-budget-westus3 -n vm-seemplify-budget --size Standard_D2s_v5
az vm start -g rg-seemplify-budget-westus3 -n vm-seemplify-budget
```

**Open an extra port (example: TCP 8080 from anywhere — tighten source as needed)**

```powershell
az vm open-port -g rg-seemplify-budget-westus3 -n vm-seemplify-budget --port 8080
```

---

## Remove everything in this deployment

This deletes the VM, disks, NIC, public IP, VNet, and NSG in the resource group:

```powershell
az group delete --name rg-seemplify-budget-westus3 --yes --no-wait
```

---

## Security

- Keep `access/azure-budget-vm/id_rsa_azure_budget_vm` restricted to people and machines that should administer this VM.
- Keep `access/azure-budget-vm/id_ed25519_budget_vm_developer` as restricted as any password: only give it to people who should have VM access, and rotate if it leaks.
- Prefer SSH keys over passwords; this VM was created with **SSH public key** authentication only.
- Consider restricting NSG source IPs for port 22 once you have stable office or VPN egress IPs.

---

## Related

- **[AZURE-BUDGET-VM-SSH-STEP-BY-STEP.md](./AZURE-BUDGET-VM-SSH-STEP-BY-STEP.md)** — detailed SSH instructions for `seemplify` and `developer`.
- Existing production-style server notes (if present): `access/SERVER-ACCESS.md`, `access/ACCESS-GUIDE.md`, `access/README.md`.
