# Azure budget VM (`vm-seemplify-budget`)

Everything for this server is in this folder:

| File | Purpose |
|------|--------|
| **AZURE-BUDGET-VM-ACCESS.md** | Admin: Azure subscription, SSH, CLI, teardown |
| **AZURE-BUDGET-VM-SSH-STEP-BY-STEP.md** | **Start here for SSH:** `seemplify` + `developer`, Windows/macOS/Linux |
| **AZURE-BUDGET-VM-DEVELOPER-SSH.md** | Short handout for developers (no Azure details) |
| **id_rsa_azure_budget_vm** / **.pub** | Admin SSH key for user `seemplify` |
| **id_ed25519_budget_vm_developer** / **.pub** | `developer` login — **sudo** on the VM (no Azure access) |

From the **repo root**, admin SSH:

```powershell
ssh -i access/azure-budget-vm/id_rsa_azure_budget_vm seemplify@172.182.227.84
```

Full **Azure configuration** (compute, disk, networking, NSG, resource names) is in **AZURE-BUDGET-VM-ACCESS.md** → section *Server configuration (Azure)*.
