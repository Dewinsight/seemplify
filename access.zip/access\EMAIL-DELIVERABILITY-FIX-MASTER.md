# Email Deliverability Fix - Master Implementation Guide

**Date:** January 13, 2026  
**Status:** All 5 tasks documented and ready to implement  
**Estimated Total Time:** 1-3 days (including Azure approval time)

---

## Overview

Fix email deliverability issues for seemplifyai.com by implementing proper DNS authentication (DKIM, SPF, DMARC) and improving IP reputation (PTR record).

**Current Issues:**
1. DKIM TXT record missing from Cloudflare DNS (CRITICAL - causes spam placement)
2. SPF record doesn't authorize Brevo relay (HIGH - causes soft-fail)
3. Duplicate DMARC records causing conflicts (MEDIUM - inconsistent policy)
4. No PTR record from Azure (MEDIUM - poor IP reputation)

**Brevo Relay Status:** Already configured and working ✅

---

## Architecture

```mermaid
graph TD
    A[Email Sender: info@seemplifyai.com] --> B[Mailcow Server: mail.seemplifyai.com]
    B --> C[Brevo SMTP Relay: smtp-relay.brevo.com:587]
    C --> D[Gmail/Outlook/Other Providers]
    
    subgraph DNS_Fixes
        E[DKIM TXT Record] -.Configured.-> D
        F[SPF Record] -.Updated.-> D
        G[DMARC Record] -.Fixed.-> D
        H[PTR Record] -.Requested.-> D
    end
    
    subgraph Cloudflare_DNS
        E
        F
        G
    end
    
    subgraph Azure_Infrastructure
        H
        I[VM: 4.180.153.209]
    end
    
    I --> B
```

---

## Implementation Tasks (Complete List)

### Task 1: Configure DKIM Authentication ✅ DOCUMENTED
**File:** [`IMPLEMENT-DKIM-AUTHENTICATION.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/IMPLEMENT-DKIM-AUTHENTICATION.md)  
**Priority:** CRITICAL  
**Status:** Ready to implement  
**Estimated Time:** 15 minutes

**What You'll Do:**
1. Enable DKIM in Mailcow Admin Panel
2. Generate DKIM keys via UI
3. Copy DKIM TXT record
4. Add to Cloudflare DNS as `dkim._domainkey`
5. Wait 5-10 minutes for DNS propagation
6. Test DKIM signing with Gmail

**Expected Impact:** IMMEDIATE - Emails stop going to spam folder

---

### Task 2: Update SPF Record ✅ DOCUMENTED
**File:** [`UPDATE-SPF-RECORD.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/UPDATE-SPF-RECORD.md)  
**Priority:** HIGH  
**Status:** Ready to implement  
**Estimated Time:** 5 minutes

**What You'll Do:**
1. Login to Cloudflare Dashboard
2. Find SPF TXT record for seemplifyai.com
3. Update from `v=spf1 mx -all` to `v=spf1 mx include:spf.brevo.com -all`
4. Wait 5-10 minutes for DNS propagation
5. Verify SPF passes via mxtoolbox.com

**Expected Impact:** IMMEDIATE - SPF passes for both Mailcow and Brevo relay

---

### Task 3: Fix DMARC Conflict ✅ DOCUMENTED
**File:** [`FIX-DMARC-CONFLICT.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/FIX-DMARC-CONFLICT.md)  
**Priority:** MEDIUM  
**Status:** Ready to implement  
**Estimated Time:** 3 minutes

**What You'll Do:**
1. Login to Cloudflare Dashboard
2. Find duplicate DMARC records for `_dmarc.seemplifyai.com`
3. Delete Brevo's record: `v=DMARC1; p=none; rua=mailto:rua@dmarc.brevo.com`
4. Keep only Mailcow's record: `v=DMARC1; p=quarantine; rua=mailto:admin@seemplifyai.com`
5. Wait 5-10 minutes for DNS propagation

**Expected Impact:** IMMEDIATE - Consistent DMARC policy with quarantine enforcement

---

### Task 4: Request PTR Record from Azure ✅ DOCUMENTED
**File:** [`REQUEST-PTR-RECORD.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/REQUEST-PTR-RECORD.md)  
**Priority:** MEDIUM  
**Status:** Ready to implement  
**Estimated Time:** 10 minutes (plus 24-72 hours for Azure approval)

**What You'll Do:**
1. Login to Azure Portal
2. Navigate to seemplify-vm > Networking > Network Interface
3. Look for "Request PTR record" or "Reverse DNS" option
4. Submit request: 4.180.153.209 → mail.seemplifyai.com
5. Wait 24-72 hours for Azure approval
6. Verify PTR via nslookup

**Expected Impact:** 1-4 weeks - Improved IP reputation and sender trust

---

### Task 5: Test Email Deliverability ✅ DOCUMENTED
**File:** [`TEST-EMAIL-DELIVERABILITY.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/TEST-EMAIL-DELIVERABILITY.md)  
**Priority:** VALIDATION  
**Status:** Ready to implement (after Tasks 1-4 complete)  
**Estimated Time:** 10 minutes

**What You'll Do:**
1. Send test email to check-auth@verifier.port25.com
2. Verify SPF, DKIM, DMARC all pass
3. Send test email to personal Gmail
4. Check Gmail headers for authentication results
5. Test at mail-tester.com (aim for 9-10/10 score)
6. Verify 90%+ of test emails reach inbox

**Expected Impact:** VALIDATION - Confirm all fixes working correctly

---

## Execution Order & Timeline

### Immediate (Do Today - 30 minutes):

**Phase 1: Cloudflare DNS Fixes (Tasks 1-3) - 23 minutes**
```
Minutes 0-5:   Task 1 - Enable DKIM in Mailcow, copy record
Minutes 5-10:  Task 1 - Add DKIM TXT record to Cloudflare
Minutes 10-15: Task 2 - Update SPF record (include Brevo)
Minutes 15-18: Task 3 - Delete duplicate DMARC record
Minutes 18-23: Wait for DNS propagation (5-10 minutes)
```

**Phase 2: Azure PTR Request (Task 4) - 10 minutes (submission)**
```
Minutes 23-33: Task 4 - Submit PTR request to Azure
```

**Phase 3: Validation (Task 5) - Wait 24-72 hours**
```
Wait for Azure PTR approval (24-72 hours)
After approval: Task 5 - Test all authentication methods
```

---

## Success Criteria

**Task 1 (DKIM) Complete When:**
- DKIM enabled in Mailcow UI
- dkim._domainkey.seemplifyai.com TXT record visible in Cloudflare DNS
- Gmail emails show DKIM-Signature: pass
- mail-tester.com shows DKIM: Pass

**Task 2 (SPF) Complete When:**
- seemplifyai.com TXT record shows: `v=spf1 mx include:spf.brevo.com -all`
- nslookup confirms updated record
- mxtoolbox.com shows SPF: Valid - PASS
- check-auth@verifier.port25.com shows SPF: Pass

**Task 3 (DMARC) Complete When:**
- Only one _dmarc TXT record exists for seemplifyai.com
- Record shows: `v=DMARC1; p=quarantine; rua=mailto:admin@seemplifyai.com`
- mxtoolbox.com shows DMARC: Single valid record
- Gmail headers show consistent DMARC: dmarc=pass

**Task 4 (PTR) Complete When:**
- Azure PTR request submitted (or confirmed via support ticket)
- After approval: nslookup shows 4.180.153.209 → mail.seemplifyai.com
- dig shows PTR: 209.153.180.4.in-addr.arpa.100 IN PTR mail.seemplifyai.com

**Task 5 (Testing) Complete When:**
- check-auth@verifier.port25.com shows all three: SPF=pass, DKIM=pass, DMARC=pass
- Gmail headers show: Authentication-Results: spf=pass dkim=pass dmarc=pass
- mail-tester.com score: 9/10 or 10/10
- 90%+ of test emails reach Gmail inbox (not spam folder)

---

## Before vs After Comparison

### Current Email State:
| Metric | Status | Problem |
|--------|--------|----------|
| DKIM Authentication | ❌ Missing | Emails go to spam |
| SPF Record | ⚠️ Weak | Brevo relay soft-fails |
| DMARC Policy | ⚠️ Conflict | Duplicate records exist |
| PTR Record | ❌ Missing | Poor IP reputation |
| Brevo Relay | ✅ Working | Port 587 operational |
| Overall Score | 5-6/10 | High spam placement |

### Expected Email State (After All Fixes):
| Metric | Status | Improvement |
|--------|--------|-------------|
| DKIM Authentication | ✅ Pass | Emails verified as legitimate |
| SPF Record | ✅ Pass | Brevo relay authorized |
| DMARC Policy | ✅ Pass | Consistent quarantine policy |
| PTR Record | ✅ Configured | Better IP reputation |
| Brevo Relay | ✅ Working | Unchanged |
| Overall Score | 9-10/10 | Emails reach inbox |

---

## Quick Reference Files

### Implementation Guides:
1. [`IMPLEMENT-DKIM-AUTHENTICATION.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/IMPLEMENT-DKIM-AUTHENTICATION.md) - DKIM setup
2. [`UPDATE-SPF-RECORD.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/UPDATE-SPF-RECORD.md) - SPF update
3. [`FIX-DMARC-CONFLICT.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/FIX-DMARC-CONFLICT.md) - DMARC fix
4. [`REQUEST-PTR-RECORD.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/REQUEST-PTR-RECORD.md) - PTR request
5. [`TEST-EMAIL-DELIVERABILITY.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/TEST-EMAIL-DELIVERABILITY.md) - Validation

### Reference Documentation:
- [`MAILCOW-CREDENTIALS.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/MAILCOW-CREDENTIALS.md) - Mailcow/Brevo config
- [`BREVO-CONFIGURATION.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/BREVO-CONFIGURATION.md) - Brevo details
- [`SERVER-ACCESS.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/SERVER-ACCESS.md) - SSH/Mailcow access

---

## Troubleshooting Quick Links

### If DKIM Not Working:
```bash
# Check DKIM keys exist
ssh seemplify@4.180.153.209
docker exec mailcowdockerized-postfix-mailcow-1 ls -la /var/lib/postfix/dkim/

# Restart Postfix if keys exist but not signing
docker restart mailcowdockerized-postfix-mailcow-1

# Check Postfix logs
docker logs mailcowdockerized-postfix-mailcow-1 --tail 50 | grep -i dkim
```

### If SPF Still Fails:
```bash
# Verify DNS propagation
nslookup -type=TXT seemplifyai.com 8.8.8.8

# Check for multiple SPF records
dig +short seemplifyai.com TXT

# Test Brevo SPF directly
dig txt spf.brevo.com +short
```

### If DMARC Still Conflicts:
```bash
# Check for duplicate records
nslookup -type=TXT _dmarc.seemplifyai.com 8.8.8.8

# Use dig for detailed check
dig +short _dmarc.seemplifyai.com TXT
```

### If PTR Not Configured:
```bash
# Check current PTR
nslookup 4.180.153.209

# Verify forward DNS still works
nslookup mail.seemplifyai.com

# Check Azure portal status
# Login to portal.azure.com and verify PTR request status
```

---

## Implementation Checklist

**Phase 1: Cloudflare DNS (Tasks 1-3)**
- [ ] Task 1: Login to Mailcow Admin Panel (admin/moohoo)
- [ ] Task 1: Navigate to Configuration > DKIM keys
- [ ] Task 1: Enable DKIM for seemplifyai.com
- [ ] Task 1: Copy DKIM TXT record
- [ ] Task 1: Login to Cloudflare Dashboard
- [ ] Task 1: Add dkim._domainkey TXT record
- [ ] Task 2: Update SPF record to include Brevo
- [ ] Task 3: Delete duplicate DMARC record (Brevo's)
- [ ] All Tasks: Wait 5-10 minutes for DNS propagation

**Phase 2: Azure PTR (Task 4)**
- [ ] Task 4: Login to Azure Portal
- [ ] Task 4: Navigate to seemplify-vm > Networking
- [ ] Task 4: Submit PTR request or create support ticket
- [ ] Task 4: Wait 24-72 hours for Azure approval

**Phase 3: Validation (Task 5)**
- [ ] Task 5: Verify DKIM via mail-tester.com
- [ ] Task 5: Send email to check-auth@verifier.port25.com
- [ ] Task 5: Verify SPF, DKIM, DMARC all pass
- [ ] Task 5: Test Gmail delivery (check headers)
- [ ] Task 5: Get mail-tester.com score (9/10+)
- [ ] Task 5: Send 10 test emails over 24 hours
- [ ] Task 5: Verify 90%+ reach inbox

**Final Verification:**
- [ ] All authentication methods pass (SPF, DKIM, DMARC)
- [ ] PTR record configured (or skipped if not eligible)
- [ ] Email deliverability score: 9/10 or 10/10
- [ ] 90%+ of emails reach inbox

---

## Expected Outcome

**After completing all 5 tasks:**

### Immediate Improvement (After Tasks 1-3):
- DKIM signature: Present in all outbound emails
- SPF check: PASS for both Mailcow and Brevo
- DMARC policy: Single consistent record with p=quarantine
- Email placement: Inbox (not spam)

### Long-term Improvement (After Task 4 completes in 1-4 weeks):
- PTR record: 4.180.153.209 → mail.seemplifyai.com
- IP reputation: Improved from poor to good
- Sender trust: Higher across email providers
- Blacklist risk: Reduced

### Deliverability Score:
- Before fixes: 5-6/10 (high spam rate)
- After Tasks 1-3: 8-9/10 (significant improvement)
- After Task 4 (PTR): 9-10/10 (target score achieved)

---

## Summary

**Total Tasks:** 5  
**Total Estimated Time:** 30 minutes (execution) + 1-4 days (Azure approval)  
**Critical Path:** Tasks 1-3 (Cloudflare DNS fixes)  
**Priority Order:** DKIM > SPF > DMARC > PTR > Testing

**All tasks are documented with step-by-step CLI and manual instructions. You can execute each task by following the respective guide file.**

**Next Step:** Start with Task 1 (DKIM) - Follow [`IMPLEMENT-DKIM-AUTHENTICATION.md`](c:/Users/Michael/Documents/GitHub/seemplify/access/IMPLEMENT-DKIM-AUTHENTICATION.md)
