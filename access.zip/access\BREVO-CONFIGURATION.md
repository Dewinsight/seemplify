# Brevo (Sendinblue) Configuration

**Last Updated:** January 6, 2026  
**Status:** ✅ Active & Configured

---

## 📋 Account Overview

Brevo is used for:
1. **SMTP Relay** - Mailcow outbound email delivery (port 587)
2. **Transactional Emails** - HR application notifications (API)

---

## 🔑 API Credentials

### API Key (for application integrations)
```
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
```

**Used by:**
- Identity Provider (`Identityprovider/.env`)
- Recruiter Backend (`recruiter/backend/.env`)
- Performance Backend (`performance/backend/.env`)

### SMTP Key (for Mailcow relay)
```
xsmtpsib-65f677712f19a7adae324dcbf4b913c473f37b7baf209f07bd8a753d327c2bf0-8rhBHTyMJrZFoCub
```

**Used by:**
- Mailcow SMTP Relay

### MCP Key (Model Context Protocol)
```
eyJhcGlfa2V5IjoieGtleXNpYi02NWY2Nzc3MTJmMTlhN2FkYWUzMjRkY2JmNGI5MTNjNDczZjM3YjdiYWYyMDlmMDdiZDhhNzUzZDMyN2MyYmYwLUJOdzllWEhlQ05vUlJQbjMifQ==
```

**Decoded (base64):**
```json
{"api_key":"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"}
```

---

## 📧 SMTP Configuration

### Server Details
| Setting | Value |
|---------|-------|
| **SMTP Server** | `smtp-relay.brevo.com` |
| **Port** | `587` |
| **Login** | `93ea9d001@smtp-brevo.com` |
| **Password** | `xsmtpsib-65f677712f19a7adae324dcbf4b913c473f37b7baf209f07bd8a753d327c2bf0-8rhBHTyMJrZFoCub` |
| **Encryption** | STARTTLS (TLS 1.3) |

### Alternative Ports
| Port | Protocol | Use Case |
|------|----------|----------|
| 587 | STARTTLS | **Recommended** - Used by Mailcow |
| 465 | SSL/TLS | Legacy secure SMTP |
| 25 | Plain | Not recommended |
| 2525 | STARTTLS | Alternative (ISP blocking workaround) |

---

## 🔗 API Configuration

### API Endpoints
| Service | URL |
|---------|-----|
| **REST API** | `https://api.brevo.com/v3/` |
| **SMTP API** | `https://api.brevo.com/v3/smtp/email` |
| **MCP Endpoint** | `https://mcp.brevo.com/v1/` |

### API Headers
```http
api-key: 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
Content-Type: application/json
```

---

## 📱 Application Integration

### Identity Provider
```env
# Identityprovider/.env
BREVO_API_KEY=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
BREVO_FROM_EMAIL=no-reply@seemplifyai.com
BREVO_FROM_NAME=Seemplify
```

### Recruiter Backend
```env
# recruiter/backend/.env
BREVO_API_KEY=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
```

### Performance Backend
```env
# performance/backend/.env
BREVO_API_KEY=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
BREVO_FROM_EMAIL=no-reply@seemplifyai.com
BREVO_FROM_NAME=SEEMPLIFY
```

---

## 🐄 Mailcow SMTP Relay Configuration

### Database Entry
```sql
-- Stored in Mailcow MySQL database
SELECT * FROM relayhosts;

-- Result:
-- id: 1
-- hostname: [smtp-relay.brevo.com]:587
-- username: 93ea9d001@smtp-brevo.com
-- password: xsmtpsib-65f677712f19a7adae324dcbf4b913c473f37b7baf209f07bd8a753d327c2bf0-8rhBHTyMJrZFoCub
-- active: 1

-- Domain assignment:
SELECT domain, relayhost FROM domain WHERE domain = 'seemplifyai.com';
-- Result: seemplifyai.com | 1
```

### Verification
```bash
# Check relay configuration
ssh seemplify@4.180.153.209
docker exec mailcowdockerized-mysql-mailcow-1 mysql -u mailcow -p3w8aLaw8jyknrgbs3qFfDgdD4LRQ mailcow -e "SELECT * FROM relayhosts;"

# Test SMTP connection
docker exec mailcowdockerized-postfix-mailcow-1 nc -zv smtp-relay.brevo.com 587

# Check mail logs
docker logs mailcowdockerized-postfix-mailcow-1 --tail 50 | grep brevo
```

---

## 📊 Usage & Limits

### Free Tier Limits (Estimated)
| Feature | Limit |
|---------|-------|
| **Emails/Day** | 300 |
| **Emails/Month** | 9,000 |
| **API Calls/Day** | Unlimited |
| **Contacts** | Unlimited |

### Current Usage
- **Mailcow Relay:** All outbound emails from seemplifyai.com
- **Application Emails:** Password resets, notifications, etc.

---

## 🔒 Security Notes

1. **API Keys are Sensitive** - Do not expose in client-side code
2. **SMTP Key is Different from API Key** - Use correct one for each purpose
3. **Rotate Keys Periodically** - Generate new keys if compromised
4. **IP Whitelisting** - Consider enabling in Brevo dashboard

---

## 🌐 Brevo Dashboard Access

- **URL:** https://app.brevo.com
- **Login:** (Your Brevo account email)
- **SMTP Settings:** Settings → SMTP & API → SMTP
- **API Keys:** Settings → SMTP & API → API Keys

---

## 🔧 MCP Integration (Future)

### MCP Server Configuration
If you want to add Brevo MCP to your AI tools:

```json
{
  "mcpServers": {
    "brevo": {
      "command": "npx",
      "args": ["-y", "@brevo/mcp-server"],
      "env": {
        "BREVO_API_KEY": "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"
      }
    }
  }
}
```

### MCP Capabilities (if configured)
- Send transactional emails
- Manage contacts
- View campaign analytics
- Create email templates
- Manage SMTP settings

---

## 📚 Documentation Links

- [Brevo API Documentation](https://developers.brevo.com/docs)
- [SMTP API Reference](https://developers.brevo.com/docs/send-a-transactional-email)
- [Authentication Guide](https://developers.brevo.com/docs/authentication)
- [MCP Protocol](https://developers.brevo.com/docs/mcp-protocol)

---

## ✅ Verification Checklist

- [x] API Key working (applications sending emails)
- [x] SMTP Key working (Mailcow relay)
- [x] Port 587 connection successful
- [x] TLS 1.3 encryption verified
- [x] seemplifyai.com domain assigned to relay
- [x] Test emails delivered successfully

---

**Last Verified:** January 6, 2026  
**Status:** ✅ All systems operational
