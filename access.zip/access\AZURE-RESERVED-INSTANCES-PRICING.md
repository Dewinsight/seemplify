# Azure Reserved Instances Pricing Analysis

## Current Infrastructure

| Resource | Current Configuration | Region |
|----------|----------------------|--------|
| **VM** | Standard_D4s_v3 (4 vCPU, 16GB RAM) | West Europe |
| **OS Disk** | 128GB Premium SSD | West Europe |
| **Data Disk** | 256GB Standard SSD (Weaviate) | West Europe |

---

## 1. VM Reserved Instance Pricing

### Standard_D4s_v3 - Linux (West Europe)

| Payment Option | Hourly | Monthly | Annual | Total | Savings |
|---------------|--------|---------|--------|-------|---------|
| **Pay-As-You-Go** | $0.211 | ~$154 | ~$1,848 | - | Baseline |
| **1-Year Reserved** | ~$0.132 | ~$96 | ~$1,155 | $1,155 | **~37% ($693/yr)** |
| **3-Year Reserved** | ~$0.084 | ~$61 | ~$736 | $2,208 | **~60% ($1,112/yr)** |

### Upfront vs Monthly Payment

| Term | Upfront (Full) | Monthly (No Interest) |
|------|----------------|----------------------|
| 1-Year | $1,155 one-time | ~$96/month × 12 |
| 3-Year | $2,208 one-time | ~$61/month × 36 |

> **Note:** Monthly payments have the same total cost as upfront - Azure doesn't charge extra for monthly billing.

---

## 2. Alternative VM Options (Cost Savings)

If you want to reduce costs further, consider these alternatives:

### Smaller VMs

| VM Size | vCPU | RAM | Pay-As-You-Go | 1-Yr Reserved | 3-Yr Reserved |
|---------|------|-----|---------------|---------------|---------------|
| **D2s_v3** | 2 | 8GB | ~$77/mo | ~$48/mo | ~$31/mo |
| **D4s_v3** (current) | 4 | 16GB | ~$154/mo | ~$96/mo | ~$61/mo |
| **B2s** (burstable) | 2 | 4GB | ~$30/mo | ~$20/mo | ~$13/mo |
| **B4ms** (burstable) | 4 | 16GB | ~$120/mo | ~$75/mo | ~$48/mo |

### Newer Generation (D4s_v5)

| Option | Monthly Cost | Savings vs Current |
|--------|-------------|-------------------|
| D4s_v5 Pay-As-You-Go | ~$140/mo | ~9% cheaper |
| D4s_v5 1-Year Reserved | ~$88/mo | Better performance + savings |
| D4s_v5 3-Year Reserved | ~$56/mo | Best value |

---

## 3. Disk Pricing

### Current Data Disk (Weaviate)

| Disk | Size | Type | Monthly Cost | Reservation? |
|------|------|------|-------------|--------------|
| weaviate-data-disk | 256GB | Standard SSD (E15) | ~$19.20 | ❌ Not eligible |

### Disk Reservation Eligibility

| Disk Type | Reservation Available? | Minimum Size |
|-----------|----------------------|--------------|
| Standard HDD | ❌ No | - |
| Standard SSD | ❌ No | - |
| **Premium SSD** | ✅ Yes | P30 (1TB) or larger |
| Premium SSD v2 | ❌ No | - |
| Ultra Disk | ❌ No | - |

> **Important:** Azure disk reservations are **only available for Premium SSDs P30 or larger (1TB+)**. Your 256GB Standard SSD is not eligible for reservation pricing.

### If Upgrading to Premium SSD with Reservation

| Size | Type | Pay-As-You-Go | 1-Yr Reserved | 3-Yr Reserved |
|------|------|---------------|---------------|---------------|
| P30 (1TB) | Premium SSD | ~$122/mo | ~$98/mo | ~$76/mo |
| P40 (2TB) | Premium SSD | ~$235/mo | ~$188/mo | ~$147/mo |

**Recommendation:** Keep the Standard SSD - it's cost-effective for Weaviate workloads and doesn't justify upgrading to 1TB+ Premium just for reservation savings.

---

## 4. Complete Cost Comparison

### Current Costs (Pay-As-You-Go)

| Resource | Monthly | Annual |
|----------|---------|--------|
| D4s_v3 VM | $154 | $1,848 |
| OS Disk (128GB Premium) | $19 | $228 |
| Data Disk (256GB Standard SSD) | $19 | $228 |
| **Total** | **$192** | **$2,304** |

### With 1-Year VM Reservation

| Resource | Monthly | Annual | Commitment |
|----------|---------|--------|------------|
| D4s_v3 VM (reserved) | $96 | $1,155 | 1-year |
| OS Disk | $19 | $228 | - |
| Data Disk | $19 | $228 | - |
| **Total** | **$134** | **$1,611** | **Save $693/yr (30%)** |

### With 3-Year VM Reservation

| Resource | Monthly | Annual | Commitment |
|----------|---------|--------|------------|
| D4s_v3 VM (reserved) | $61 | $736 | 3-year |
| OS Disk | $19 | $228 | - |
| Data Disk | $19 | $228 | - |
| **Total** | **$99** | **$1,192** | **Save $1,112/yr (48%)** |

---

## 5. Azure Credits & Reserved Instances

### Can Azure Credits Be Used for Reservations?

| Credit Type | Can Purchase Reservations? |
|-------------|---------------------------|
| Microsoft for Startups | ❌ **NO** |
| Azure Sponsorship | ❌ **NO** |
| Visual Studio Credits | ❌ **NO** |
| Free Trial Credits | ❌ **NO** |
| Azure Prepayment (EA) | ✅ Yes |
| Pay-As-You-Go (Credit Card) | ✅ Yes |
| Enterprise Agreement | ✅ Yes |
| Microsoft Customer Agreement | ✅ Yes |

> **Source:** [Microsoft Learn - Azure Credits & Reservations](https://learn.microsoft.com/en-us/answers/questions/1353925/can-azure-reserved-instances-be-payed-with-microso)

### Why Credits Can't Be Used

Azure Sponsorship/Startup credits are delivered via special subscription types that don't support reservation purchases. Reservations require:
- Pay-As-You-Go subscription with credit card
- Enterprise Agreement (EA)
- Microsoft Customer Agreement (MCA)

### Workaround Options

1. **Use credits for pay-as-you-go** - Your credits offset the regular hourly charges
2. **Create a separate subscription** - Use a pay-as-you-go subscription for reservations
3. **Wait until credits expire** - Then convert to reserved instances

---

## 6. Recommendations

### Best Option: 1-Year VM Reservation

| Factor | Recommendation |
|--------|----------------|
| **Commitment Level** | 1-year (less risky than 3-year) |
| **Payment** | Monthly (no interest, same total cost) |
| **Annual Savings** | ~$693 (30% off) |
| **Flexibility** | Can exchange for different VM size |

### If Budget-Conscious: Consider Downsizing

| Current | Alternative | Monthly Savings |
|---------|------------|-----------------|
| D4s_v3 (4 vCPU, 16GB) | D2s_v3 (2 vCPU, 8GB) | ~$50/mo |
| D4s_v3 (4 vCPU, 16GB) | B4ms (burstable) | ~$30/mo |

### If Maximizing Savings: 3-Year Reservation

| Metric | Value |
|--------|-------|
| Total 3-Year Cost | $2,208 |
| Total Savings | $3,336 over 3 years |
| Monthly Equivalent | $61/mo vs $154/mo |

---

## 7. How to Purchase Reserved Instances

### Via Azure Portal

1. Go to **Azure Portal** → **Reservations**
2. Click **+ Add** → **Virtual Machine**
3. Select:
   - **Scope:** Single subscription or shared
   - **Region:** West Europe
   - **VM Size:** Standard_D4s_v3
   - **Term:** 1 year or 3 years
   - **Billing Frequency:** Upfront or Monthly
4. Review pricing and purchase

### Via Azure CLI

```bash
# List available reservations
az reservations catalog show --subscription-id <sub-id> --reserved-resource-type VirtualMachines --location westeurope

# Purchase reservation (requires proper permissions)
az reservations reservation-order purchase \
  --reservation-order-id <order-id> \
  --sku Standard_D4s_v3 \
  --location westeurope \
  --term P1Y \
  --billing-plan Monthly \
  --quantity 1
```

---

## 8. Summary

| Scenario | Monthly Cost | Annual Cost | Savings |
|----------|-------------|-------------|---------|
| Current (Pay-As-You-Go) | $192 | $2,304 | - |
| 1-Year VM Reservation | $134 | $1,611 | **$693/yr (30%)** |
| 3-Year VM Reservation | $99 | $1,192 | **$1,112/yr (48%)** |

### Key Takeaways

1. **VM Reservation:** ✅ Recommended - saves 30-60%
2. **Disk Reservation:** ❌ Not available for Standard SSD 256GB
3. **Azure Credits:** ❌ Cannot be used for reservations
4. **Best Value:** 1-year reservation with monthly payments
5. **Payment Flexibility:** Monthly payments = same cost as upfront

---

*Prices are estimates based on Azure pricing as of January 2026. Actual prices may vary. Check [Azure Pricing Calculator](https://azure.microsoft.com/en-us/pricing/calculator/) for current rates.*
