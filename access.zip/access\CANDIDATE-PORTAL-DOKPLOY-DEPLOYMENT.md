# Candidate Portal Dokploy Deployment

**Created:** May 29, 2026  
**Scope:** Recruiter candidate onboarding portal in `recruiter/candidates`

---

## Production

| Item | Value |
|------|-------|
| Dokploy application | `candidate-portal` |
| Application ID | `rSbQ94UbxV72pilm_1J9N` |
| Domain | `candidate.seemplifyai.com` |
| Additional Akwa Ibom domain | `candidate-ibom.aiinnigeria.com` |
| Git branch | `main` |
| Build path | `./recruiter/candidates` |
| Dockerfile | `./recruiter/candidates/Dockerfile` |
| Docker context | `./recruiter/candidates` |
| Internal port | `5300` |
| API target | `https://api.seemplifyai.com` |

Runtime env in Dokploy:

```bash
NODE_ENV=production
NEXT_PUBLIC_RECRUITER_API_BASE_URL=https://api.seemplifyai.com
```

`candidate-ibom.aiinnigeria.com` uses the same production app and codebase. The candidate portal detects the hostname and switches to Akwa Ibom branding automatically.

---

## Development

| Item | Value |
|------|-------|
| Dokploy application | `candidate-portal-dev` |
| Application ID | `keCzhatG2hg6aOdIFCACS` |
| Domain | `candidate-dev.seemplifyai.com` |
| Additional Akwa Ibom dev domain | `candidate-ibom-dev.aiinnigeria.com` |
| Git branch | `dev` |
| Build path | `./recruiter/candidates` |
| Dockerfile | `./recruiter/candidates/Dockerfile` |
| Docker context | `./recruiter/candidates` |
| Internal port | `5300` |
| API target | `https://api-dev.seemplifyai.com` |

Runtime env in Dokploy:

```bash
NODE_ENV=production
NEXT_PUBLIC_RECRUITER_API_BASE_URL=https://api-dev.seemplifyai.com
```

---

## Cloudflare DNS

The Seemplify records are configured in the `seemplifyai.com` zone.

| Hostname | Type | Target | Proxy |
|----------|------|--------|-------|
| `candidate.seemplifyai.com` | A | `4.180.153.209` | Proxied |
| `candidate-dev.seemplifyai.com` | A | `4.180.153.209` | Proxied |

The Akwa Ibom records are configured in the `aiinnigeria.com` zone.

| Hostname | Type | Target | Proxy |
|----------|------|--------|-------|
| `candidate-ibom.aiinnigeria.com` | A | `4.180.153.209` | Proxied |
| `candidate-ibom-dev.aiinnigeria.com` | A | `4.180.153.209` | Proxied |

Cloudflare token and zone IDs are documented in `SERVER-ACCESS.md` and `ACCESS-GUIDE.md`. Use the `aiinnigeria.com` zone ID for the Akwa Ibom candidate records.

---

## GitHub Actions

Repository secrets configured:

| Secret | Value |
|--------|-------|
| `CANDIDATE_PORTAL_APP_ID` | `rSbQ94UbxV72pilm_1J9N` |
| `CANDIDATE_PORTAL_DEV_APP_ID` | `keCzhatG2hg6aOdIFCACS` |

Workflow files:

| Workflow | Branch | Path trigger | Domain |
|----------|--------|--------------|--------|
| `.github/workflows/deploy-candidate-portal.yml` | `main` | `recruiter/candidates/**` | `candidate.seemplifyai.com`, `candidate-ibom.aiinnigeria.com` |
| `.github/workflows/deploy-candidate-portal-dev.yml` | `dev` | `recruiter/candidates/**` | `candidate-dev.seemplifyai.com`, `candidate-ibom-dev.aiinnigeria.com` |

Manual deploy:

```bash
gh workflow run deploy-candidate-portal.yml --ref main
gh workflow run deploy-candidate-portal-dev.yml --ref dev
```

Direct Dokploy deploy:

```bash
curl -X POST "http://4.180.153.209:3000/api/application.deploy" \
  -H "x-api-key: <DOKPLOY_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"applicationId": "rSbQ94UbxV72pilm_1J9N"}'
```

---

## Backend Requirements

The Recruiter backend must expose:

- `CANDIDATE_PORTAL_URL=https://candidate.seemplifyai.com`
- `AKWA_IBOM_CANDIDATE_PORTAL_URL=https://candidate-ibom.aiinnigeria.com`
- `CANDIDATE_JWT_TTL=20m`
- `CANDIDATE_REFRESH_TTL=30d`
- Candidate CORS origins:
  - `https://candidate.seemplifyai.com`
  - `https://candidate-dev.seemplifyai.com`
  - `https://candidate-ibom.aiinnigeria.com`
  - `https://candidate-ibom-dev.aiinnigeria.com`
- Candidate portal routes:
  - `/api/candidate-portal/*`
  - `/api/onboarding/*`

The backend sends Akwa Ibom onboarding links to `AKWA_IBOM_CANDIDATE_PORTAL_URL` when the recruiter request origin or organization branding contains `akwa`, `ibom`, or `jetstone`.

These are part of the candidate onboarding implementation.

When updating backend env in Dokploy, preserve the existing production `MONGO_URI`, `JWT_SECRET`, Azure AI, Brevo, Cloudinary, Nylas, and Weaviate keys. The candidate portal variables should be merged into the existing backend env, not replace it.

---

## Traefik Route

Because the candidate portal Dokploy app was created from automation instead of the UI, Traefik did not immediately generate a dynamic route file. Production routing was added at:

```bash
/etc/dokploy/traefik/dynamic/candidate-portal-prod.yml
```

It routes `candidate.seemplifyai.com` to the Swarm service `candidate-portal-prod` on port `5300` with Let's Encrypt enabled.

Add `candidate-ibom.aiinnigeria.com` as an additional domain on the same production Dokploy app. If Dokploy does not generate the route automatically, mirror the existing production dynamic route and add the Akwa host rule to the same service.

---

## Verification

Last verified on May 29, 2026:

- `https://candidate.seemplifyai.com/login` returns `200`.
- `https://candidate-ibom.aiinnigeria.com/login` returns `200` and shows Akwa Ibom branding.
- `https://app.seemplifyai.com/onboarding` returns `200`.
- `https://api.seemplifyai.com/api/candidate-portal/me` returns `401` without a candidate token.
- `https://api.seemplifyai.com/api/onboarding` returns `401` without a recruiter token.
