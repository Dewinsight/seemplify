# Mailcow Email Server - Access & Client Setup Guide

**Date:** January 6, 2026  
**Domain:** seemplifyai.com  
**Mail Server:** mail.seemplifyai.com

---

## 🌐 Web Access

### Option 1: Webmail (SOGo) - Recommended for Quick Access

**URL:** https://mail.seemplifyai.com/SOGo

**Features:**
- ✅ Read and send emails
- ✅ Calendar and contacts
- ✅ Works on any device with a browser
- ✅ No app installation needed

**Login:**
- **Username:** Full email address (e.g., admin@seemplifyai.com)
- **Password:** Your mailbox password
  - admin@seemplifyai.com: `Admin2026!Secure`
  - info@seemplifyai.com: `Info2026!Secure`

### Option 2: Admin Panel - For Management

**URL:** https://mail.seemplifyai.com

**Login:**
- **Username:** `admin`
- **Password:** `moohoo` ⚠️ **Change immediately!**

**What You Can Do:**
- Create/delete email accounts
- Manage domains
- View logs and statistics
- Configure anti-spam settings
- Manage aliases and forwarding

---

## 📱 Mobile Email Client Setup

### iPhone/iPad (iOS Mail App)

#### Step-by-Step Setup:

1. **Open Settings** → **Mail** → **Accounts**
2. Tap **Add Account**
3. Tap **Other** → **Add Mail Account**
4. Fill in:
   - **Name:** Your name (e.g., "Administrator")
   - **Email:** admin@seemplifyai.com
   - **Password:** Admin2026!Secure
   - **Description:** Seemplify Mail
5. Tap **Next**
6. **Select IMAP** (not POP)
7. **Incoming Mail Server:**
   - **Host Name:** mail.seemplifyai.com
   - **User Name:** admin@seemplifyai.com
   - **Password:** Admin2026!Secure
8. **Outgoing Mail Server:**
   - **Host Name:** mail.seemplifyai.com
   - **User Name:** admin@seemplifyai.com
   - **Password:** Admin2026!Secure
9. Tap **Next** → **Save**

#### iOS Mail Settings (Advanced):

If automatic setup fails, use manual configuration:

**Incoming Server (IMAP):**
- **Server:** mail.seemplifyai.com
- **Port:** 993
- **SSL:** ON (Required)
- **Authentication:** Password
- **Username:** admin@seemplifyai.com

**Outgoing Server (SMTP):**
- **Server:** mail.seemplifyai.com
- **Port:** 587
- **SSL:** ON (STARTTLS)
- **Authentication:** Password
- **Username:** admin@seemplifyai.com

---

### Android (Gmail App or Outlook App)

#### Option A: Gmail App (Recommended for Android)

1. **Open Gmail App**
2. Tap **Menu** (☰) → **Settings**
3. Tap **Add account**
4. Select **Other**
5. Enter email: admin@seemplifyai.com
6. Select **Personal (IMAP)**
7. **Password:** Admin2026!Secure
8. **Incoming Server Settings:**
   - **Username:** admin@seemplifyai.com
   - **Password:** Admin2026!Secure
   - **Server:** mail.seemplifyai.com
   - **Port:** 993
   - **Security type:** SSL/TLS (Accept all certificates)
9. **Outgoing Server Settings:**
   - **SMTP Server:** mail.seemplifyai.com
   - **Port:** 587
   - **Security type:** STARTTLS
   - **Require sign-in:** ✅ Checked
   - **Username:** admin@seemplifyai.com
   - **Password:** Admin2026!Secure
10. Tap **Next** → **Done**

#### Option B: Microsoft Outlook Mobile App

1. **Download Outlook app** from Play Store/App Store
2. **Open Outlook** → Tap **Get Started**
3. Enter email: admin@seemplifyai.com
4. Tap **Continue**
5. Select **IMAP**
6. Enter password: Admin2026!Secure
7. Tap **Sign In**
8. **If automatic setup fails, configure manually:**
   - **IMAP Host:** mail.seemplifyai.com
   - **IMAP Port:** 993
   - **IMAP Security:** SSL/TLS
   - **SMTP Host:** mail.seemplifyai.com
   - **SMTP Port:** 587
   - **SMTP Security:** STARTTLS
9. Tap **Done**

---

## 💻 Desktop Email Client Setup

### Microsoft Outlook (Desktop)

#### Windows/Mac Outlook Setup:

1. **Open Outlook**
2. Click **File** → **Add Account**
3. Enter email: admin@seemplifyai.com
4. Click **Advanced options**
5. Check **Let me set up my account manually**
6. Click **Connect**
7. Select **IMAP**
8. Fill in settings:

**Incoming Mail (IMAP):**
- **Server:** mail.seemplifyai.com
- **Port:** 993
- **Encryption:** SSL/TLS
- **Username:** admin@seemplifyai.com
- **Password:** Admin2026!Secure

**Outgoing Mail (SMTP):**
- **Server:** mail.seemplifyai.com
- **Port:** 587
- **Encryption:** STARTTLS
- **Authentication:** Required
- **Username:** admin@seemplifyai.com
- **Password:** Admin2026!Secure

9. Click **Connect** → **Done**

---

### Mozilla Thunderbird

1. **Open Thunderbird**
2. Click **☰ Menu** → **Account Settings**
3. Click **Account Actions** → **Add Mail Account**
4. Fill in:
   - **Your name:** Administrator
   - **Email:** admin@seemplifyai.com
   - **Password:** Admin2026!Secure
5. Click **Continue**
6. Select **IMAP** (recommended)
7. Click **Manual config**
8. Configure:

**Incoming (IMAP):**
- **Server:** mail.seemplifyai.com
- **Port:** 993
- **SSL:** SSL/TLS
- **Authentication:** Normal password

**Outgoing (SMTP):**
- **Server:** mail.seemplifyai.com
- **Port:** 587
- **SSL:** STARTTLS
- **Authentication:** Normal password

9. Click **Re-test** → **Done**

---

### Apple Mail (macOS)

1. **Open Mail app**
2. Go to **Mail** → **Add Account**
3. Select **Other Mail Account** → **Continue**
4. Fill in:
   - **Name:** Administrator
   - **Email:** admin@seemplifyai.com
   - **Password:** Admin2026!Secure
5. Click **Sign In**

**If manual setup needed:**
- **Account Type:** IMAP
- **Incoming Mail Server:** mail.seemplifyai.com
- **Outgoing Mail Server:** mail.seemplifyai.com
- Use port 993 (IMAP) and 587 (SMTP)

---

## 🔧 Server Configuration Quick Reference

### IMAP Settings (Receiving Email)
```
Server:   mail.seemplifyai.com
Port:     993
Security: SSL/TLS
Username: full email address (admin@seemplifyai.com)
Password: your mailbox password
```

### SMTP Settings (Sending Email)
```
Server:   mail.seemplifyai.com
Port:     587 (recommended) or 465
Security: STARTTLS (587) or SSL/TLS (465)
Auth:     Required
Username: full email address (admin@seemplifyai.com)
Password: your mailbox password
```

### Alternative Ports
- **SMTP Port 25:** Basic SMTP (often blocked by ISPs)
- **SMTP Port 465:** SMTPS (SSL/TLS from start)
- **SMTP Port 587:** Submission (STARTTLS - Recommended)
- **IMAP Port 143:** IMAP without encryption (not recommended)
- **IMAP Port 993:** IMAPS (SSL/TLS - Recommended)
- **POP3 Port 995:** POP3S (if you prefer POP3)

---

## 📧 Available Email Accounts

| Email Address | Password | Purpose | Quota |
|---------------|----------|---------|-------|
| admin@seemplifyai.com | `Admin2026!Secure` | Administrator | 10 GB |
| info@seemplifyai.com | `Info2026!Secure` | General inquiries | 10 GB |

⚠️ **Security Note:** Change these passwords after first login!

---

## 🌐 All Access URLs

| Service | URL | Credentials |
|---------|-----|-------------|
| **Webmail (SOGo)** | https://mail.seemplifyai.com/SOGo | Email accounts above |
| **Admin Panel** | https://mail.seemplifyai.com | admin / moohoo |
| **Server SSH** | ssh seemplify@4.180.153.209 | SSH key |

---

## 🔒 Security Recommendations

### For Mobile Devices

1. **Use strong passwords** - Change default passwords
2. **Enable device encryption** - Protect email data
3. **Use biometric login** - Fingerprint/Face ID if available
4. **Remote wipe capability** - If device is lost
5. **Don't save passwords** on shared devices

### For Email Accounts

1. **Change default passwords** immediately
2. **Use unique passwords** for each account
3. **Enable 2FA** if available in Mailcow
4. **Regular password rotation** - Every 90 days
5. **Monitor login activity** - Check Mailcow logs

---

## 🆘 Troubleshooting

### "Cannot Connect to Server" Error

**Check:**
1. Internet connection is active
2. Server is running: `ssh seemplify@4.180.153.209 "docker ps | grep mailcow"`
3. Ports are open in Azure NSG (they are!)
4. DNS is resolving: `nslookup mail.seemplifyai.com`

**Try:**
- Use port 587 instead of 465 for SMTP
- Disable VPN temporarily
- Check device firewall settings

### "Invalid Username/Password" Error

**Common Issues:**
1. Using just `admin` instead of full email `admin@seemplifyai.com`
2. Caps Lock is on
3. Wrong password (check MAILCOW-CREDENTIALS.md)
4. Space at beginning/end of username

**Fix:**
- Always use **full email address** as username
- Double-check password (case-sensitive)
- Try copying password from MAILCOW-CREDENTIALS.md

### "SSL Certificate Error" on Mobile

**iOS:**
- Tap **Continue** when prompted about certificate
- If blocked, go to Settings → General → About → Certificate Trust Settings

**Android:**
- Select **Accept all certificates** in advanced IMAP settings
- Some apps may require installing certificate manually

### Emails Going to Spam

**Check:**
1. SPF record configured: ✅ (v=spf1 mx -all)
2. DKIM record configured: ✅
3. DMARC record configured: ✅
4. Reverse DNS (PTR) for 4.180.153.209

**Test:**
- Send email to: check-auth@verifier.port25.com
- Check score at: https://www.mail-tester.com

### Can't Send Email (SMTP Error)

**Check:**
1. Using correct SMTP port (587 or 465)
2. Authentication is enabled
3. Using full email as username
4. Firewall not blocking outgoing connections

**Try:**
- Switch from port 465 to 587
- Enable STARTTLS instead of SSL/TLS
- Check Mailcow logs: `docker logs mailcowdockerized-postfix-mailcow-1`

---

## 📱 Recommended Apps

### iOS (iPhone/iPad)
- **Built-in Mail app** - ✅ Works perfectly
- **Microsoft Outlook** - ✅ Great for business
- **Gmail app** - ✅ Can add non-Gmail accounts

### Android
- **Gmail app** - ✅ Best option, supports IMAP
- **Microsoft Outlook** - ✅ Good alternative
- **Samsung Email** - ✅ If using Samsung device
- **K-9 Mail** - ✅ Open source, advanced features

---

## 💡 Pro Tips

### Saving Mobile Data
- **Fetch Settings:** Set to "Fetch manually" or "Every 30 minutes" instead of "Push"
- **Download Attachments:** Only when WiFi is available
- **Load Remote Images:** Disable to save data and improve privacy

### Battery Optimization
- Don't use "Push" notifications for all accounts
- Use "Fetch" every 15-30 minutes instead
- Reduce sync period for older emails

### Organization
- **Use Folders:** Create folders in webmail (SOGo) and they'll sync to mobile
- **Use Filters:** Set up server-side filters in Mailcow admin panel
- **Archive Old Emails:** Move to archive folder to keep inbox clean

---

## 🔗 Integration with HR Applications

Your HR applications can send emails via Mailcow:

### Backend Configuration

Add to your backend `.env` files:

```env
# Email Configuration
SMTP_HOST=mail.seemplifyai.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=info@seemplifyai.com
SMTP_PASS=Info2026!Secure
SMTP_FROM=info@seemplifyai.com
SMTP_FROM_NAME=Seemplify HR

# For notifications
ADMIN_EMAIL=admin@seemplifyai.com
```

### Node.js Example (Nodemailer)

```javascript
const nodemailer = require('nodemailer');

// Create reusable transporter
const transporter = nodemailer.createTransport({
  host: 'mail.seemplifyai.com',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: 'info@seemplifyai.com',
    pass: 'Info2026!Secure'
  }
});

// Send email
async function sendNotification(to, subject, html) {
  const info = await transporter.sendMail({
    from: '"Seemplify HR" <info@seemplifyai.com>',
    to: to,
    subject: subject,
    html: html
  });
  
  console.log('Message sent: %s', info.messageId);
  return info;
}

// Example: Interview invitation
await sendNotification(
  'candidate@example.com',
  'Interview Invitation - Seemplify',
  '<p>Dear Candidate,</p><p>We would like to invite you for an interview...</p>'
);
```

---

## 📊 Quick Setup Comparison

| Client | Difficulty | Features | Recommended |
|--------|------------|----------|-------------|
| **iOS Mail** | ⭐ Easy | Basic | ✅ Yes |
| **Android Gmail** | ⭐ Easy | Good | ✅ Yes |
| **Outlook Mobile** | ⭐⭐ Medium | Excellent | ✅ Yes |
| **Webmail (SOGo)** | ⭐ Easy | Good + Calendar | ✅ Yes |
| **Thunderbird** | ⭐⭐ Medium | Excellent | ✅ Yes |
| **Outlook Desktop** | ⭐⭐ Medium | Excellent | ✅ Yes |

---

## 🧪 Test Your Setup

### Test 1: Send Email via Webmail

1. Go to https://mail.seemplifyai.com/SOGo
2. Login as admin@seemplifyai.com
3. Click **Compose** (✉️ icon)
4. Send email to your personal email
5. Check if it arrives (check spam folder)

### Test 2: Configure Mobile Client

1. Follow setup instructions above
2. Send test email from mobile app
3. Receive test email on mobile app
4. Check sync with webmail

### Test 3: Test Email Deliverability

**Method A:** Automated Check
- Send email to: **check-auth@verifier.port25.com**
- You'll receive automated reply with:
  - SPF: Pass/Fail
  - DKIM: Pass/Fail
  - DMARC: Pass/Fail
  - Spam score

**Method B:** Mail Tester
1. Go to https://www.mail-tester.com
2. Copy the test email address shown
3. Send email from admin@seemplifyai.com to that address
4. Click "Then check your score"
5. **Aim for:** 9/10 or 10/10

---

## 📋 Common Email Client Settings Summary

### Quick Copy-Paste Configuration

**For all email clients:**

```
IMAP Server Settings (Incoming):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Server:     mail.seemplifyai.com
Port:       993
Security:   SSL/TLS
Username:   admin@seemplifyai.com
Password:   Admin2026!Secure

SMTP Server Settings (Outgoing):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Server:     mail.seemplifyai.com
Port:       587 (or 465)
Security:   STARTTLS (or SSL/TLS for 465)
Auth:       Required
Username:   admin@seemplifyai.com
Password:   Admin2026!Secure
```

---

## 🎯 Account-Specific Settings

### admin@seemplifyai.com

```
Email:      admin@seemplifyai.com
Password:   Admin2026!Secure
IMAP:       mail.seemplifyai.com:993 (SSL/TLS)
SMTP:       mail.seemplifyai.com:587 (STARTTLS)
Webmail:    https://mail.seemplifyai.com/SOGo
```

### info@seemplifyai.com

```
Email:      info@seemplifyai.com
Password:   Info2026!Secure
IMAP:       mail.seemplifyai.com:993 (SSL/TLS)
SMTP:       mail.seemplifyai.com:587 (STARTTLS)
Webmail:    https://mail.seemplifyai.com/SOGo
```

---

## 🔐 Password Management

### Change Password via Webmail

1. Login to https://mail.seemplifyai.com/SOGo
2. Click **Preferences** (gear icon ⚙️)
3. Click **Password**
4. Enter:
   - **Current Password:** Your current password
   - **New Password:** Your new password
   - **Confirm:** Repeat new password
5. Click **Change**

### Change Password via Admin Panel

1. Login to https://mail.seemplifyai.com
2. Go to **Configuration** → **Mail setup** → **Mailboxes**
3. Click on the mailbox you want to edit
4. Scroll to **Password** section
5. Enter new password
6. Click **Save**

### Change Mailcow Admin Password

1. Login to https://mail.seemplifyai.com
2. Click **admin** (top right)
3. Click **Edit**
4. Enter new password in **Password** field
5. Click **Save changes**

---

## 📞 Support & Commands

### Check if Mail Server is Running

```bash
ssh seemplify@4.180.153.209
docker ps --format 'table {{.Names}}\t{{.Status}}' | grep mailcow
```

### View Email Logs

```bash
# SMTP logs (sending)
docker logs mailcowdockerized-postfix-mailcow-1 --tail 100

# IMAP logs (receiving)
docker logs mailcowdockerized-dovecot-mailcow-1 --tail 100
```

### Check Email Queue

```bash
docker exec mailcowdockerized-postfix-mailcow-1 mailq
```

### Restart Mail Services

```bash
cd /data/mailcow
docker compose restart
```

---

## 🌟 Features Available

### Via Webmail (SOGo)

- ✅ Send and receive emails
- ✅ Calendar with scheduling
- ✅ Contacts/Address book
- ✅ Multiple email accounts
- ✅ Email filters and rules
- ✅ Vacation/auto-reply
- ✅ Email forwarding
- ✅ Mobile-responsive interface

### Via Admin Panel

- ✅ Create unlimited email accounts (up to domain limit)
- ✅ Email aliases (multiple addresses → one inbox)
- ✅ Email forwarding rules
- ✅ Spam filter configuration
- ✅ Virus scanning (ClamAV)
- ✅ DKIM key management
- ✅ Email logs and statistics
- ✅ Backup and restore

---

## 🚀 Advanced Setup

### Email Aliases

Create aliases (multiple addresses → one inbox):

1. Login to admin panel
2. Go to **Configuration** → **Mail setup** → **Aliases**
3. Click **Add alias**
4. Example: `contact@seemplifyai.com` → `info@seemplifyai.com`

### Auto-Reply/Vacation

Set up auto-reply in SOGo webmail:
1. Login to webmail
2. Click **Preferences** → **Filters**
3. Create vacation rule

### Email Forwarding

Forward emails to external address:
1. Admin panel → **Mailboxes**
2. Edit mailbox
3. Add to **Forward to** field
4. Choose: Keep copy or delete after forwarding

---

## 📱 Native App Alternatives

### iOS Alternatives to Built-in Mail

- **Spark Mail** - Smart inbox features
- **Airmail** - Power user features
- **Edison Mail** - AI-powered assistant
- **Canary Mail** - Security focused

### Android Alternatives

- **BlueMail** - Multiple accounts
- **TypeApp** - Modern interface
- **Aqua Mail** - Customizable
- **FairEmail** - Privacy focused

All of these support standard IMAP/SMTP with the settings above!

---

## ✅ Setup Verification Checklist

After configuring your email client:

- [ ] Can send email to external address (Gmail, Outlook.com, etc.)
- [ ] Can receive email from external address
- [ ] Emails not going to spam (check with mail-tester.com)
- [ ] Mobile push notifications working (if enabled)
- [ ] Contacts and calendar syncing (if using SOGo/CalDAV)
- [ ] Signature configured in email client
- [ ] Password changed from default

---

## 🎓 Email Best Practices

### Professional Email Etiquette

1. **Use proper signatures:**
   ```
   Best regards,
   Your Name
   Your Title
   Seemplify
   admin@seemplifyai.com
   https://seemplifyai.com
   ```

2. **Clear subject lines** - Recipients should know what email is about
3. **Professional tone** - Especially for customer/candidate communication
4. **Proofread** - Check spelling and grammar
5. **Timely responses** - Within 24 hours for business emails

### Spam Prevention

- Don't send bulk emails without proper tools
- Use BCC for multiple recipients
- Keep email lists clean (remove bounces)
- Monitor spam complaints in Mailcow admin

---

## 📖 Related Documentation

| Document | Purpose |
|----------|---------|
| **MAILCOW-SETUP-COMPLETE.md** | Complete setup summary |
| **MAILCOW-CREDENTIALS.md** | All login credentials |
| **MAILCOW-DEPLOYMENT-COMPLETE.md** | Technical deployment details |
| **SERVER-ACCESS.md** | Server and infrastructure access |

---

## 🔗 Useful Links

- **Mailcow Docs:** https://docs.mailcow.email/
- **SOGo Webmail Guide:** https://www.sogo.nu/support.html
- **Email Tester:** https://www.mail-tester.com
- **MX Toolbox:** https://mxtoolbox.com/SuperTool.aspx

---

**🎉 Your email server is fully configured and ready to use on all your devices!**

**Need help?** Check the troubleshooting section or contact your system administrator.

**Last Updated:** January 6, 2026
