# Frappe LMS API Credentials

**Date:** February 2, 2026  
**Purpose:** API access to lms.seemplifyai.com

---

## API Credentials

| Setting | Value |
|---------|-------|
| **Site URL** | `https://lms.seemplifyai.com` |
| **User** | `Administrator` |
| **API Key** | `6240a485f925e28` |
| **API Secret** | `ab9aede9235098e` |

**Auth header format (recommended):**

`Authorization: token <api_key>:<api_secret>`

---

## Usage

These credentials can be used to:
- Access the Frappe REST API
- Make API calls to manage doctypes
- Check email queue status
- Automate LMS administration tasks

### Example API Call

```bash
# Ping (no Cloudflare 1010; should return {"message":"pong"})
curl -s \
  -H "Authorization: token 6240a485f925e28:ab9aede9235098e" \
  "https://lms.seemplifyai.com/api/method/ping"

# Who am I? (should return {"message":"Administrator"})
curl -s \
  -H "Authorization: token 6240a485f925e28:ab9aede9235098e" \
  "https://lms.seemplifyai.com/api/method/frappe.auth.get_logged_user"

# Example: list 5 users (Resource API)
curl -s \
  -H "Authorization: token 6240a485f925e28:ab9aede9235098e" \
  "https://lms.seemplifyai.com/api/resource/User?fields=%5B%22name%22%2C%22enabled%22%5D&limit_page_length=5"
```

---

## Security Notes

1. **Keep Secret Safe:** Never expose `api_secret` in client-side code
2. **Rotate Periodically:** Generate new keys if credentials are compromised
3. **Access Control:** These keys provide access to your LMS instance
4. **Storage:** This file is in the `access/` directory (gitignored)

---

## API Endpoints

| Endpoint | Description |
|----------|-------------|
| `/api/method/<method_name>` | Call Frappe whitelisted methods |
| `/api/resource/<doctype>` | CRUD access to DocTypes |
| `/api/resource/<doctype>/<name>` | Access a specific document |

---

## Notes (Cloudflare / API access)

- If API calls ever return **Cloudflare `1010`** again, check whether the DNS record for `lms.seemplifyai.com` is **proxied**.
- Current operating mode: `lms.seemplifyai.com` was set to **DNS-only** to eliminate `1010` for `/api/*`.

---

**Status:** ✅ Active  
**Last Updated:** February 2, 2026
