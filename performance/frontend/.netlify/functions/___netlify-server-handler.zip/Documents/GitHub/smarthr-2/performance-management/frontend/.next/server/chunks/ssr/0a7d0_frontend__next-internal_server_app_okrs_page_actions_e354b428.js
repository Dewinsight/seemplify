module.exports=[46753,(a,b,c)=>{}];

//# sourceMappingURL=0a7d0_frontend__next-internal_server_app_okrs_page_actions_e354b428.js.map