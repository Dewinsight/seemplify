module.exports=[88611,(a,b,c)=>{}];

//# sourceMappingURL=0a7d0_frontend__next-internal_server_app__not-found_page_actions_e0f07d60.js.map