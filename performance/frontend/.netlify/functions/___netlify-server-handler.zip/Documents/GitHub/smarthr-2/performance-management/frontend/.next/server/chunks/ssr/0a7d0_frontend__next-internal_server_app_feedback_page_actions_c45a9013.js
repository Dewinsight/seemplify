module.exports=[52706,(a,b,c)=>{}];

//# sourceMappingURL=0a7d0_frontend__next-internal_server_app_feedback_page_actions_c45a9013.js.map