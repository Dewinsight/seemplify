var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__42a089ac._.js")
R.c("server/chunks/[root-of-the-server]__ab715ef8._.js")
R.c("server/chunks/[root-of-the-server]__69fa080d._.js")
R.c("server/chunks/4bfc1__next-internal_server_app_api_auth_[___nextauth]_route_actions_d9fc4434.js")
R.m(83249)
module.exports=R.m(83249).exports
