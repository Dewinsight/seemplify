var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__69fa080d._.js")
R.c("server/chunks/a48f6_next_29f38c95._.js")
R.c("server/chunks/0a7d0_frontend__next-internal_server_app_favicon_ico_route_actions_2db1d2e0.js")
R.m(51571)
module.exports=R.m(51571).exports
