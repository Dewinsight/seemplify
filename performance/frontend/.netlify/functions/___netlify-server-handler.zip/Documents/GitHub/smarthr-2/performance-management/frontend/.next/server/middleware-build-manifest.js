globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c80456b64cdb9515.js",
    "static/chunks/56cbb35a2f8929cd.js",
    "static/chunks/42af6e55c09e551b.js",
    "static/chunks/ad03a75bf68bdc8c.js",
    "static/chunks/turbopack-c98882d5679f9c6b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];