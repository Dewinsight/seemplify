module.exports=[48974,(a,b,c)=>{}];

//# sourceMappingURL=36c00_performance-management_frontend__next-internal_server_app_page_actions_610afc80.js.map