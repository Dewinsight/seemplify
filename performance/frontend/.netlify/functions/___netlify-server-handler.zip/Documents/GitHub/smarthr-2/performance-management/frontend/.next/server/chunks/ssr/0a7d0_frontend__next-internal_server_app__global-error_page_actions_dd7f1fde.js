module.exports=[85093,(a,b,c)=>{}];

//# sourceMappingURL=0a7d0_frontend__next-internal_server_app__global-error_page_actions_dd7f1fde.js.map