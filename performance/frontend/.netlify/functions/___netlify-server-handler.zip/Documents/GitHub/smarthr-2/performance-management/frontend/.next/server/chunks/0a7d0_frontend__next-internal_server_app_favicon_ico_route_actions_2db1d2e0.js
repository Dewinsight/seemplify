module.exports=[32144,(e,o,d)=>{}];

//# sourceMappingURL=0a7d0_frontend__next-internal_server_app_favicon_ico_route_actions_2db1d2e0.js.map