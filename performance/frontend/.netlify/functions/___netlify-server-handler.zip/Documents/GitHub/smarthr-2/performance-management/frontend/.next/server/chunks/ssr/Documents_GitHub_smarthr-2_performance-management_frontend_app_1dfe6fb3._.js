module.exports=[39730,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},26493,a=>{"use strict";let b={src:a.i(39730).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Documents_GitHub_smarthr-2_performance-management_frontend_app_1dfe6fb3._.js.map