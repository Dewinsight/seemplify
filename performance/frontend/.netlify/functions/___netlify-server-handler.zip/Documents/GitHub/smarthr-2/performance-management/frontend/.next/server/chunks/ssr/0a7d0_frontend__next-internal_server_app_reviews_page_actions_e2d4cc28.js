module.exports=[24002,(a,b,c)=>{}];

//# sourceMappingURL=0a7d0_frontend__next-internal_server_app_reviews_page_actions_e2d4cc28.js.map