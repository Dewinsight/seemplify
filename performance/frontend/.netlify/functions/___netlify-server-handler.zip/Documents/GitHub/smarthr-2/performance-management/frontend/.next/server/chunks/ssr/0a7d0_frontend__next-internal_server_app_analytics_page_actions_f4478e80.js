module.exports=[7711,(a,b,c)=>{}];

//# sourceMappingURL=0a7d0_frontend__next-internal_server_app_analytics_page_actions_f4478e80.js.map